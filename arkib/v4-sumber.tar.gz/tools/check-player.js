#!/usr/bin/env node
/* Automated checks for the V4 player video-showcase-v4.html (run: node tools/check-player.js).
 * A offline load · B one dataset · C labels, captions, Sheets write, coverage count-up · M paper
 * Borang ACD + Lampiran 1 · V hard gates (phone gate 00:24.30, re-typing by 00:11.85, title impact
 * 00:13.35, 3D angles, holds) · D frame determinism · E soundtrack (music + effects, no narration)
 * F player controls. Exit code 1 on failure. */
'use strict';
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { pathToFileURL } = require('url');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..');
const HTML = path.resolve(ROOT, process.argv[2] || 'video-showcase-v4.html');
const URL = pathToFileURL(HTML).href;
const WAV = path.join(ROOT, 'narration-bm.wav');
const SRT = path.join(ROOT, 'kit-suara', 'subtitles-bm.srt');
const results = [];
const check = (name, ok, detail) => { results.push({ name, ok: !!ok, detail: detail === undefined ? '' : String(detail) }); };
const sha = b => crypto.createHash('sha1').update(b).digest('hex');
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function open(browser, query) {
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  const blocked = [], errors = [];
  await ctx.route('**/*', r => { const u = r.request().url(); if (/^(file|data|blob):/i.test(u)) return r.continue(); blocked.push(u); return r.abort(); });
  const page = await ctx.newPage();
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(URL + (query || ''));
  await page.evaluate(() => window.ACD.ready);
  return { ctx, page, blocked, errors, cdp: await ctx.newCDPSession(page) };
}
const shot = async X => sha(Buffer.from((await X.cdp.send('Page.captureScreenshot', { format: 'png' })).data, 'base64'));

/* in-page helpers: effective opacity and on-stage visibility of an element */
const PAGE_HELPERS = () => {
  window.__eff = el => {
    if (!el || !el.getClientRects().length) return 0;
    let o = 1, e = el;
    while (e && e.id !== 'stage') { const cs = getComputedStyle(e); if (cs.display === 'none' || cs.visibility === 'hidden') return 0; o *= parseFloat(cs.opacity); e = e.parentElement; }
    const r = el.getBoundingClientRect();
    if (r.right < 0 || r.left > 1920 || r.bottom < 0 || r.top > 1080) return 0;
    return o;
  };
  window.__ref = r => document.querySelector('[data-ref="' + r + '"]');
  window.__at = t => window.renderFrame(Math.round(t * 60));
  window.__textVisible = (needle, min) => Array.from(document.querySelectorAll('#stage *')).some(el => el.childElementCount === 0 && el.textContent.includes(needle) && window.__eff(el) >= (min || 0.98));
  window.__visibleText = min => Array.from(document.querySelectorAll('#stage *')).filter(el => el.childElementCount === 0 && el.textContent.trim() && window.__eff(el) >= (min || 0.5)).map(el => el.textContent.trim()).join(' | ');
  window.__phoneOn = () => window.__eff(window.__ref('w.phone')) > 0.001;
  window.__yaw = ref => { const m = /rotateY\(([-\d.]+)deg\)/.exec(window.__ref(ref).style.transform || ''); return m ? +m[1] : 0; };
};
/* longest continuous run (seconds) in [t0, t1] where pred(frame) holds, sampled every frame */
async function longestRun(page, t0, t1, predSrc) {
  return page.evaluate(([a, b, src]) => {
    const pred = new Function('t', src);
    let best = 0, cur = 0, bestStart = -1, curStart = -1;
    for (let f = Math.round(a * 60); f <= Math.round(b * 60); f++) {
      window.renderFrame(f);
      if (pred(f / 60)) { if (cur === 0) curStart = f / 60; cur++; if (cur > best) { best = cur; bestStart = curStart; } } else cur = 0;
    }
    return { sec: best / 60, from: bestStart, to: bestStart + best / 60 };
  }, [t0, t1, predSrc]);
}
function parseSrt(file) {
  const t = s => { const m = /(\d+):(\d+):(\d+),(\d+)/.exec(s); return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000; };
  return fs.readFileSync(file, 'utf8').replace(/\r/g, '').trim().split(/\n\n+/).map(b => { const l = b.split('\n'); const [a, z] = l[1].split(' --> '); return { start: t(a), end: t(z), text: l.slice(2).join('\n') }; });
}
const flat = s => s.replace(/\s+/g, ' ').trim();

(async () => {
  const browser = await chromium.launch({ args: ['--autoplay-policy=user-gesture-required'] });
  try {
    /* ---------------- A. offline load */
    const R = await open(browser, '?render=1');
    await R.page.evaluate(PAGE_HELPERS);
    const html = fs.readFileSync(HTML, 'utf8'), textOnly = html.replace(/[A-Za-z0-9+/=]{400,}/g, '');
    check('A1 opens from file:// with every network request blocked', R.blocked.length === 0, R.blocked.length + ' request(s) attempted');
    check('A2 no live URL / spreadsheet ID / map coordinates in the file', !/https?:\/\//i /* [pengecam sebenar dibuang dalam salinan repositori awam] */.test(textOnly));
    const meta = await R.page.evaluate(() => ({ fps: window.ACD.FPS, frames: window.ACD.TOTAL_FRAMES, dur: window.ACD.DURATION, scenes: SCENES.map(s => s.start).concat(SCENES[SCENES.length - 1].end) }));
    check('A3 timeline 120 s × 60 fps = 7,200 frames', meta.fps === 60 && meta.frames === 7200 && meta.dur === 120, JSON.stringify({ fps: meta.fps, frames: meta.frames, dur: meta.dur }));
    check('A4 V3 segments 0 · 13.2 · 24.3 · 49 · 62 · 78 · 85 · 105 · 112.35 · 120', meta.scenes.join() === '0,13.2,24.3,49,62,78,85,105,112.35,120', meta.scenes.join(' '));
    const kept = ['video-showcase.html', 'NADI-Muallim-120s.mp4', 'video-showcase-v3.html', 'NADI-Muallim-Pitch-120s-v3.mp4'];
    check('A5 V2 and V3 exports kept for comparison', kept.every(f => fs.existsSync(path.join(ROOT, f))) && !kept.includes(path.basename(HTML)), kept.join(', '));

    /* ---------------- B. one dataset (110 / 92 / 12 / 6 / 84%) */
    const T = await R.page.evaluate(() => window.ACD.TOTALS);
    check('B1 totals 110 / 92 / 12 / 337 / 3 / 3, unvisited 6', T.locality === 110 && T.visited === 92 && T.locked === 12 && T.pop === 337 && T.symp === 3 && T.ref === 3 && T.unvisited === 6, JSON.stringify(T));
    check('B2 coverage ROUND(92/110×100) = 84%', T.pct === 84, (92 / 110 * 100).toFixed(3) + '% → ' + T.pct + '%');
    const teamPct = await R.page.evaluate(() => [1, 2, 3, 4, 5, 6].map(t => calcTeamPct(TEAMS[t])));
    check('B3 team coverage 85/83/84/82/83/83 %', teamPct.join() === '85,83,84,82,83,83', teamPct.join(' '));
    const ds = await R.page.evaluate(() => {
      const g = r => window.__ref(r).textContent.replace(/\s+/g, ' ').trim();
      window.__at(70); const dash = { pct: g('dk.kpiPct'), ratio: g('dk.kpiRatio') }, res = g('ov.res');
      window.__at(90.5); const card = ['na.kTarget', 'na.kVisited', 'na.kLocked', 'na.kLeft'].map(r => window.__ref(r).querySelector('.na-kpi-n').textContent.trim()), left = g('ov.left');
      window.__at(83); const sum = g('ov.summary');
      return { dash, res, card, left, sum };
    });
    const oneSet = ds.dash.pct === '84%' && ds.dash.ratio === '(92 / 110 premis)' && /84%/.test(ds.res) && /92 daripada 110 premis dilawati/.test(ds.res) &&
      ds.card.join() === '110,92,12,6' && /6\s*premis belum dilawati.*12\s*berkunci atau kosong/.test(ds.left) && /92 \/ 110 \(84%\)/.test(ds.sum) && /12\s*premis/.test(ds.sum);
    check('B4 the same numbers on the monitor, coverage card, NADI card, follow-up card and summary', oneSet, JSON.stringify(ds).slice(0, 300));
    const reveal = await R.page.evaluate(() => { const hits = []; for (let f = 1458; f <= 1980; f += 6) { window.renderFrame(f); const tx = window.__visibleText(0.3); const m = tx.match(/\b(110|92|84 ?%|12 berkunci|6 premis)\b/); if (m) hits.push((f / 60).toFixed(2) + 's:' + m[0]); } return hits; });
    check('B5 no headline numbers during the phone reveal (00:24.30–00:33)', reveal.length === 0, reveal.slice(0, 4).join(' ') || 'none');
    const indiv = await R.page.evaluate(() => { window.__at(42); const rec = window.__ref('ov.rl2').textContent; window.__at(83); const sm = window.__ref('ov.summary').textContent; window.__at(18); const na = window.__ref('na.card').textContent; return { rec, sm, na }; });
    check('B6 screened / referred individuals kept distinct from notified cases', /individu bergejala/.test(indiv.rec) && !/\bkes\b/i.test(indiv.rec) && /337 diperiksa · 3 bergejala · 3 dirujuk/.test(indiv.sm) && /Kes Wabak/.test(indiv.na) && !/bergejala/.test(indiv.na), flat(indiv.rec));

    /* ---------------- C. labels, captions, the Sheets write */
    const simAt = [1, 5, 10, 18, 22, 26, 34, 45, 51, 58, 64, 72, 80, 87, 96, 102];
    const simVis = [];
    for (const t of simAt) simVis.push(await R.page.evaluate(x => { window.__at(x); return Array.from(document.querySelectorAll('#stage .sim-badge')).some(el => window.__eff(el) > 0.5); }, t));
    check('C1 "DATA SIMULASI" on screen at ' + simAt.join(', ') + ' s', simVis.every(Boolean), simVis.map((v, i) => simAt[i] + 's:' + (v ? 'ya' : 'TIDAK')).join(' '));
    const protoAt = [[22.5, true], [24.0, true], [87, true], [100, true], [107, true], [111, true], [30, false], [58, false], [70, false], [82, false], [116, false]];
    const protoVis = [];
    for (const [t] of protoAt) protoVis.push(await R.page.evaluate(x => { window.__at(x); return Array.from(document.querySelectorAll('#stage .proto-badge')).some(el => window.__eff(el) > 0.5); }, t));
    check('C2 "PROTOTAIP INTEGRASI" on the NADI action, the NADI follow-up and the last benefit card only', protoVis.every((v, i) => v === protoAt[i][1]), protoVis.map((v, i) => protoAt[i][0] + 's:' + (v ? 'ya' : 'tidak')).join(' '));
    const srt = parseSrt(SRT);
    const cues = await R.page.evaluate(() => CUES.map(c => ({ id: c.id, start: c.start, end: c.end, sub: c.sub, scene: c.scene })));
    const adjusted = ['c05', 'c06'];
    const same = cues.filter((c, i) => !adjusted.includes(c.id) && srt[i] && Math.abs(srt[i].start - c.start) < 0.0005 && Math.abs(srt[i].end - c.end) < 0.0005 && flat(srt[i].text) === flat(c.sub));
    check('C3 19 cues from subtitles-bm.srt (17 unchanged; c05/c06 split moved to the pause at 25.66/25.69 s)', srt.length === 19 && cues.length === 19 && same.length === 17 &&
      flat(cues[4].sub) === flat(srt[4].text) && flat(cues[5].sub) === flat(srt[5].text) && Math.abs(cues[4].start - srt[4].start) < 0.0005 && Math.abs(cues[5].end - srt[5].end) < 0.0005,
      same.length + ' identical + c05 ' + cues[4].start + '–' + cues[4].end + ', c06 ' + cues[5].start + '–' + cues[5].end);
    const caps = await R.page.evaluate(() => ({ lines: CUES.every(c => c.sub.split('\n').length <= 2), ordered: CUES.every((c, i) => !i || c.start >= CUES[i - 1].end), inScene: CUES.every(c => { const s = SCENES.find(q => q.id === c.scene); return c.start >= s.start && c.start < s.end; }) }));
    check('C4 captions: ≤ 2 lines, in order without overlap, each starts in its segment', caps.lines && caps.ordered && caps.inScene, JSON.stringify(caps));
    const capOk = [];
    for (const c of cues) capOk.push(await R.page.evaluate(([mid, sub]) => { window.__at(mid); const b = window.__ref('subsBox'); return b.textContent === sub && parseFloat(getComputedStyle(b).opacity) > 0.95; }, [(c.start + c.end) / 2, c.sub]));
    check('C5 the caption on screen matches its cue at the middle of all 19 cues', capOk.every(Boolean), capOk.filter(Boolean).length + '/19');
    const target = await R.page.evaluate(() => {
      const b = r => window.__ref(r).textContent.trim();
      window.__at(66.5); const before = [b('ph.kpiBadge'), b('dk.kpiBadge')], mark = window.__eff(window.__ref('dk.targetMark')) > 0.9 && window.__textVisible('Sasaran 80%', 0.5);
      window.__at(73); const after = [b('ph.kpiBadge'), b('dk.kpiBadge')], formula = window.__textVisible('sasaran dalam aplikasi: ≥ 80%', 0.98), pill = window.__eff(window.__ref('ov.capai')) > 0.98;
      return { before, after, mark, formula, pill };
    });
    check('C6 target animation (v1): "Sedang Berjalan (<80%)" → "Capai Sasaran (≥80%)", "Sasaran 80%" marker, pill, formula labelled "sasaran dalam aplikasi"',
      target.before.every(x => x === 'Sedang Berjalan (<80%)') && target.after.every(x => x === 'Capai Sasaran (≥80%)') && target.mark && target.formula && target.pill, JSON.stringify(target));
    const cu = await R.page.evaluate(() => {
      const pct = t => { window.__at(t); return [window.__ref('ph.kpiPct').textContent, window.__ref('dk.kpiPct').textContent, window.__ref('dk.mLoc').textContent, window.__ref('dk.mVis').textContent]; };
      const ev = window.ACD.soundEvents().find(e => e.k === 'success');
      return { s62: pct(62.5), s65: pct(65.2), s67: pct(67.0), s69: pct(69.1), cross: T_TARGET_CROSS, success: ev ? ev.t : null };
    });
    const mid = parseInt(cu.s67[1], 10);
    check('C9 coverage counts up from zero (v1): 0% → 84%, locality to 110, visited to 92; target crossed during the count with a success sound',
      cu.s62[1] === '0%' && cu.s65[2] === '110' && mid > 0 && mid < 84 && cu.s69[0] === '84%' && cu.s69[1] === '84%' && cu.s69[3] === '92' && cu.cross > 64.7 && cu.cross < 69.0 && Math.abs(cu.success - cu.cross) < 1e-6,
      '62.5 s ' + cu.s62[1] + ' · 65.2 s lokaliti ' + cu.s65[2] + ' · 67.0 s ' + cu.s67[1] + ' · 69.1 s ' + cu.s69[1] + ' (' + cu.s69[3] + '/110) · sasaran dicapai ' + cu.cross.toFixed(3) + ' s');
    const sheet = await R.page.evaluate(() => {
      const cell = (r, k) => window.__ref('sh.c' + r + '_' + k).textContent.trim();
      window.__at(57.2); const before = [cell(0, 1), cell(1, 1)];
      window.__at(58.4); const after = [cell(0, 1), cell(1, 1)], selAfter = window.__eff(window.__ref('sh.sel'));
      const range = window.__textVisible('Hasil ACD!C8:H13', 0.98), line = window.__textVisible('Dapatan diselaraskan apabila sambungan tersedia', 0.98), demo = window.__textVisible('tiada sambungan langsung dalam demo', 0.98);
      const paths = [window.__ref('ov.fp1'), window.__ref('ov.fp2')].map(p => ({ end: p.getAttribute('marker-end') || '', start: p.getAttribute('marker-start') || '' }));
      return { before, after, selAfter, range, line, demo, paths, saved: T.h.saved, write: T.i.write };
    });
    check('C7 Sheets: "Hasil ACD!C8:H13" written after the save (P1 19/16 → 20/17), one-way arrows, write conditional on connectivity, no live call',
      sheet.before.join() === '19,16' && sheet.after.join() === '20,17' && sheet.write > sheet.saved && sheet.selAfter > 0.9 && sheet.range && sheet.line && sheet.demo &&
      sheet.paths.every(p => /flArrow/.test(p.end) && !p.start), JSON.stringify({ before: sheet.before, after: sheet.after, save: sheet.saved, write: sheet.write, range: sheet.range, line: sheet.line }));
    const sup = await R.page.evaluate(() => { window.__at(99.6); const cur = window.__eff(window.__ref('na.cursor')); window.__at(T.l.click + 0.03); const press = window.__ref('na.decBtn').classList.contains('press'); window.__at(100.5); const dec = window.__eff(window.__ref('ov.dec')); return { cur, press, dec, click: T.l.click }; });
    check('C8 the supervisor visibly selects "Rancang lawatan susulan" during cue 16 (99.01–101.75 s)', sup.cur > 0.9 && sup.press && sup.dec > 0.98 && sup.click > 99.01 && sup.click < 101.75, JSON.stringify(sup));

    /* ---------------- M. paper Borang ACD + Lampiran 1 (layout of the PKD Muallim forms) */
    const forms = await R.page.evaluate(() => {
      const f = window.__ref('man.paper').textContent.replace(/\s+/g, ' '), l = window.__ref('man.paper2').textContent.replace(/\s+/g, ' ');
      const clip = r => getComputedStyle(window.__ref(r)).clipPath;
      window.__at(4.6); const blank = ['man.f0', 'man.l0_0'].map(clip);
      window.__at(7.1);
      const written = ['man.f0', 'man.f2', 'man.f3', 'man.l0_0', 'man.l6_0', 'man.l6_5'].map(r => clip(r) === 'none');
      const ticks = [0, 1, 2].map(i => window.__ref('man.fc' + i).getAttribute('stroke-dashoffset'));
      const vis = window.__eff(window.__ref('man.paper')) > 0.98 && window.__eff(window.__ref('man.paper2')) > 0.98;
      const shown = window.__visibleText(0.3);
      return { f, l, blank, written, ticks, vis, phone: /\b0\d{1,2}[- ]?\d{7,8}\b/.test(f + l + shown), focus: T.b.write };
    });
    const formFields = ['PEJABAT KESIHATAN DAERAH MUALLIM BORANG PENGESANAN KES AKTIF (ACTIVE CASE DETECTION - ACD) DENGGI', 'BAHAGIAN A: MAKLUMAT LOKALITI & SIASATAN', 'TARIKH', 'MASA', 'NAMA ANGGOTA/NO TEL',
      'BAHAGIAN B: MAKLUMAT ISI RUMAH & SARINGAN GEJALA DENGGI', 'rujuk Lampiran 1', 'BAHAGIAN C: STATUS PEMERIKSAAN PERSEKITARAN', 'Ada takungan air berpotensi pembiakan Aedes?',
      'BAHAGIAN D: PENGESAHAN PEGAWAI DI LAPANGAN', 'Jumlah Sampel Diambil di Lapangan (jika berkaitan):', 'Diterima oleh:'];
    const lampFields = ['LAMPIRAN 1', 'Alamat / No. Rumah', '1-dilawati', '4-enggan', 'Bil. Penghuni', 'Nama dan no telefon ketua rumah/', 'Catatan Nama & No telefon (Kes Bergejala)', 'Tindakan Lapangan', 'Pendidikan Kesihatan'];
    const nz = x => x.replace(/\s+/g, '');   // line breaks in the form headings have no whitespace in textContent
    const hasF = x => nz(forms.f).includes(nz(x)), hasL = x => nz(forms.l).includes(nz(x));
    check('M1 manual scene shows the Borang ACD (Bahagian A–D) and Lampiran 1 (7 columns) as in the kit PDFs', formFields.every(hasF) && lampFields.every(hasL) && forms.vis,
      formFields.filter(x => !hasF(x)).concat(lampFields.filter(x => !hasL(x))).join(' | ') || 'semua medan ada');
    check('M2 the forms are filled by hand during 4.7–7.1 s (Bahagian A, C ticks, Lampiran rows 1–7), entries fictional, no phone numbers',
      forms.blank.every(c => c !== 'none') && forms.written.every(Boolean) && forms.ticks.every(x => x === '0') && !forms.phone, JSON.stringify({ written: forms.written, ticks: forms.ticks, phone: forms.phone }));

    /* ---------------- V. V3 hard gates */
    const gate = await R.page.evaluate(() => {
      const on = []; for (let f = 0; f <= 1457; f++) { window.renderFrame(f); if (window.__phoneOn()) on.push(f); }
      let first = -1; for (let f = 1458; f <= 1500 && first < 0; f++) { window.renderFrame(f); if (window.__phoneOn()) first = f; }
      const named = [1027, 1065, 1160, 1457].map(f => { window.renderFrame(f); return window.__phoneOn(); });
      const early = window.ACD.soundEvents().filter(e => (e.k === 'tap' || e.k === 'whoosh') && e.t < 24.3);
      return { on: on.length, first, named, early: early.length };
    });
    check('V1 phone layer (frame, shadow, badges, tap marker) hidden on every frame 0–1457; frames 1027/1065/1160/1457 hidden', gate.on === 0 && gate.named.every(v => !v), gate.on + ' frames with phone; named ' + gate.named.join(','));
    check('V2 first phone frame ≥ 1458 (00:24.30); no phone tap or reveal sound before it', gate.first >= 1458 && gate.early === 0, 'first frame ' + gate.first + ' (' + (gate.first / 60).toFixed(3) + ' s), early sounds ' + gate.early);
    const settle = await R.page.evaluate(() => { const st = t => { window.__at(t); return window.__ref('phone').style.transform + '|' + window.__ref('w.phone').style.transform; }; const a = st(25.6), b = st(28.0), c = st(32.4); window.__at(25.6); return { same: a === b && b === c, yaw: window.__yaw('phone') }; });
    check('V3 phone settled by 25.60 at a shallow three-quarter angle and still until the push-in', settle.same && Math.abs(settle.yaw) >= 8 && Math.abs(settle.yaw) <= 14, 'yaw ' + settle.yaw + '°');
    const typing = await R.page.evaluate(() => {
      const cell = () => document.querySelector('[data-ref="man.lapGrid"] [data-focus]');
      window.__at(11.85); const c = cell(), done = c.textContent === '14' && c.classList.contains('done'), lap = window.__eff(window.__ref('man.laptop'));
      window.__at(11.7); const mid = cell().textContent;
      const tf = t => { window.__at(t); return window.__ref('man').style.transform; };
      const hold = tf(11.85) === tf(12.33);
      window.__at(13.35); const title = window.__eff(window.__ref('ov.title')), impact = window.ACD.soundEvents().some(e => e.k === 'impact' && Math.abs(e.t - 13.35) < 1e-6);
      const riser = window.ACD.soundEvents().find(e => e.k === 'riser');
      const tt = t => { window.__at(t); return window.__ref('ov.title').style.transform; };
      const settled = tt(13.8) === tt(16.0);
      return { done, lap, mid, hold, title, impact, riserEnd: riser ? +(riser.t + riser.d).toFixed(3) : null, settled };
    });
    check('V4 re-typing finished by 11.85 (cell "14" complete), held to 12.33 before the clear', typing.done && typing.lap > 0.98 && typing.hold, JSON.stringify({ done: typing.done, at11_7: typing.mid, hold: typing.hold }));
    check('V5 title on screen at the 13.35 impact (riser ends there), settled by 13.80', typing.title > 0.98 && typing.impact && typing.riserEnd === 13.35 && typing.settled, JSON.stringify({ title: typing.title, impact: typing.impact, riserEnd: typing.riserEnd, settled: typing.settled }));
    const ang = await R.page.evaluate(() => {
      const at = t => { window.__at(t); return { ph: window.__yaw('phone'), dk: window.__yaw('desktop') }; };
      const tr = t => { window.__at(t); return window.__ref('phone').style.transform + '|' + window.__ref('desktop').style.transform + '|' + window.__ref('w.desk').style.transform; };
      return { entry: at(26), record: at(40), sync: at(58), joint: at(66), close: at(72), verify: at(80), complete: tr(64.5) === tr(69.5), zoom: tr(70.8) === tr(77.4) };
    });
    const inYaw = v => Math.abs(v) >= 8 && Math.abs(v) <= 14;
    check('V6 3D yaw 8–14° on the phone (entry, Sheets, joint) and monitor; frontal for reading; reveal complete by 64.50, still during the count-up, push-in still from 70.8',
      inYaw(ang.entry.ph) && ang.record.ph === 0 && inYaw(ang.sync.ph) && inYaw(ang.joint.ph) && inYaw(ang.joint.dk) && ang.close.ph === 0 && ang.verify.ph === 0 && ang.complete && ang.zoom,
      'entry ' + ang.entry.ph + '° · rekod ' + ang.record.ph + '° · Sheets ' + ang.sync.ph + '° · telefon ' + ang.joint.ph + '° / monitor ' + ang.joint.dk + '° · kad liputan ' + ang.close.ph + '° · Bahagian D ' + ang.verify.ph + '° · tetap 64.5–69.5: ' + ang.complete + ', zum tetap 70.8–77.4: ' + ang.zoom);
    const vis = r => 'return window.__eff(window.__ref("' + r + '")) >= 0.98;';
    let h = await longestRun(R.page, 49, 56, vis('ov.saved'));
    const cnt = await R.page.evaluate(() => { window.__at(50.5); const a = window.__ref('ov.savedCount').textContent; window.__at(52.5); return a + ' → ' + window.__ref('ov.savedCount').textContent; });
    check('V7 "Rekod disimpan" held ≥ 4 s from the 49.32 cue; the count updates', h.sec >= 4 && h.from <= 49.95 && cnt === '16 / 19 → 17 / 20', h.sec.toFixed(2) + ' s (' + h.from.toFixed(2) + '–' + h.to.toFixed(2) + '), ' + cnt);
    h = await longestRun(R.page, 62, 78, 'const r = window.__ref("ov.res"); return window.__eff(r) >= 0.98 && /Liputan ACD/i.test(r.textContent) && /84%/.test(r.textContent) && /92 daripada 110 premis dilawati/.test(r.textContent);');
    const pillRun = await longestRun(R.page, 70, 78, 'return window.__eff(window.__ref("ov.capai")) >= 0.98;');
    const camStill = await longestRun(R.page, 70.8, 77.4, 'const v = window.__ref("w.phone").style.transform + window.__ref("phone").style.transform; if (t === 70.8) window.__c = v; return v === window.__c;');
    check('V8 after the count-up: "84%" + "92 daripada 110 premis dilawati" + "Capai Sasaran" held to ≥ 74.86 on a still close-up', h.from <= 71.0 && h.to >= 74.86 && pillRun.from <= 71.8 && pillRun.to >= 74.86 && camStill.sec >= 6.5,
      'angka ' + h.from.toFixed(2) + '–' + h.to.toFixed(2) + ' s, pil ' + pillRun.from.toFixed(2) + '–' + pillRun.to.toFixed(2) + ' s, kamera ' + camStill.sec.toFixed(2) + ' s');
    const fu = await R.page.evaluate(() => { window.__at(85.9); const six = window.__eff(window.__ref('ov.left')) >= 0.98 && window.__textVisible('premis belum dilawati', 0.98); window.__at(90.42); const twelve = window.__eff(window.__ref('ov.lf12')) >= 0.98 && window.__ref('ov.lf12').classList.contains('hl'); return { six, twelve }; });
    check('V9 "6 premis belum dilawati" on screen by 85.90; "12 berkunci atau kosong" legible and highlighted at 90.42', fu.six && fu.twelve, JSON.stringify(fu));
    h = await longestRun(R.page, 105, 112.4, 'for (let i = 0; i < 4; i++) if (window.__eff(window.__ref("ov.bf" + i)) < 0.98) return false; return true;');
    const bf = await R.page.evaluate(() => { window.__at(108); return { titles: [0, 1, 2, 3].map(i => window.__ref('ov.bf' + i).textContent.replace(/\s+/g, ' ').trim()), proto: [0, 1, 2, 3].map(i => !!window.__ref('ov.bf' + i).querySelector('.proto-badge')) }; });
    const bfNames = ['Rekod ACD pada telefon', 'Kiraan liputan automatik', 'Pengesahan dan ringkasan', 'Perancangan lawatan susulan'];
    check('V10 four benefit cards, the last marked Prototaip Integrasi, full row held ≥ 5 s', h.sec >= 5 && bfNames.every((n, i) => bf.titles[i].includes(n)) && bf.proto.join() === 'false,false,false,true', h.sec.toFixed(2) + ' s (' + h.from.toFixed(2) + '–' + h.to.toFixed(2) + ')');
    h = await longestRun(R.page, 112.35, 119.99, 'return window.__textVisible("NADI") && window.__textVisible("Dari Survelan ke Respons Denggi") && window.__textVisible("Pejabat Kesihatan Daerah Muallim");');
    check('V11 closing lockup fully in by 113.20 and held to the final frame', h.from <= 113.2 && h.to >= 119.98, h.sec.toFixed(2) + ' s (' + h.from.toFixed(2) + '–' + h.to.toFixed(2) + ')');
    const nadiAct = await R.page.evaluate(() => { window.__at(23.5); const shown = window.__eff(window.__ref('na.openBtn')) > 0.98 && window.__textVisible('Buka Operasi ACD', 0.98); window.__at(24.12); return { shown, pressed: window.__ref('na.openBtn').classList.contains('press') || window.__ref('na.openBtn').classList.contains('done'), click: T.e.click }; });
    check('V12 NADI locality card: "Buka Operasi ACD" prototype action activated at ≈24.10, before the phone', nadiAct.shown && nadiAct.pressed && Math.abs(nadiAct.click - 24.1) < 0.05, JSON.stringify(nadiAct));

    /* ---------------- D. determinism */
    const frames = [660, 801, 1458, 2650, 3460, 3880, 5160, 6000, 7199];
    const A = await open(browser, '?render=1'), B = await open(browser, '?render=1');
    let seekSame = 0;
    for (const f of frames) { await A.page.evaluate(i => window.renderFrame(i), f); await B.page.evaluate(i => window.renderFrame(i), f); if ((await shot(A)) === (await shot(B))) seekSame++; }
    check('D1 seeking to a frame is reproducible across fresh pages', seekSame === frames.length, seekSame + '/' + frames.length + ' identical');
    const stateHash = () => { const out = []; for (const el of document.querySelectorAll('#stage *')) { if (!el.getClientRects().length) continue; let o = 1, e = el; while (e && e.id !== 'stage') { const cs = getComputedStyle(e); o *= parseFloat(cs.opacity); if (cs.visibility === 'hidden') o = 0; e = e.parentElement; } if (o <= 0.001) continue; out.push(Array.from(el.style).sort().map(k => k + ':' + el.style.getPropertyValue(k)).join(';'), Array.from(el.classList).sort().join(' '), el.getAttribute('d') || '', el.getAttribute('opacity') || '', el.getAttribute('transform') || '', el.getAttribute('stroke-dashoffset') || '', el.childElementCount ? '' : el.textContent); } return out.join('|'); };
    let stateSame = 0; const sampled = [740, 1458, 3460, 5980, 7000];
    const P1 = await open(browser, '?render=1');
    for (let f = 0; f <= 7000; f += 2) { await P1.page.evaluate(i => window.renderFrame(i), f); if (sampled.includes(f)) { const a = sha(await P1.page.evaluate(stateHash)); await B.page.evaluate(i => window.renderFrame(i), f); const b = sha(await B.page.evaluate(stateHash)); if (a === b) stateSame++; } }
    check('D2 playing to frame N gives the same visible DOM state as seeking to N', stateSame === sampled.length, stateSame + '/' + sampled.length + ' identical hashes');
    await A.ctx.close(); await B.ctx.close(); await P1.ctx.close();

    /* ---------------- E. soundtrack and narration */
    const au = await R.page.evaluate(async () => { const m = await window.ACD.audio.render(); const ev = buildSoundEvents(); return { len: m.length, sr: m.sampleRate, info: m.info, events: ev.length, kinds: [...new Set(ev.map(e => e.k))] }; });
    const n = au.info.narration;
    const nr = await R.page.evaluate(() => window.ACD.audio.narrationPcm16());
    check('E1 one resolved mix, exactly 120.000 s at 48 kHz', au.len === 120 * 48000 && au.sr === 48000, au.len + ' samples');
    check('E2 no narration: the Osman voice-over is not embedded and not in the mix (music and effects only)', n === null && nr === null && !/id="narasi-flac"/.test(html), 'narasi: ' + (n ? n.label : 'tiada') + ', blok FLAC: ' + /id="narasi-flac"/.test(html));
    check('E3 programme −16 LUFS ±0.5, peak ≤ −1.4 dBFS (look-ahead limiter)', Math.abs(au.info.mix.lufs + 16) <= 0.5 && au.info.mix.peakDb <= -1.4, au.info.mix.lufs + ' LUFS, peak ' + au.info.mix.peakDb + ' dBFS, limiter ' + au.info.mix.limiter.maxReductionDb.toFixed(2) + ' dB');
    check('E4 the score is the programme (no ducking without a voice)', au.info.bed.target === -16 && Math.abs(au.info.mix.trimDb) < 1, 'skor ' + au.info.bed.lufsIn + ' → ' + au.info.bed.target + ' LUFS, laras ' + au.info.mix.trimDb + ' dB');
    check('E5 legacy opening restored: drone + paired heartbeat + ticks + riser, impact on the title, pulse on the pin', au.kinds.includes('riser') && au.kinds.includes('impact') && au.kinds.includes('pulse') && au.kinds.includes('success') && /tension drone/.test(textOnly) && /paired, accelerating/.test(textOnly), au.events + ' events: ' + au.kinds.join(' '));
    check('E6 no browser speech synthesis in the player', !/SpeechSynthesisUtterance|speechSynthesis\.speak/.test(textOnly) && !/id="bSpeech"/.test(textOnly));
    check('E7 no page errors in render mode', R.errors.length === 0, R.errors.join(' | '));
    await R.ctx.close();

    /* ---------------- F. player controls (preview mode) */
    const U = await open(browser, '');
    const st = () => U.page.evaluate(() => window.ACD.player.state);
    const visq = sel => U.page.evaluate(s => { const e = document.querySelector(s); if (!e) return false; const cs = getComputedStyle(e); return cs.display !== 'none' && cs.visibility !== 'hidden' && parseFloat(cs.opacity) > 0.05; }, sel);
    check('F1 start overlay and controls present; no Web Speech button', (await visq('#startOverlay')) && (await visq('#controls')) && !(await U.page.$('#bSpeech')));
    await U.page.waitForFunction(() => /Sedia/.test(document.getElementById('startStatus').textContent), null, { timeout: 120000 });
    const status = await U.page.textContent('#startStatus');
    check('F2 player reports music only (no narration)', /muzik latar sahaja/.test(status), status.trim());
    await U.page.click('#startOverlay');
    await sleep(1600);
    let s = await st();
    check('F3 first click starts the soundtrack and unlocks audio (no narration)', s.playing && s.t > 1.0 && s.ctx === 'running' && s.buffer && s.audioClock && !s.narrated, JSON.stringify({ t: +s.t.toFixed(2), ctx: s.ctx, audioClock: s.audioClock, narrated: s.narrated }));
    await U.page.keyboard.press('Space'); await sleep(100);
    const p1 = await st(); await sleep(500); const p2 = await st();
    check('F4 pause holds the frame', !p1.playing && p1.t === p2.t, 't=' + p1.t.toFixed(3));
    await U.page.click('.scene-btn[data-s="4"]'); await sleep(150);
    s = await st();
    check('F5 scene jump to segment 4 lands on 00:49.000 (frame 2940)', Math.abs(s.t - 49) < 1e-6 && s.frame === 2940, 't=' + s.t + ' frame=' + s.frame);
    await U.page.evaluate(() => { const r = document.getElementById('scrub'); r.value = '4500'; r.dispatchEvent(new Event('input', { bubbles: true })); });
    s = await st();
    check('F6 scrubber seeks to frame 4500 (01:15.000)', s.frame === 4500 && Math.abs(s.t - 75) < 1e-6, 'frame=' + s.frame);
    await U.page.evaluate(() => { const r = document.getElementById('scrub'); r.value = '4440'; r.dispatchEvent(new Event('input', { bubbles: true })); });
    const subOn = await U.page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('[data-ref="subsBox"]')).opacity));
    await U.page.keyboard.press('s'); await sleep(50);
    const subOff = await U.page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('[data-ref="subsBox"]')).opacity));
    await U.page.keyboard.press('s');
    check('F7 subtitle toggle hides/shows the caption', subOn > 0.9 && subOff === 0, 'on ' + subOn + ' / off ' + subOff);
    await U.page.click('#bMute'); s = await st();
    const muteTxt = await U.page.textContent('#bMute');
    check('F8 mute sets gain 0 and relabels the button', s.muted && s.gain === 0 && /Mati/.test(muteTxt), muteTxt.trim());
    await U.page.click('#bMute');
    await U.page.keyboard.press('9'); await sleep(100); s = await st();
    check('F9 key 9 jumps to the closing at 01:52.350 (frame 6741)', s.frame === 6741, 'frame=' + s.frame);
    await U.page.click('#bRestart'); await sleep(300); s = await st();
    check('F10 restart returns to 0 and plays the mix from its start', s.playing && s.t < 0.6 && s.audioT0 === 0 && s.audioClock, 't=' + s.t.toFixed(3) + ' audioT0=' + s.audioT0);
    await U.page.evaluate(() => { const r = document.getElementById('scrub'); r.dispatchEvent(new Event('pointerdown', { bubbles: true })); r.value = '3000'; r.dispatchEvent(new Event('input', { bubbles: true })); r.dispatchEvent(new Event('pointerup', { bubbles: true })); });
    await sleep(400); s = await st();
    check('F11 a seek while playing restarts the mix at the new time (sound stays in sync)', s.playing && s.audioT0 === 50 && s.audioClock && s.t >= 50 && s.t < 51, 'audioT0=' + s.audioT0 + ' t=' + s.t.toFixed(3));
    await U.page.mouse.move(5, 5); await sleep(3000);
    check('F12 controls auto-hide during playback', await U.page.evaluate(() => document.getElementById('controls').classList.contains('hidden')));
    await U.page.keyboard.press('c'); await sleep(100);
    const cleanHidden = !(await visq('#controls')) && (await U.page.evaluate(() => getComputedStyle(document.body).cursor)) === 'none';
    await U.page.keyboard.press('Escape'); await sleep(100);
    check('F13 clean recording mode hides controls and cursor; Esc exits', cleanHidden && (await visq('#controls')));
    await U.page.keyboard.press('Space'); await sleep(50);
    await U.page.keyboard.press('ArrowRight'); s = await st();
    const tA = s.t; await U.page.keyboard.press('.'); const sB = await st();
    check('F14 keyboard seek ±1 s and single-frame step', Math.abs(sB.t - tA - 1 / 60) < 1e-6, 't ' + tA.toFixed(3) + ' → ' + sB.t.toFixed(3));
    const timeLbl = await U.page.textContent('#tTime');
    check('F15 time display shows the 02:00.00 length', /\/ 02:00\.00/.test(timeLbl), timeLbl.trim());
    check('F16 no page errors in preview mode', U.errors.length === 0, U.errors.join(' | '));
    await U.ctx.close();
  } finally { await browser.close(); }

  const w = Math.max(...results.map(r => r.name.length));
  let fail = 0;
  for (const r of results) { if (!r.ok) fail++; console.log((r.ok ? 'PASS ' : 'FAIL ') + r.name.padEnd(w) + (r.detail ? '  · ' + r.detail : '')); }
  console.log('\n' + (results.length - fail) + '/' + results.length + ' checks passed');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
