# NADI Muallim — Filem Pertandingan 120 Saat · V4 (muzik latar, tanpa narasi)

Filem 02:00.000 (1920 × 1080, 60 fps, 7,200 bingkai) untuk **Pejabat Kesihatan Daerah Muallim**. V4 ialah V3 dengan empat perubahan yang diminta:
1. suara narasi dibuang;
2. kiraan naik liputan dipulihkan;
3. animasi "capai sasaran" dipulihkan;
4. borang ACD sebenar digunakan dalam babak manual.

Semua rekod, nama, angka dan lokasi ialah **data simulasi**. Paparan e-ACD di dalam NADI dilabel **Prototaip Integrasi**. Tiada panggilan ke aplikasi langsung, Google Sheets, peta atau perkhidmatan pesanan.

## Fail V4 (untuk dihantar)

| Fail | Kegunaan |
|---|---|
| `NADI-Muallim-Pitch-120s-v4.mp4` | Filem akhir V4: H.264 High 1920 × 1080, CFR 60 fps, 7,200 bingkai, 120.000 s; AAC 48 kHz stereo. Hanya muzik latar dan kesan bunyi; tiada narasi. |
| `video-showcase-v4.html` | Pemain HTML kendiri, luar talian, dengan runut bunyi yang sama. |

**Disimpan untuk perbandingan (tidak diubah):**
- **V3 bernarasi:** `NADI-Muallim-Pitch-120s-v3.mp4`, `video-showcase-v3.html`, `sari-kata-bm-v3.srt`, `NADI-Muallim-V3-pratonton-00-30s.mp4`.
- **V2:** `NADI-Muallim-120s.mp4`, `video-showcase.html`.
- **Sumber lama:** `arkib/v2-sumber.tar.gz` dan `arkib/v3-sumber.tar.gz`.

## Perubahan V4 berbanding V3

1. **Suara narasi lelaki (Osman) dibuang.**
   - Runut bunyi kini muzik latar dan kesan bunyi asal: dron, degupan, detik jam, riser, hentakan tajuk, bunyi ketukan dan "whoosh".
   - Tanpa suara, muzik tidak lagi direndahkan; ia sendiri menjadi program pada −16 LUFS.
   - 19 baris sari kata dikekalkan sebagai **teks pada skrin**, supaya cerita masih boleh difahami tanpa suara. Dalam pemain HTML, kekunci S menyembunyikannya; MP4 tetap memaparkannya.
2. **Kiraan naik liputan ACD, seperti v1 (filem e-ACD 90 saat).** Papan pemuka telefon dan monitor bermula daripada sifar:
   - 62.7–63.9 s: premis dalam lokaliti dikira naik hingga 110.
   - 64.7–69.0 s: premis dilawati naik hingga 92, dan liputan 0% → 84%.
   - Carta bar dan donut ikut naik bersama.
3. **Animasi "capai sasaran", seperti v1.**
   - Penanda bertitik "Sasaran 80%" muncul pada bar liputan dari 63.9 s.
   - Lencana dalam aplikasi bertukar daripada "Sedang Berjalan (<80%)" kepada **"Capai Sasaran (≥80%)"** pada saat liputan melepasi 80% (~68.3 s), dengan bunyi kejayaan.
   - Kamera zum ke kad liputan telefon (69.6–70.8 s), seperti v1.
   - Panel besar "84% · 92 daripada 110 premis dilawati" muncul, diikuti pil **"Capai Sasaran"** (71.25 s) dan formula "ROUND(92 / 110 × 100) = 84% · sasaran dalam aplikasi: ≥ 80%" (71.6 s). Semuanya ditahan hingga 77.6 s.
4. **Borang manual yang betul.**
   - "Borang Pengesanan Kes Aktif (ACD) Denggi" PKD Muallim (Bahagian A–D) dan **Lampiran 1** (7 lajur, baris 1–7) dibina semula mengikut PDF kit.
   - Kedua-duanya diisi dengan tulisan tangan pada 4.7–7.1 s, dengan kamera menolak masuk supaya boleh dibaca.
   - **Isian (fiksyen):**
     - Bahagian A: tarikh 04/11/2026, masa 9.00 pagi, Kg. Ketoyong, Petugas 1–3.
     - Bahagian C: tanda ✓ pada ketiga-tiga soalan.
     - Lampiran 1: Premis Contoh 001–007, kod status (1/2/3), bilangan penghuni, tindakan lapangan (Pend. Kesihatan / Rujuk Klinik / Notis).
   - **Privasi:** lajur nama dan nombor telefon ditulis sebagai contengan yang tidak boleh dibaca. Nombor telefon petugas dibiarkan kosong. Bahagian D kosong kerana diisi di akhir operasi.
   - Tulisan tangan menggunakan fon Caveat (SIL OFL 1.1, dibenam; lesen dalam `assets/Caveat-OFL.txt`).

## Keputusan semakan V4

`node tools/check-player.js` menjalankan 59 semakan; **59/59 lulus**. Ini termasuk semua pintu V3:
- telefon tiada pada bingkai 0–1457;
- taip semula selesai 11.85 s;
- hentakan tajuk 13.35 s;
- sudut 3D;
- tulisan sehala ke Sheets;
- tahanan;
- satu set data 110 / 92 / 12 / 6 / 84%.

Semakan baharu:

| Semakan | Bukti |
|---|---|
| C6 animasi sasaran | Pada 66.5 s kedua-dua lencana "Sedang Berjalan (<80%)" dan penanda "Sasaran 80%" kelihatan. Pada 73 s lencana "Capai Sasaran (≥80%)", pil dan formula "sasaran dalam aplikasi: ≥ 80%" kelihatan. |
| C9 kiraan naik | 62.5 s: 0%; 65.2 s: lokaliti 110; 67.0 s: 45%; 69.1 s: 84% (92/110). Sasaran dicapai di tengah kiraan, dengan bunyi kejayaan pada saat yang sama. |
| M1 borang | Semua medan utama Borang ACD (Bahagian A–D) dan semua tajuk lajur Lampiran 1 ada dan kelihatan. |
| M2 isian | Tiada tulisan pada 4.6 s; semua entri (Bahagian A, tanda ✓, baris 1–7) siap pada 7.1 s; tiada corak nombor telefon. |
| E2 tanpa narasi | Tiada narasi dalam campuran dan tiada blok FLAC dalam HTML. |
| E3 kenyaringan | Program −16.0 LUFS, puncak −1.6 dBFS. |

**Render V4** (`node render-video.js --out NADI-Muallim-Pitch-120s-v4.mp4`, 10 min 29 s):
- **ffprobe:**
  - H.264 High, 1920 × 1080, yuv420p bt709, 60/1, **7,200 bingkai**, video 120.000 s.
  - AAC 48 kHz stereo, 120.000 s; bekas 120.000 s; 45.0 MB.
- **Tiada narasi dalam MP4:** audio MP4 dikorelasi dengan `narration-bm.wav` dalam 19 tetingkap kiu; korelasi maksimum hanya 0.013 (narasi akan memberi kira-kira 0.97).
- **Kenyaringan (FFmpeg ebur128):** −16.0 LUFS, LRA 3.2 LU, puncak sebenar −1.1 dBTP.
- **Bingkai MP4 berbanding HTML:** 16 bingkai disemak, termasuk borang (300/372/420), pintu telefon (1457/1458/1459) dan kiraan naik (3780/3990/4110/4164/4260/4350). PSNR 36.7–42.9 dB, iaitu beza mampatan H.264 sahaja.
- **Rangkaian:** 0 permintaan rangkaian.

## Perkara untuk perhatian (V4)

1. **Sari kata kekal pada skrin.** Ia ialah teks narasi lama, tetapi kini tanpa suara. Jika anda mahu filem tanpa teks sari kata, MP4 perlu dirender semula; dalam pemain HTML, tekan S.
2. **Dua baris sari kata masih membuat dakwaan tanpa bukti dalam pakej ini:**
   - c08 "Borang kertas tidak perlu dibawa untuk tugas ini."
   - c10 "Ini menjimatkan masa menyediakan ringkasan."

   Saya kekalkan teks asal kit. Cadangan: sediakan bukti, atau tukar kepada pernyataan tanpa dakwaan.
3. **"Capai Sasaran" ialah status dalam aplikasi**, berdasarkan ambang 80% yang ditetapkan dalam e-ACD (data simulasi). Ia bukan sasaran rasmi yang disahkan; formula pada skrin menyatakan "sasaran dalam aplikasi".
4. **Susun atur borang** disalin daripada PDF kit (teks dan struktur), bukan imej PDF itu sendiri. Saiz fon dan jarak dilaraskan sedikit supaya muat dalam bingkai.

## Bina, semak dan render (V4)

```bash
node tools/build-player.js
```

```bash
node tools/check-player.js
```

```bash
node render-video.js --out NADI-Muallim-Pitch-120s-v4.mp4
```

Selepas mux, `render-video.js` mengesahkan bahawa narasi `narration-bm.wav` **tiada** dalam MP4: korelasi bagi setiap tetingkap kiu mesti di bawah 0.15. Untuk membina semula V3 yang bernarasi, jalankan `npm run render:v3`.

## Dokumentasi V3 (bernarasi, disimpan untuk perbandingan)

Filem 02:00.000 (1920 × 1080, 60 fps, 7,200 bingkai) untuk **Pejabat Kesihatan Daerah Muallim**. V3 menggunakan narasi `narration-bm.wav` dan 19 kiu sari kata daripada kit suara. Gerakan dan muzik pembukaan diambil semula daripada filem e-ACD 90 saat.

Semua rekod, nama, angka dan lokasi ialah **data simulasi**. Paparan e-ACD di dalam NADI dilabel **Prototaip Integrasi**. Filem ini tidak membuat sebarang panggilan ke aplikasi langsung, Google Sheets, peta atau perkhidmatan pesanan.

### Fail V3 (untuk dihantar)

| Fail | Kegunaan |
|---|---|
| `NADI-Muallim-Pitch-120s-v3.mp4` | Filem akhir V3: H.264 High 1920 × 1080, CFR 60 fps, 7,200 bingkai, 120.000 s; AAC 48 kHz stereo. Mengandungi narasi, muzik dan kesan bunyi (satu campuran). |
| `video-showcase-v3.html` | Pemain HTML kendiri, luar talian. Narasi terbenam sebagai FLAC tanpa kehilangan, jadi campurannya sama dengan MP4. |
| `sari-kata-bm-v3.srt` | 19 kiu sari kata yang dipaparkan dalam filem. Teks sama dengan kit; hanya masa kiu 5/6 berubah (lihat §4). |
| `NADI-Muallim-V3-pratonton-00-30s.mp4` | Pratonton bernarasi 0–30 s untuk menyemak pembukaan, sebutan, sari kata dan keseimbangan muzik. |

**Input (dibaca sahaja):**
- `narration-bm.wav`: mono PCM 16-bit, 48 kHz, 120.000 s, sha256 `8a1bbe04fb96…`.
- `kit-suara/`: `subtitles-bm.srt`, `voiceover-script-bm.md`, `README.md`.

**V2, disimpan untuk perbandingan (tidak diubah):**
- `NADI-Muallim-120s.mp4`, `video-showcase.html`, `sari-kata-bm.srt`, `skrip-narasi-bm.md`.
- `arkib/v2-sumber.tar.gz`: sumber V2.
- `arkib/README-VIDEO-v2.md`: dokumentasi V2.

### 1. Garis masa V3

| Masa | Babak | Narasi (kiu) | Paparan dan masa penting |
|---|---|---|---|
| 00:00–00:13.2 | 1 · Pembukaan | c01 0.92–3.22<br>c02 4.03–8.69<br>c03 9.39–12.33 | Peta daerah gelap daripada filem 90 s (ilustrasi, 110 premis). Pin Kg. Ketoyong berdenyut sekali pada 0.80, diikuti tolakan perlahan. Soalan "Premis mana yang masih perlu dilawati?" muncul 0.80–4.10.<br>Fokus berpindah satu demi satu: borang (4.15), fail (5.95), kiraan manual (9.20; lakaran 9.70–10.95, "dikira" ≈ 10.81), komputer riba (10.70).<br>Kamera tolak ke satu sel 11.05–11.50. Sel "14" ditaip 11.45–11.85, ditahan hingga 12.85, kemudian set dikosongkan 12.85–13.30. Riser 9.90 → 13.35. |
| 00:13.2–00:24.3 | 2 · NADI | c04 16.94–20.54<br>c05 21.22–25.66 | Tajuk "NADI Muallim · Dari Survelan ke Respons Denggi" (gaya penutup). Hentakan 13.35, stabil 13.80.<br>Kad lokaliti Kg. Ketoyong, dengan kurang krom pelayar dan butiran GIS. Tindakan "Buka Operasi ACD" berlabel PROTOTAIP INTEGRASI diklik pada 24.10.<br>Kad hilang 24.16–24.34. |
| 00:24.3–00:49 | 3 · Rekod | c06 25.69–27.02<br>c07 33.92–38.95<br>c08 40.73–44.02 | **Telefon tidak wujud sebelum 24.30** (bingkai 1458); bingkai pertama yang kelihatan ialah 1459. Skrin pembuka "Operasi ACD · Kg. Ketoyong" (lokaliti sama).<br>Sudut tiga suku cetek (yaw −12°), stabil pada 25.60. "Cukup satu telefon untuk rekod ACD" dipaparkan 25.75–32.85.<br>Pasukan 1 · Premis Contoh 012: status, saringan gejala, rujukan dan Bahagian C. Telefon hampir hadapan untuk dibaca. |
| 00:49–01:02 | 4 · Simpan, Sheets | c09 49.32–53.63<br>c10 56.34–59.08 | Simpan 49.42. "Rekod disimpan" ditahan 49.73–54.83 (5.1 s). Kiraan Pasukan 1 berubah 16/19 → 17/20 pada 51.30.<br>Telefon → Google Apps Script → "Hasil ACD!C8:H13", satu hala. Sel diisi selepas simpan, pada 57.45. "Dapatan diselaraskan apabila sambungan tersedia". |
| 01:02–01:18 | 5 · Liputan | c11 64.93–70.69<br>c12 72.38–74.86 | Telefon (12°) dan monitor (−9°) dengan gerakan kamera 3D cetek, selesai 64.50.<br>Kad "84% liputan ACD · 92 daripada 110 premis dilawati" ditahan 64.82–77.60; carta menjadi latar sekunder. |
| 01:18–01:25 | 6 · Sahkan | c13 78.92–81.25 | Pengesahan Bahagian D (80.35) dan ringkasan statik sedia dikongsi. Tiada penghantaran WhatsApp. |
| 01:25–01:45 | 7 · Susulan | c14 85.92–87.98<br>c15 90.42–93.28<br>c16 99.01–101.75<br>c17 101.75–104.54 | Kad NADI (PROTOTAIP INTEGRASI + DATA SIMULASI). "6 premis belum dilawati" muncul pada 85.85. "12 berkunci atau kosong" ditonjolkan 90.30–93.60.<br>Penyelia mengklik "Rancang lawatan susulan" pada 99.65. "Semak semula status 12 premis" pada 102.0. |
| 01:45–01:52.35 | 8 · Manfaat | (tiada) | Empat kad:<br>• Rekod ACD pada telefon<br>• Kiraan liputan automatik<br>• Pengesahan dan ringkasan<br>• Perancangan lawatan susulan (Prototaip Integrasi)<br>Masuk dalam kira-kira 1 s; baris penuh 106.08–112.07. |
| 01:52.35–02:00 | 9 · Penutup | c18 112.90–114.02<br>c19 114.68–118.16 | Lockup penutup penuh pada 113.03, kekal hingga bingkai akhir. |

**Diambil semula daripada filem 90 saat:**
- Peta daerah gelap dengan 110 premis dan pin.
- Tetingkap Google Sheets dan nod Apps Script, termasuk anak panah satu hala dan paket data.
- Sudut 3D telefon/monitor (`perspective` + `rotateX/Y`, rata semasa membaca supaya teks tajam).
- Bunyi pembukaan: dron, degupan jantung berpasangan yang semakin laju, detik jam, riser dan hentakan.

### 2. Pintu wajib V3: keputusan semakan

`node tools/check-player.js` menjalankan 56 semakan; **56/56 lulus**. Semakan utama:

| Pintu | Bukti |
|---|---|
| Telefon tiada sebelum 00:24.30 | Lapisan telefon (bingkai, bayang, lencana, penanda sentuhan) tersembunyi pada **setiap** bingkai 0–1457, termasuk 1027, 1065, 1160 dan 1457. Bingkai pertama yang kelihatan: 1459. Tiada bunyi sentuhan atau bunyi pendedahan telefon sebelum 24.30. `renderFrame()` yang sama dipakai untuk main, lompat dan eksport. |
| Babak taip semula | Sel "14" lengkap pada 11.85 dan kamera tetap hingga 12.33. Tajuk kelihatan pada bingkai hentakan 13.35 (riser berakhir 13.35) dan stabil pada 13.80. |
| Sudut 3D | Telefon −12° (masuk), 14° (Sheets), 12° (gabungan); monitor −9°. Telefon 0° semasa borang dan Bahagian D dibaca. Gerakan selesai 64.50, kamera tetap 64.5–74.9. |
| Satu set data | 110 / 92 / 12 / 6 / 84% sama pada monitor, kad liputan, kad NADI, kad susulan dan ringkasan. Tiada angka utama semasa telefon didedahkan (24.30–33). Individu yang disaring/dirujuk dibezakan daripada kes yang dinotifikasi. |
| Sheets | Julat "Hasil ACD!C8:H13". P1 berubah 19/16 → 20/17 hanya selepas simpan. Anak panah satu hala. Tulisan bersyarat sambungan, dengan nota "tiada sambungan langsung dalam demo". |
| Tahanan | "Rekod disimpan" 5.1 s; kad 84%/92 daripada 110 dari 64.82 hingga 77.60; "6 premis" pada 85.85; "12" boleh dibaca pada 90.42; baris manfaat 5.98 s; penutup penuh 113.03. |
| Audio | Satu campuran 120.000 s. Narasi = `narration-bm.wav` (sha256 sama, sampel sama bit demi bit). Program −16.0 LUFS, puncak −1.5 dBFS. Setiap kiu ≥ 12.7 LU di atas muzik. Tiada sintesis suara pelayar. |
| Pemain | Narasi kekal segerak selepas mula semula dan lompat ketika main: campuran dimulakan semula pada masa baharu. 0 permintaan rangkaian, tiada ralat halaman. |

**Keputusan render `NADI-Muallim-Pitch-120s-v3.mp4`** (`render-video.js --voiceover narration-bm.wav`, 12 min 17 s):
- **ffprobe:**
  - H.264 High, 1920 × 1080, yuv420p bt709, 60/1 (purata 60/1), **7,200 bingkai** dinyahkod, video 120.000 s.
  - AAC 48 kHz stereo, 120.000 s; bekas 120.000 s; 41.8 MB.
- **Narasi dalam MP4:** audio MP4 dinyahkod dan dikorelasi dengan `narration-bm.wav` bagi setiap kiu: r = 0.960–0.982 untuk semua 19 kiu, sela 0.00 ms, paras narasi +2.3/+2.4 dB (sama dengan gandaan dalam halaman).
- **Kenyaringan MP4 (FFmpeg ebur128):** −16.0 LUFS, LRA 5.3 LU, puncak sebenar −1.4 dBTP.
- **Bingkai MP4 berbanding HTML:** 22 bingkai disemak, termasuk 711, 740, 801, 1027, 1065, 1160, 1457, 1458 dan 1459. PSNR 37.6–42.9 dB, iaitu beza mampatan H.264 sahaja.
- **Rangkaian:** 0 permintaan rangkaian semasa render.
- **Pratonton** `NADI-Muallim-V3-pratonton-00-30s.mp4`: 1,800 bingkai, 30.000 s; semakan narasi c01–c06 lulus.

### 3. Audio: satu campuran

`src/audio.js` mengira **satu** campuran dalam halaman. Pemain memainkan sampel ini, dan `render-video.js` mengeksport sampel yang sama ke MP4. Tiada pemprosesan kedua dalam FFmpeg selain pengekodan AAC.

- **Narasi:** `narration-bm.wav` dibenam sebagai FLAC tanpa kehilangan dan dinyahkod pada 48 kHz. Sampel yang dinyahkod sama bit demi bit dengan WAV. Dengan `--voiceover`, PCM WAV dihantar terus ke halaman dan menghasilkan campuran yang sama.
- **Pembukaan (dari filem 90 s):**
  - Dron ketegangan D2 + A2, kemudian geseran A3/Bb3.
  - Degupan berpasangan yang semakin laju dari 0.80 hingga 13.2.
  - Detik jam 4.0–13.2 dan riser 9.90 → 13.35.
  - **Hentakan dipindahkan ke tajuk pada 13.35**, kira-kira 6 dB lebih rendah daripada versi 90 s supaya tidak mengejutkan.
  - Satu "ping" mengiringi denyutan pin pada 0.80.
- **Muzik selepas itu:** pad kord D6/9 · Bm11 · Gmaj9 · Asus2, bertukar pada sempadan babak V3, dengan bes, denyut lembut, arpeggio dan kesan UI daripada jadual kiu yang sama dengan visual.
- **Paras (ITU-R BS.1770):**
  - Narasi diukur −19.87 LUFS (mono) dan diberi +1.26 dB, iaitu −15.6 LUFS sebagai stereo dwi-mono.
  - Skor dan kesan bunyi pada −19.5 LUFS, dan direndahkan **−12 dB** ketika narasi aktif (pandang depan 80 ms, tahan 250 ms, lepas 600 ms).
  - Program dilaraskan +1.12 dB ke **−16.0 LUFS**. Penghad pandang depan 5 ms dengan siling −1.5 dBFS (pengurangan maksimum 1.2 dB pada 73 puncak).
- **Keseimbangan per kiu** (narasi berbanding muzik + kesan, LU):

| Kiu | c01 | c02 | c03 | c04 | c05 | c06 | c07 | c08 | c09 | c10 |
|---|---|---|---|---|---|---|---|---|---|---|
| Beza | 17.5 | 15.0 | 12.7 | 16.8 | 16.5 | 15.8 | 16.1 | 16.8 | 15.7 | 15.9 |

| Kiu | c11 | c12 | c13 | c14 | c15 | c16 | c17 | c18 | c19 |
|---|---|---|---|---|---|---|---|---|---|
| Beza | 16.7 | 16.6 | 14.7 | 17.0 | 17.1 | 16.9 | 16.2 | 14.6 | 15.4 |

  c03 paling rapat (12.7 LU) kerana riser dan degupan sedang membina ke arah tajuk. Ini disengajakan dan masih jauh di atas paras yang menenggelamkan suara. Di celah ayat, muzik naik semula ke kira-kira −18 LUFS momentari.

### 4. Sari kata (19 kiu)

`sari-kata-bm-v3.srt` dijana daripada `src/data.js`, iaitu kiu yang sama yang memacu pemain dan MP4. Semua teks dan 17 masa sama dengan `kit-suara/subtitles-bm.srt`.

**Satu perubahan: sempadan kiu 5/6.** Kit meletakkannya pada 24.03; V3 meletakkannya pada **25.66 / 25.69**. [Keyakinan sederhana]

Mengapa sempadan 24.03 tidak sepadan dengan pertuturan dalam WAV:
- Kiu 5 ("…penyelia membuka operasi pengesanan kes aktif", kira-kira 19 suku kata) tidak muat dalam 2.81 s; ini memerlukan 6.8 suku kata/s, berbanding kira-kira 4.5–5.3 dalam kiu lain.
- Kiu 6 ("di Kampung Ketoyong", 6 suku kata) pula akan mengambil 3 s.

Asas keputusan ini:
- kiraan nukleus suku kata (16 nukleus sebelum 25.67 s);
- anggaran berkadar masa (25.70 s);
- jeda tenaga pada 25.66–25.69 s.

Jeda pada 24.14–24.18 s ialah hujung perkataan "membuka". Semakan ini **tidak** menggunakan pengecaman pertuturan (ASR); lihat §7.

Sempadan kiu lain disemak dengan WAV: mula dalam −0.05/+0.06 s, tamat 0–0.19 s lebih awal daripada hujung suara. Sempadan 16/17 (101.75) dikekalkan kerana ujiannya tidak muktamad.

### 5. Bina, semak dan render

Semua langkah berjalan luar talian. Tailwind 3.4.17 dan FFmpeg diperlukan untuk membina; Playwright 1.63.0 untuk render.

```bash
node tools/build-player.js --voiceover narration-bm.wav
```

```bash
node tools/check-player.js
```

```bash
node render-video.js --voiceover narration-bm.wav --start 0 --end 1799 --out NADI-Muallim-V3-pratonton-00-30s.mp4
```

```bash
node render-video.js --voiceover narration-bm.wav --out NADI-Muallim-Pitch-120s-v3.mp4
```

```bash
node tools/make-docs.js
```

**Selepas mux, `render-video.js` mengesahkan narasi.** Ia menyahkod audio MP4 dan mengira korelasi dengan narasi bagi setiap kiu, kemudian gagal (kod keluar 1) jika narasi tiada, terlalu perlahan atau tidak sejajar.

**Ralat yang boleh diambil tindakan.** Fail WAV tiada, bukan WAV, senyap, lebih panjang daripada 120 s, atau pemain tanpa narasi terbenam: setiap kes menghentikan eksport dengan arahan pembetulan. Gunakan `--no-narration` hanya jika eksport tanpa narasi memang dikehendaki.

### 6. Privasi dan luar talian

- **Rekod dan nama:**
  - Semua rekod ialah fiksyen.
  - Petugas dan pegawai dinamakan mengikut peranan atau "Pegawai Contoh".
  - Medan hubungan dibiarkan kosong.
- **Peta, rangkaian dan Sheets:**
  - Peta ialah ilustrasi, bukan berskala, dan dilabel "Peta ilustrasi".
  - Penyelarasan Sheets dan ringkasan WhatsApp disimulasi dalam halaman, dengan nota "tiada sambungan langsung dalam demo".
  - Pemain dibuka daripada `file://`. Semua permintaan rangkaian disekat semasa semakan dan render: **0 permintaan**.
- **Pengawal binaan:** `tools/build-player.js` menolak output yang mengandungi URL langsung, ID spreadsheet, koordinat peta atau nama sebenar kakitangan daripada aplikasi sumber.

### 7. Perkara belum selesai dan memerlukan semakan manusia

1. **Sebutan "Muallim" dan "Ketoyong" belum disahkan dengan pendengaran.** Saya tidak dapat mendengar audio, dan pemasangan ASR (Whisper) tidak dibenarkan dalam persekitaran ini. Sila dengar:
   - Pratonton 00:16.9–00:18.1: "Nadi Muallim".
   - Pratonton 00:25.7–00:27.0: "di Kampung Ketoyong".
   - Filem penuh 01:52.9–01:54.0: "NADI Muallim".
2. **Dua dakwaan dalam narasi yang dibekalkan belum disokong bukti dalam pakej ini:**
   - c08 "Borang kertas tidak perlu dibawa untuk tugas ini." (dakwaan penggantian kertas)
   - c10 "Ini menjimatkan masa menyediakan ringkasan." (dakwaan penjimatan masa)

   Audio tidak diubah. Cip visual "Tanpa borang kertas" yang pernah ditambah pada kad rekod telah **dibuang** supaya filem tidak menguatkan dakwaan itu. Sediakan bukti (contohnya ukuran masa sebenar) atau rakam semula dua baris tersebut sebelum tayangan rasmi.
3. **Sempadan kiu 5/6** dipindahkan berdasarkan analisis tenaga dan suku kata (§4). [Keyakinan sederhana] Jika anda mendengar sempadan lain, ubah `c05`/`c06` dalam `src/data.js`, kemudian bina semula dan render.
4. **Lesen suara.** Menurut README kit, narasi menggunakan suara stok "Osman" daripada FreeReadText. Terma kegunaan komersial suara itu tidak saya semak. **Ini perlu disahkan.**
5. **Data simulasi sahaja.** Angka 110 / 92 / 12 / 6 / 84% dan semua rekod adalah sintetik dan bukan dapatan operasi sebenar.

### 8. Struktur sumber

| Laluan | Kandungan |
|---|---|
| `src/data.js` | Babak V3, 19 kiu, set data simulasi, kad manfaat |
| `src/markup.js` | Pentas: peta pembukaan, set manual, NADI, telefon, monitor, Sheets/Apps Script, tindanan |
| `src/engine.js` | Garis masa V3 deterministik (`renderFrame`), kamera, peletakan 3D, pintu telefon |
| `src/audio.js` | Skor, kesan bunyi, narasi, ducking, kenyaringan, penghad: satu campuran |
| `src/player.js` | Kawalan pemain (main, lompat, babak 1–9, sari kata, bisu, mod bersih) |
| `tools/` | `build-player.js`, `check-player.js`, `make-docs.js` (`sync-narration.js` hanya untuk aliran V2) |
| `arkib/` | Sumber dan dokumentasi V2 |
