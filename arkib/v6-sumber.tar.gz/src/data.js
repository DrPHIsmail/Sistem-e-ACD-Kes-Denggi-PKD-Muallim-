/* ==========================================================================
 * data.js — single source of truth for the NADI Muallim film (V3–V6; V6 runs 134 s).
 * V6 inserts a 14-second WhatsApp sharing segment at story time 84.95 s: every beat from the
 * V5 story (engine.js T) keeps its story time; FILM time = story time + 14 s after the insert.
 * SCENES and CUES below are in film time.
 * Segment times from the V3 brief, the 19 narration cues of the supplied
 * kit (kit-suara/subtitles-bm.srt, timed to narration-bm.wav), the synthetic
 * Kg. Ketoyong scenario and the calculations copied from the e-ACD source.
 * Every figure is SYNTHETIC ("Data Simulasi"). The cue times below drive the
 * player's captions, sari-kata-bm-v3.srt and the MP4; V3 has no timing
 * override (the V2 recording-sync hook was removed).
 * ========================================================================== */

const FPS = 60;
const DURATION = 134;                // 02:14.000 (V6: 120 s story + 14 s WhatsApp insert)
const TOTAL_FRAMES = FPS * DURATION; // 8040 frames: 0 .. 8039
/* V6: the WhatsApp copy-and-paste segment is inserted at story time `at` and lasts `len` seconds;
 * the story is held at `at` meanwhile. filmTime(story) / storyTime(film) convert between the two. */
const INSERT = { at: 84.95, len: 14 };
function filmTime(ts) { return ts < INSERT.at ? ts : ts + INSERT.len; }
function storyTime(tf) { return tf < INSERT.at ? tf : tf < INSERT.at + INSERT.len ? INSERT.at : tf - INSERT.len; }

/* V3 edit anchors (seconds) from the V3 brief; the player's scene markers. */
const SCENES = [
  { id: 1, start: 0,      end: 13.2,   key: 'Pembukaan', title: 'Aliran wabak dan proses manual' },
  { id: 2, start: 13.2,   end: 24.3,   key: 'NADI',      title: 'Tajuk NADI dan kad lokaliti Kg. Ketoyong' },
  { id: 3, start: 24.3,   end: 49,     key: 'Rekod',     title: 'Satu telefon, satu rekod premis' },
  { id: 4, start: 49,     end: 62,     key: 'Simpan',    title: 'Rekod disimpan dan diselaraskan ke Sheets' },
  { id: 5, start: 62,     end: 78,     key: 'Liputan',   title: 'Telefon dan monitor: 92/110, 84%' },
  { id: 6, start: 78,     end: 84.95,  key: 'Sahkan',    title: 'Pengesahan Bahagian D' },
  { id: 7, start: 84.95,  end: 98.95,  key: 'Kongsi',    title: 'Salin dan tampal ringkasan ACD ke WhatsApp (simulasi)' },
  { id: 8, start: 98.95,  end: 118.95, key: 'Susulan',   title: 'NADI: 6 premis belum dilawati, lawatan susulan' },
  { id: 9, start: 118.95, end: 126.35, key: 'Manfaat',   title: 'Kad manfaat' },
  { id: 10, start: 126.35, end: 134,   key: 'Penutup',   title: 'Penutup' }
];

/* e-ACD locality metadata (source app state.meta). */
const META = { locality: 'Kg. Ketoyong', date: '04/11/2026 (Rabu)', time: '5.00 petang', meetingPoint: 'Surau Kg. Ketoyong (Peta)', requiredStaff: 16 };

/* Synthetic team totals (same set as the 90-second film). The followed visit is part of Pasukan 1. */
const TEAMS = {
  1: { locality: 20, visited: 17, locked: 2, pop: 61, symp: 1, ref: 1, sample: 0, breeding: 3, abate: 3, pamphlet: 17 },
  2: { locality: 18, visited: 15, locked: 2, pop: 55, symp: 0, ref: 0, sample: 0, breeding: 2, abate: 2, pamphlet: 15 },
  3: { locality: 19, visited: 16, locked: 2, pop: 58, symp: 1, ref: 1, sample: 0, breeding: 3, abate: 2, pamphlet: 16 },
  4: { locality: 17, visited: 14, locked: 2, pop: 50, symp: 0, ref: 0, sample: 0, breeding: 1, abate: 1, pamphlet: 14 },
  5: { locality: 18, visited: 15, locked: 2, pop: 56, symp: 1, ref: 1, sample: 0, breeding: 3, abate: 3, pamphlet: 15 },
  6: { locality: 18, visited: 15, locked: 2, pop: 57, symp: 0, ref: 0, sample: 0, breeding: 2, abate: 2, pamphlet: 15 }
};
const TEAM1_BEFORE = { locality: 19, visited: 16, locked: 2, pop: 56, symp: 0, ref: 0, sample: 0, breeding: 2, abate: 2, pamphlet: 16 };
const HOUSE_DEMO = {
  team: 1, address: 'Premis Contoh 012', status: '1', occupants: 5,
  symptoms: ['Demam panas mengejut', 'Sakit kepala teruk', 'Sakit sendi/tulang/otot'],
  symptomCount: 1, referredCount: 1, sampleCount: 0, breeding: true, abate: true, pamphlet: true, fieldAction: 'Rujuk Klinik Kesihatan'
};
const SYMPTOMS = ['Demam panas mengejut', 'Sakit kepala teruk', 'Sakit di belakang mata', 'Sakit sendi/tulang/otot',
  'Ruam bintik merah', 'Loya/muntah', 'Pendarahan gusi/hidung', 'Sakit perut teruk'];
const STATUS_CODES = [
  { code: '1', label: '1 - Dilawati' }, { code: '2', label: '2 - Berkunci' }, { code: '3', label: '3 - Kosong' },
  { code: '4', label: '4 - Enggan' }, { code: '6', label: '6 - Tanah/Lot Kosong' }
];
const VERIFICATION = { officerName: 'Pegawai Contoh', officerRole: 'Penolong Pegawai Kesihatan Persekitaran (PPKP)', date: '04/11/2026' };

/* ---- NADI locality card (OutbreakMap.tsx floating card), synthetic values only.
 * Kg. Ketoyong does not appear in the NADI repository's data. */
const NADI_CARD = {
  statusLabel: 'Wabak Aktif (WT)', name: 'Kg. Ketoyong', area: 'Daerah Muallim · paparan demonstrasi',
  outbreakCases: 3, cumulativeCases: 4, lastNotification: '02-11-2026', epidWeek: 44, expectedEnd: '16-11-2026', daysSince: 2,
  premisesInspected: 64, ptpP1: '03-11-2026', ptpP2: 'Tiada maklumat', srtP1: '03-11-2026', srtP2: 'Tiada maklumat'
};
/* Simulated target premises still to visit (follow-up list). */
const BENEFITS = [
  { icon: 'phoneIcon', title: 'Rekod ACD pada telefon', text: 'Satu rekod lawatan premis terus ke Lampiran 1' },
  { icon: 'sigma', title: 'Kiraan liputan automatik', text: 'Jumlah enam pasukan dan peratus liputan' },
  { icon: 'shield', title: 'Pengesahan dan ringkasan', text: 'Bahagian D dan ringkasan sedia dikongsi' },
  { icon: 'calendar', title: 'Perancangan lawatan susulan', text: 'Premis belum dilawati dipaparkan di NADI', proto: true }
];
const FOLLOW_UP = ['Premis Contoh 018', 'Premis Contoh 033', 'Premis Contoh 061', 'Premis Contoh 074', 'Premis Contoh 096', 'Premis Contoh 105'];

/* ---- calculations copied from the e-ACD source (computeTotals / calcTeamPct) */
function calcTeamPct(teamObj) {
  if (!teamObj || !teamObj.locality || teamObj.locality <= 0) return null;
  return Math.round((teamObj.visited / teamObj.locality) * 100);
}
function computeTotals(teams) {
  const totals = { locality: 0, visited: 0, locked: 0, pop: 0, symp: 0, ref: 0, sample: 0, breeding: 0, abate: 0, pamphlet: 0, activeTeams: 0 };
  for (let t = 1; t <= 6; t++) {
    const d = teams[t];
    for (const k of ['locality', 'visited', 'locked', 'pop', 'symp', 'ref', 'sample', 'breeding', 'abate', 'pamphlet']) totals[k] += Number(d[k]) || 0;
    if ((Number(d.locality) || 0) > 0 || (Number(d.visited) || 0) > 0) totals.activeTeams++;
  }
  totals.pct = totals.locality > 0 ? Math.round((totals.visited / totals.locality) * 100) : 0;
  totals.unvisited = Math.max(0, totals.locality - totals.visited - totals.locked);
  return totals;
}
const TOTALS = computeTotals(TEAMS);
const TARGET_PCT = 80; // V5: the KKM coverage target (≥ 80%), as confirmed by PKD; the e-ACD badge uses the same threshold

function buildWhatsappSummary(meta, totals) {
  return [
    '*LAPORAN RINGKASAN ACD DENGGI - PKD MUALLIM*',
    '📍 Lokaliti: ' + meta.locality,
    '📅 Tarikh/Masa: ' + meta.date + ' (' + meta.time + ')',
    '',
    '*RINGKASAN DAPATAN KESELURUHAN:*',
    '1. Jumlah Rumah/Premis dalam Lokaliti: ' + totals.locality + ' buah',
    '2. Jumlah Rumah/Premis Dilawati: ' + totals.visited + ' buah',
    '3. Jumlah Rumah/Premis Berkunci/Kosong: ' + totals.locked + ' buah',
    '4. Jumlah Penduduk Diperiksa (ACD): ' + totals.pop + ' orang',
    '5. Jumlah Kes Bergejala Dikesan: ' + totals.symp + ' orang',
    '6. Jumlah Rujukan Fasiliti Kesihatan: ' + totals.ref + ' orang',
    '7. Jumlah Sampel Diambil: ' + totals.sample + ' sampel',
    '📊 *Pencapaian ACD (%): ' + totals.pct + '%*',
    '',
    '*Pemeriksaan Persekitaran (Bahagian C):*',
    '• Takungan Berpotensi Aedes: ' + totals.breeding + ' premis',
    '• Tindakan Abate Diberi: ' + totals.abate + ' premis',
    '• Risalah Kesihatan Diedar: ' + totals.pamphlet + ' premis'
  ].join('\n');
}

/* ==========================================================================
 * NARRATION (V3) — the 19 cues of the supplied voice kit (subtitles-bm.srt),
 * spoken in narration-bm.wav. `say` is what the voice says (numbers in words),
 * `sub` is the caption (≤ 2 lines). Times are the SRT times, checked against
 * the WAV by tools/check-narration.js: every onset is within −0.05/+0.06 s of
 * its cue. One change: the SRT splits cue 5/6 at 24.03 s, but in the WAV
 * "…kes aktif | di Kampung Ketoyong" falls at 25.66–25.69 s (energy dip and
 * syllable count; 24.16 s is the end of "membuka"), so the split is moved there.
 * ========================================================================== */
const CUES = [
  { id: 'c02', scene: 1, start: 6.6,    end: 9.2,   say: 'Dalam operasi denggi, borang kertas dan fail perlu dibawa ke lapangan.', sub: 'Dalam operasi denggi, borang kertas\ndan fail perlu dibawa ke lapangan.' },
  { id: 'c03', scene: 1, start: 9.39,   end: 12.33,  say: 'Dapatan lawatan kemudian dikira dan ditaip semula.', sub: 'Dapatan lawatan kemudian dikira\ndan ditaip semula.' },
  { id: 'c04', scene: 2, start: 16.94,  end: 20.54,  say: 'Nadi Muallim memaparkan situasi denggi mengikut lokaliti.', sub: 'NADI Muallim memaparkan situasi\ndenggi mengikut lokaliti.' },
  { id: 'c05', scene: 2, start: 21.22,  end: 25.66,  say: 'Dalam prototaip ini, penyelia membuka operasi pengesanan kes aktif', sub: 'Dalam prototaip ini, penyelia membuka\noperasi pengesanan kes aktif' },
  { id: 'c06', scene: 3, start: 25.69,  end: 27.02,  say: 'di Kampung Ketoyong.', sub: 'di Kampung Ketoyong.' },
  { id: 'c07', scene: 3, start: 33.92,  end: 38.95,  say: 'Petugas merekod status premis, saringan gejala dan rujukan dengan satu telefon.', sub: 'Petugas merekod status premis, saringan\ngejala dan rujukan dengan satu telefon.' },
  { id: 'c08', scene: 3, start: 40.73,  end: 44.02,  say: 'Borang kertas tidak perlu dibawa untuk tugas ini.', sub: 'Borang kertas tidak perlu dibawa\nuntuk tugas ini.' },
  { id: 'c09', scene: 4, start: 49.32,  end: 53.63,  say: 'Selepas rekod disimpan, sistem mengira dapatan secara automatik.', sub: 'Selepas rekod disimpan, sistem\nmengira dapatan secara automatik.' },
  { id: 'c10', scene: 4, start: 56.34,  end: 59.08,  say: 'Ini menjimatkan masa menyediakan ringkasan.', sub: 'Ini menjimatkan masa\nmenyediakan ringkasan.' },
  { id: 'c11', scene: 5, start: 64.93,  end: 70.69,  say: 'Dalam simulasi ini, enam pasukan melawati sembilan puluh dua daripada seratus sepuluh premis.', sub: 'Dalam simulasi ini, enam pasukan\nmelawati 92 daripada 110 premis.' },
  { id: 'c12', scene: 5, start: 72.38,  end: 74.86,  say: 'Liputannya lapan puluh empat peratus.', sub: 'Liputannya 84 peratus.' },
  { id: 'c13', scene: 6, start: 78.92,  end: 81.25,  say: 'Pegawai merekodkan pengesahan dapatan.', sub: 'Pegawai merekodkan pengesahan dapatan.' },
  // V6: the WhatsApp segment (film time; captions only, no narration)
  { id: 'w1', scene: 7, start: 85.55,  end: 88.15,  say: 'Ringkasan laporan disalin dengan satu ketikan.', sub: 'Ringkasan laporan disalin\ndengan satu ketikan.' },
  { id: 'w2', scene: 7, start: 89.0,   end: 91.9,   say: 'Ringkasan ditampal ke kumpulan WhatsApp pasukan.', sub: 'Ringkasan ditampal ke kumpulan\nWhatsApp pasukan.' },
  { id: 'w3', scene: 7, start: 93.0,   end: 96.6,   say: 'Angka dalam mesej datang terus daripada rekod yang disimpan.', sub: 'Angka dalam mesej datang terus\ndaripada rekod yang disimpan.' },
  // from here on: V5 story time + 14 s
  { id: 'c14', scene: 8, start: 100.9,  end: 102.9,  say: 'Enam premis belum dilawati.', sub: 'Enam premis belum dilawati.' },
  { id: 'c15', scene: 8, start: 104.42, end: 107.28, say: 'Dua belas direkodkan berkunci atau kosong.', sub: 'Dua belas direkodkan berkunci\natau kosong.' },
  { id: 'c16', scene: 8, start: 109.0,  end: 111.7,  say: 'Penyelia menjadualkan lawatan ke enam premis itu', sub: 'Penyelia menjadualkan lawatan\nke enam premis itu' },
  { id: 'c17', scene: 8, start: 111.9,  end: 114.6,  say: 'dan menyemak status premis yang selebihnya.', sub: 'dan menyemak status premis\nyang selebihnya.' },
  { id: 'c18', scene: 10, start: 126.90, end: 128.02, say: 'Nadi Muallim.', sub: 'NADI Muallim.' },
  { id: 'c19', scene: 10, start: 128.68, end: 132.16, say: 'Dari survelan denggi kepada tindakan susulan di lapangan.', sub: 'Dari survelan denggi kepada\ntindakan susulan di lapangan.' }
];
/* cue times exactly as supplied in kit-suara/subtitles-bm.srt (for the audit trail) */
const SRT_SUPPLIED = { c05: [21.22, 24.03], c06: [24.03, 27.02] };
const PLANNED = CUES.map(c => ({ id: c.id, start: c.start, end: c.end }));

/* V4: the paper Borang ACD and Lampiran 1 in the manual scene (layout of the PKD Muallim forms,
 * kit PDFs), filled by hand with FICTIONAL entries. Staff appear as roles; the household-head and
 * symptomatic-case name/phone columns are illegible scribbles, so no personal data is shown. */
const PAPER_FORM = { tarikh: '04/11/2026', masa: '9.00 pagi', lokaliti: 'Kg. Ketoyong', petugas: ['Petugas 1', 'Petugas 2', 'Petugas 3'] };
const PAPER_ROWS = [
  { alamat: 'Premis Contoh 001', status: '1', penghuni: '4', nama: 1, kes: 0, tindakan: 'Pend. Kesihatan' },
  { alamat: 'Premis Contoh 002', status: '1', penghuni: '5', nama: 1, kes: 1, tindakan: 'Rujuk Klinik' },
  { alamat: 'Premis Contoh 003', status: '2', penghuni: '-', nama: 0, kes: 0, tindakan: 'Notis' },
  { alamat: 'Premis Contoh 004', status: '1', penghuni: '3', nama: 1, kes: 0, tindakan: 'Pend. Kesihatan' },
  { alamat: 'Premis Contoh 005', status: '3', penghuni: '-', nama: 0, kes: 0, tindakan: 'Notis' },
  { alamat: 'Premis Contoh 006', status: '1', penghuni: '6', nama: 1, kes: 0, tindakan: 'Pend. Kesihatan' },
  { alamat: 'Premis Contoh 007', status: '1', penghuni: '2', nama: 1, kes: 0, tindakan: 'Pend. Kesihatan' }
];

/* V3: cue times come from the supplied SRT (checked against the WAV), not from a sync tool. */
/* V5 (music only): the kit captions stay as on-screen text. c01 (the supervisor's question) now heads the
 * follow-up flow instead of opening the film; c02, c14, c16 and c17 are retimed to the new visual beats. */
const NARRATION_SOURCE = 'kit-suara/subtitles-bm.srt (V5 on-screen text, retimed)';
/* V5 · 00:00–00:06.5 the opening flow chart */
const FLOW_STEPS = [
  { icon: 'bell', tone: 'teal', title: 'Notifikasi diterima', sub: 'Kes denggi dinotifikasi kepada PKD' },
  { icon: 'trend', tone: 'amber', title: 'Peningkatan kes', sub: 'Kes bertambah di Kg. Ketoyong' },
  { icon: 'alert', tone: 'rose', title: 'Isytihar wabak', sub: 'Lokaliti diisytihar wabak aktif' },
  { icon: 'house', tone: 'go', title: 'Pengesanan Kes Aktif (ACD)', sub: 'Lawatan rumah ke rumah di lokaliti wabak' }
];

/* Narration per scene (one take per scene). */
const NARRATION = SCENES.filter(s => CUES.some(c => c.scene === s.id)).map(s => {
  const cs = CUES.filter(c => c.scene === s.id);
  return { id: 'N' + s.id, scene: s.id, cues: cs.map(c => c.id), start: cs[0].start, end: cs[cs.length - 1].end, say: cs.map(c => c.say).join(' ') };
});

if (typeof module !== 'undefined') {
  module.exports = { FPS, DURATION, TOTAL_FRAMES, INSERT, filmTime, storyTime, SCENES, SRT_SUPPLIED, BENEFITS, PAPER_FORM, PAPER_ROWS, FLOW_STEPS, META, TEAMS, TEAM1_BEFORE, TOTALS, TARGET_PCT, HOUSE_DEMO, SYMPTOMS, STATUS_CODES,
    VERIFICATION, NADI_CARD, FOLLOW_UP, CUES, PLANNED, NARRATION, calcTeamPct, computeTotals, buildWhatsappSummary,
    get NARRATION_SOURCE() { return NARRATION_SOURCE; } };
}
