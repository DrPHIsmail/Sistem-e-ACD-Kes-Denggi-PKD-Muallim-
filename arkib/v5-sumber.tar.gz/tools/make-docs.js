#!/usr/bin/env node
/* Writes sari-kata-bm-v5.srt from src/data.js — the on-screen caption cues of the current film
 * (V5: 18 kit captions as text, retimed; c01 now heads the follow-up flow) — and reports every
 * difference from the supplied kit-suara/subtitles-bm.srt. The V3 SRT is left untouched. */
'use strict';
const fs = require('fs');
const path = require('path');
const D = require('../src/data.js');
const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'sari-kata-bm-v5.srt');
const KIT = path.join(ROOT, 'kit-suara', 'subtitles-bm.srt');

const srt = s => { const ms = Math.round(s * 1000), h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, sec = Math.floor(ms / 1000) % 60; return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0') + ',' + String(ms % 1000).padStart(3, '0'); };
let out = '';
D.CUES.forEach((c, i) => { out += (i + 1) + '\n' + srt(c.start) + ' --> ' + srt(c.end) + '\n' + c.sub + '\n\n'; });
fs.writeFileSync(OUT, out);
console.log('wrote ' + path.basename(OUT) + ' (' + D.CUES.length + ' cues)');
if (fs.existsSync(KIT)) {
  // compare by cue id (cNN ↔ kit cue NN), so a removed cue does not shift the comparison
  const kit = fs.readFileSync(KIT, 'utf8').replace(/\r/g, '').trim().split(/\n\n+/).map(b => { const l = b.split('\n'); return { time: l[1], text: l.slice(2).join('\n') }; });
  let diffs = 0;
  kit.forEach((k, i) => {
    const c = D.CUES.find(q => q.id === 'c' + String(i + 1).padStart(2, '0'));
    if (!c) { diffs++; console.log('  kit cue ' + (i + 1) + ' (' + k.time + ') not shown as a caption'); return; }
    const time = srt(c.start) + ' --> ' + srt(c.end);
    if (time === k.time && c.sub === k.text) return;
    diffs++;
    console.log('  ' + c.id + ': ' + k.time + '  →  ' + time + (c.sub !== k.text ? '  (text differs)' : '  (time only)'));
  });
  console.log(diffs ? diffs + ' cue(s) differ from kit-suara/subtitles-bm.srt' : 'identical to kit-suara/subtitles-bm.srt');
}
