#!/usr/bin/env node
/* Builds the self-contained V3 player video-showcase-v3.html from src/
 * (the V2 player video-showcase.html is left untouched for comparison):
 *   1. compiles Tailwind 3.4.17 utilities used by the mockups (offline),
 *   2. inlines Inter, Plus Jakarta Sans, JetBrains Mono (woff2, OFL) and the
 *      Jata Negara PNG as data URIs,
 *   3. embeds the supplied narration (narration-bm.wav) losslessly as FLAC in
 *      a non-executed <script type="application/octet-stream"> block; the page
 *      decodes it and builds one resolved mix (narration + ducked score),
 *   4. concatenates data → markup → engine → audio → player into one <script>,
 *   5. refuses to write the file if live URLs, the spreadsheet ID, map
 *      coordinates or real staff names from the source apps leak into it.
 * Usage: node tools/build-player.js [--voiceover narration-bm.wav] [--no-narration] [--out video-showcase-v3.html]
 *        (needs tailwindcss: npm install, or TAILWIND_BIN=/path/to/tailwindcss; needs ffmpeg for the FLAC step)
 */
'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'src');
const ASSETS = path.join(ROOT, 'assets');
const ARGS = process.argv.slice(2);
const argVal = (k, d) => { const i = ARGS.indexOf(k); return i >= 0 && i + 1 < ARGS.length ? ARGS[i + 1] : d; };
const OUT = path.resolve(ROOT, argVal('--out', 'video-showcase-v3.html'));
const VOICE = ARGS.includes('--no-narration') ? null : path.resolve(ROOT, argVal('--voiceover', 'narration-bm.wav'));
const FFMPEG = process.env.FFMPEG_PATH || 'ffmpeg';
if (path.basename(OUT) === 'video-showcase.html') throw new Error('video-showcase.html is the V2 export kept for comparison; choose another --out name');

function tailwindBin() {
  const cands = [process.env.TAILWIND_BIN, path.join(ROOT, 'node_modules', '.bin', 'tailwindcss')].filter(Boolean);
  for (const c of cands) if (fs.existsSync(c)) return c;
  throw new Error('tailwindcss not found. Run "npm install" (devDependency tailwindcss@3.4.17) or set TAILWIND_BIN.');
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'eacd-build-'));
const cssOut = path.join(tmp, 'styles.css');
execFileSync(tailwindBin(), ['-c', path.join(__dirname, 'tailwind.config.js'), '-i', path.join(SRC, 'styles.css'), '-o', cssOut, '--minify'], { stdio: ['ignore', 'ignore', 'inherit'] });
let css = fs.readFileSync(cssOut, 'utf8');
// keep Tailwind's MIT attribution banner, minus the URL scheme (the output must contain no URLs at all)
css = css.replace(/https:\/\/tailwindcss\.com/g, 'tailwindcss.com');
const fonts = {
  __FONT_400__: 'Inter-Regular', __FONT_500__: 'Inter-Medium', __FONT_600__: 'Inter-SemiBold', __FONT_700__: 'Inter-Bold', __FONT_800__: 'Inter-ExtraBold',
  __PJS_400__: 'PlusJakartaSans-400', __PJS_500__: 'PlusJakartaSans-500', __PJS_600__: 'PlusJakartaSans-600', __PJS_700__: 'PlusJakartaSans-700', __PJS_800__: 'PlusJakartaSans-800',
  __JBM_400__: 'JetBrainsMono-Regular', __JBM_600__: 'JetBrainsMono-SemiBold', __JBM_700__: 'JetBrainsMono-Bold'
};
for (const [ph, f] of Object.entries(fonts)) {
  if (css.split(ph).length !== 2) throw new Error('expected one ' + ph + ' placeholder in CSS');
  css = css.replace(ph, fs.readFileSync(path.join(ASSETS, f + '.woff2')).toString('base64'));
}
if (/__(FONT|PJS|JBM)_\d+__/.test(css)) throw new Error('font placeholder left in CSS');

const order = ['data.js', 'markup.js', 'engine.js', 'audio.js', 'player.js'];
let js = order.map(f => '/* ---- ' + f + ' ---- */\n' + fs.readFileSync(path.join(SRC, f), 'utf8')).join('\n');
// V3: caption cues are the 19 kit cues in src/data.js (no recording-sync override)
console.log('cues: 19 from src/data.js (kit-suara/subtitles-bm.srt; c05/c06 split at the 25.66 s pause)');
const jata = 'data:image/png;base64,' + fs.readFileSync(path.join(ASSETS, 'jata-negara.png')).toString('base64');
if ((js.match(/__JATA__/g) || []).length !== 1) throw new Error('expected exactly one __JATA__ placeholder');
js = js.replace('__JATA__', jata);

let html = fs.readFileSync(path.join(SRC, 'template.html'), 'utf8');
html = html.replace('/*__CSS__*/', () => css).replace('/*__JS__*/', () => js);

// narration: the supplied WAV, losslessly re-packed as FLAC (no metadata)
let voiceBlock = '';
if (VOICE) {
  if (!fs.existsSync(VOICE)) throw new Error('Narration file not found: ' + VOICE + '\n  Put narration-bm.wav (mono/stereo PCM WAV, 120.000 s) in the project folder, pass --voiceover <file>, or build a silent-narration player with --no-narration.');
  const wav = fs.readFileSync(VOICE);
  if (wav.toString('ascii', 0, 4) !== 'RIFF' || wav.toString('ascii', 8, 12) !== 'WAVE') throw new Error('Narration file is not a RIFF/WAVE file: ' + VOICE);
  const sha = require('crypto').createHash('sha256').update(wav).digest('hex');
  const flac = path.join(tmp, 'narasi.flac');
  try { execFileSync(FFMPEG, ['-hide_banner', '-loglevel', 'error', '-y', '-i', VOICE, '-map_metadata', '-1', '-fflags', '+bitexact', '-flags:a', '+bitexact', '-c:a', 'flac', '-compression_level', '12', flac]); }
  catch (e) { throw new Error('FFmpeg could not convert the narration to FLAC (' + (e.message || e) + '). Install FFmpeg or set FFMPEG_PATH.'); }
  const b64 = fs.readFileSync(flac).toString('base64');
  voiceBlock = '<script type="application/octet-stream" id="narasi-flac" data-file="' + path.basename(VOICE) + '" data-sha256="' + sha + '">' + b64 + '</script>\n';
  console.log('narration: ' + path.basename(VOICE) + ' (sha256 ' + sha.slice(0, 12) + '…) embedded as FLAC, ' + (b64.length / 1048576).toFixed(2) + ' MB base64');
} else console.log('narration: none (--no-narration)');
if (html.split('<!--__NARASI__-->').length !== 2) throw new Error('expected one <!--__NARASI__--> placeholder in template.html');
html = html.replace('<!--__NARASI__-->', () => voiceBlock);

// privacy / offline guards
const forbidden = [
  /https?:\/\//i, /script\.google/i, /google\.com\/maps/i, /3\.6993145/, /101\.510945/,
  /1w9P5Ikuv3gI312b_LhnG2Ko6VbHJr6j2NZEHVmpr8t8/,
  /LOGESVARAN|KUMARASAMY|SHAHIRAN|KHAIRULLAH|SOMUSUNDARAM|NAZREEN|SAIFUL BIN|HARTINI|IRDAWATY|SURYANI|AFZAN|NURUL DIANA|SAFIYYAH|HAPIZAH|AZLIN BINTI|AZRI A\/L/i
];
// binary payloads (fonts, image, FLAC) are base64 and cannot carry readable text; test everything else
const textOnly = html.replace(/[A-Za-z0-9+\/=]{400,}/g, '');
for (const re of forbidden) {
  const m = textOnly.match(re);
  if (m) throw new Error('forbidden content in output: ' + re + ' near "' + textOnly.substr(Math.max(0, m.index - 40), 100) + '"');
}
fs.writeFileSync(OUT, html);
fs.rmSync(tmp, { recursive: true, force: true });
console.log('wrote ' + path.relative(process.cwd(), OUT) + ' (' + (fs.statSync(OUT).size / 1024).toFixed(0) + ' KB)');
