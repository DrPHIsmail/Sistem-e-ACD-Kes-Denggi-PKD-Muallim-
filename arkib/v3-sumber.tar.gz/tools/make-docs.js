#!/usr/bin/env node
/* V3: writes sari-kata-bm-v3.srt from src/data.js — the 19 cues that drive the captions in
 * video-showcase-v3.html and NADI-Muallim-Pitch-120s-v3.mp4 — and reports every difference
 * from the supplied kit-suara/subtitles-bm.srt (expected: only the c05/c06 split). */
'use strict';
const fs = require('fs');
const path = require('path');
const D = require('../src/data.js');
const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'sari-kata-bm-v3.srt');
const KIT = path.join(ROOT, 'kit-suara', 'subtitles-bm.srt');

const srt = s => { const ms = Math.round(s * 1000), h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, sec = Math.floor(ms / 1000) % 60; return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0') + ',' + String(ms % 1000).padStart(3, '0'); };
let out = '';
D.CUES.forEach((c, i) => { out += (i + 1) + '\n' + srt(c.start) + ' --> ' + srt(c.end) + '\n' + c.sub + '\n\n'; });
fs.writeFileSync(OUT, out);
console.log('wrote ' + path.basename(OUT) + ' (' + D.CUES.length + ' cues)');
if (fs.existsSync(KIT)) {
  const kit = fs.readFileSync(KIT, 'utf8').replace(/\r/g, '').trim().split(/\n\n+/), mine = out.trim().split(/\n\n+/);
  let diffs = 0;
  kit.forEach((b, i) => {
    if (b === mine[i]) return;
    diffs++;
    const [ka, kb] = [b.split('\n'), (mine[i] || '').split('\n')];
    console.log('  differs from the kit at cue ' + (i + 1) + ': ' + ka[1] + '  →  ' + kb[1] + (ka.slice(2).join(' ') !== kb.slice(2).join(' ') ? '  (text differs)' : '  (time only)'));
  });
  console.log(diffs ? diffs + ' cue(s) differ from kit-suara/subtitles-bm.srt' : 'identical to kit-suara/subtitles-bm.srt');
}
