/* ==========================================================================
 * engine.js — deterministic timeline for the 120-second NADI Muallim film.
 * renderFrame(frameIndex) is a pure function of the frame number
 * (t = frameIndex / 60): it recomputes every animated property from t, so
 * seeking to a frame and playing up to it give the same pixels. No CSS
 * transitions or animations, no Math.random().
 *
 * Each device sits on its own world layer with its own camera, so a shot can
 * dissolve to the next one independently. After every important action the
 * camera holds still so the result can be read; one element carries the
 * visual focus at a time.
 * ========================================================================== */
'use strict';

/* ---------------------------------------------------------------- math */
const clamp = (x, a = 0, b = 1) => (x < a ? a : x > b ? b : x);
const lerp = (a, b, p) => a + (b - a) * p;
function makeOutBack(s) { return p => 1 + (s + 1) * Math.pow(p - 1, 3) + s * Math.pow(p - 1, 2); }
/* Analytic damped spring, normalised so f(0)=0 and f(1)=1 (subtle overshoot). */
function makeSpring(zeta, w) {
  const wd = w * Math.sqrt(1 - zeta * zeta);
  const f = p => 1 - Math.exp(-zeta * w * p) * (Math.cos(wd * p) + (zeta * w / wd) * Math.sin(wd * p));
  const end = f(1);
  return p => (p <= 0 ? 0 : p >= 1 ? 1 : f(p) / end);
}
const E = {
  lin: p => p,
  outQuad: p => 1 - (1 - p) * (1 - p),
  inQuad: p => p * p,
  inCubic: p => p * p * p,
  outCubic: p => 1 - Math.pow(1 - p, 3),
  inOutCubic: p => (p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2), // as Motion Canvas easeInOutCubic
  outQuart: p => 1 - Math.pow(1 - p, 4),
  inOutSine: p => -(Math.cos(Math.PI * p) - 1) / 2,
  outBack: makeOutBack(1.25),
  spring: makeSpring(0.62, 11),
  springSoft: makeSpring(0.78, 10)
};
/* progress of t through [t0, t1] with easing; 0 before, 1 after */
function seg(t, t0, t1, e) { if (t <= t0) return 0; if (t >= t1) return 1; return (e || E.inOutCubic)((t - t0) / (t1 - t0)); }
/* in a→b, hold, out c→d */
function win(t, a, b, c, d, ein, eout) { return Math.min(seg(t, a, b, ein || E.outCubic), 1 - seg(t, c, d, eout || E.inCubic)); }
function mix(a, b, p) {
  if (typeof a === 'number') return lerp(a, b, p);
  const o = {}; for (const k in a) o[k] = lerp(a[k], b[k] === undefined ? a[k] : b[k], p); return o;
}
/* keyframes: [[time, value, easingIntoThisKey?], ...] */
function kf(t, keys) {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    if (t < keys[i][0]) {
      const k0 = keys[i - 1], k1 = keys[i];
      return mix(k0[1], k1[1], (k1[2] || E.inOutCubic)((t - k0[0]) / (k1[0] - k0[0])));
    }
  }
  return keys[keys.length - 1][1];
}
/* step keyframes (constant interpolation): [[time, value], ...] */
function step(t, keys) { let v = keys[0][1]; for (const [k, val] of keys) { if (t >= k) v = val; } return v; }

/* ---------------------------------------------------------------- seeded randomness */
function mulberry32(a) {
  return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function hashStr(s) { let h = 2166136261 >>> 0; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
const rng = seed => mulberry32(typeof seed === 'string' ? hashStr(seed) : seed);

/* ---------------------------------------------------------------- DOM helpers (cached writes) */
const $ = {};
function collectRefs(root) { root.querySelectorAll('[data-ref]').forEach(el => { $[el.dataset.ref] = el; }); }
function css(el, prop, val) { const c = el.__s || (el.__s = {}); if (c[prop] !== val) { el.style.setProperty(prop, val); c[prop] = val; } }
function tf(el, v) { css(el, 'transform', v); }
function op(el, v) { css(el, 'opacity', (Math.round(clamp(v) * 1000) / 1000).toString()); }
function vis(el, on) { css(el, 'display', on ? '' : 'none'); }
function txt(el, s) { if (el.__t !== s) { el.textContent = s; el.__t = s; } }
function html(el, s) { if (el.__h !== s) { el.innerHTML = s; el.__h = s; } }
function cls(el, c, on) { const k = '__c' + c; if (el[k] !== on) { el.classList.toggle(c, !!on); el[k] = on; } }
function attr(el, a, v) { const k = '__a' + a; if (el[k] !== v) { el.setAttribute(a, v); el[k] = v; } }
const px = v => (Math.round(v * 100) / 100) + 'px';
const r2 = v => Math.round(v * 1000) / 1000;

/* ==========================================================================
 * NAMED TIME EVENTS (seconds) — the beat sheet. Visual states, taps, typing,
 * camera holds and sound cues all read from here. Segment boundaries follow
 * SCENES in data.js (00:00, 00:12, 00:28, 01:02, 01:24, 01:43, 01:54).
 * ========================================================================== */
const T = {
  s1: { click: 1.75, cardIn: [1.85, 2.25], push: [3.1, 4.4], q: [6.55, 6.85, 11.65, 11.95] },
  s2: { setIn: [11.7, 12.0, 12.3], tags: [12.55, 13.35, 15.75, 16.55], write: [12.5, 15.3], tally: [15.8, 16.95], typing: [16.75, 19.0],
        shrink: [17.0, 17.8], rise: [17.0, 17.8], tapIcon: 18.05, launch: [18.15, 18.8], appIn: [18.75, 18.95], tapNew: 19.35, borang: 19.5,
        setOut: [19.3, 20.0], one: [19.75, 20.15, 27.6, 27.95] },
  s3: { zoom: [28.0, 28.8], tapTeam: 28.95, pickTeam: 29.55, tapAddr: 30.0, type: [30.1, 31.2], tapStatus: 31.75, occ: [33.0, 33.35, 33.7, 34.05],
        toB: [37.3, 38.1], toggle: 38.75, chips: [39.55, 40.1, 40.65], hlSymp: 40.95, hlRef: 42.3, toC: [47.3, 48.1], cb0: 48.85, cb1: 49.65,
        hlRis: 50.45, hlAct: 51.5, save: 56.9, saved: 57.05, pull: [57.25, 58.05], rec: [31.3, 34.45, 42.55, 50.85, 51.95], recWin: [28.6, 29.0, 61.75, 62.1] },
  s4: { dissolve: [61.75, 62.05, 62.4], cols: [62.9, 63.45, 64.0, 64.55, 65.1, 65.65], tot: 66.2, move: [66.7, 67.6], res: [67.75, 68.05, 83.3, 83.65] },
  s5: { dissolve: [83.7, 84.0, 84.35], tapName: 84.45, type: [84.55, 85.25], tapVerify: 85.65, ver: [85.8, 86.0, 90.2, 90.4], cut: 90.4, tapWa: 91.15,
        chat: [92.45, 92.85], cam: [92.6, 93.3], paste: 93.4, jimat: [95.55, 95.95, 102.6, 102.95] },
  s6: { dissolve: [102.7, 103.0, 103.35], expand: [103.5, 104.15], left: [104.4, 104.75, 113.6, 113.95], cursor: [108.9, 109.85], click: 110.05, planned: [110.2, 110.5], marks: 110.35 },
  s7: { in: [113.75, 114.35], title: 114.0 }
};

/* ---------------------------------------------------------------- layout constants (world px) */
const PH = { x: 1330, y: 540, s: 0.95 };      // phone centre and scale
const DK = { x: 960, y: 560 };                // desktop monitor centre
const NW = { x: 960, y: 540, s: 1.36 };       // NADI browser window centre and scale
const NADI_W = 1280, NADI_H = 756;            // window incl. 36 px chrome bar
const PH_SCREEN_W = 390, PH_SCREEN_H = 842;
const DK_S = 0.86545;                         // desktop app scale inside the monitor
const KET = { x: 830, y: 222 };               // Kg. Ketoyong centroid on the illustrative map (map px)
const FOLLOW_POS = [[30, 50], [75, 46], [120, 52], [160, 44], [200, 50], [345, 47]]
  .map(([a, r]) => ({ x: KET.x + Math.cos(a * Math.PI / 180) * r, y: KET.y + Math.sin(a * Math.PI / 180) * r }));

/* ---------------------------------------------------------------- dashboard data over time */
const TEAMS_BEFORE = (() => { const o = {}; for (let k = 1; k <= 6; k++) o[k] = Object.assign({}, TEAMS[k]); o[1] = Object.assign({}, TEAM1_BEFORE); return o; })();
const TOTALS_BEFORE = computeTotals(TEAMS_BEFORE);
/* the followed record joins Pasukan 1 when it is saved (source: locality +1, visited +1) */
function teamsAt(t) { return t < T.s3.saved ? TEAMS_BEFORE : TEAMS; }

/* ---------------------------------------------------------------- interactions */
const TAPS = [
  { t: T.s2.tapIcon, ref: 'ph.newIcon', layer: 'home' },
  { t: T.s2.tapNew, ref: 'ph.btnNew' },
  { t: T.s3.tapTeam, ref: 'ph.teamSel' }, { t: T.s3.pickTeam, ref: 'ph.dd1' },
  { t: T.s3.tapAddr, ref: 'ph.addrBox', ax: 0.3 }, { t: T.s3.tapStatus, ref: 'ph.pill1' },
  ...T.s3.occ.map(t => ({ t, ref: 'ph.occPlus' })),
  { t: T.s3.toggle, ref: 'ph.toggle' },
  { t: T.s3.chips[0], ref: 'ph.chip0' }, { t: T.s3.chips[1], ref: 'ph.chip1' }, { t: T.s3.chips[2], ref: 'ph.chip3' },
  { t: T.s3.cb0, ref: 'ph.cb0' }, { t: T.s3.cb1, ref: 'ph.cb1' },
  { t: T.s3.save, ref: 'ph.saveBtn' },
  { t: T.s5.tapName, ref: 'ph.vNameBox', ax: 0.3 }, { t: T.s5.tapVerify, ref: 'ph.vBtn' },
  { t: T.s5.tapWa, ref: 'ph.btnWa' }
];
const TYPING = [
  { t0: T.s3.type[0], t1: T.s3.type[1], text: HOUSE_DEMO.address },
  { t0: T.s5.type[0], t1: T.s5.type[1], text: VERIFICATION.officerName }
];
function typed(t, k) { const ty = TYPING[k]; const n = Math.floor(seg(t, ty.t0, ty.t1, E.lin) * ty.text.length + 1e-6); return ty.text.slice(0, n); }
/* NADI mouse: select the locality (segment 1), take the follow-up decision (segment 6) */
const NCUR = [
  { from: [560, 430], t0: 0.75, t1: 1.6, click: T.s1.click, out: [2.2, 2.5], target: () => ({ x: KET.x, y: KET.y }) },
  { from: [690, 330], t0: T.s6.cursor[0], t1: T.s6.cursor[1], click: T.s6.click, out: [110.6, 110.9], target: t => decBtnMap(t) }
];
/* Supervisor-facing system label, top left */
const SYS = [
  [4.5, 11.75, 'NADI Muallim', 'Peta lokaliti · paparan demonstrasi'],
  [18.9, 61.85, 'e-ACD Denggi', 'Telefon petugas'],
  [62.3, 83.75, 'e-ACD Denggi', 'Papan pemuka · 6 pasukan'],
  [84.2, 102.75, 'e-ACD Denggi', 'Telefon petugas'],
  [103.2, 113.85, 'NADI Muallim', 'Prototaip integrasi e-ACD']
];

/* ---------------------------------------------------------------- sound event table (shared with audio.js) */
function buildSoundEvents() {
  const ev = [];
  const add = (t, k, o) => ev.push(Object.assign({ t, k }, o || {}));
  // 1 · NADI: the supervisor's question
  add(T.s1.click, 'click'); add(T.s1.cardIn[0], 'pop', { soft: 1 }); add(T.s1.push[0] + 0.1, 'whooshSoft'); add(T.s1.q[0] + 0.2, 'swell');
  // 2 · paper, tally and re-entry → one phone
  add(T.s2.setIn[1], 'whoosh');
  T.s2.tags.forEach((t, i) => (i < 2 ? add(t, 'paper') : add(t, 'pop', { soft: 1, f: 520 + i * 60 })));
  for (let r = 0; r < 12; r++) add(T.s2.write[0] + r * 0.23, 'pencil');
  for (let i = 0; i < 24; i++) add(T.s2.tally[0] + i * ((T.s2.tally[1] - T.s2.tally[0]) / 24), 'pencil');
  for (let i = 0; i < 30; i++) add(T.s2.typing[0] + i * ((T.s2.typing[1] - T.s2.typing[0]) / 30), 'key', { soft: 1 });
  add(T.s2.rise[0] + 0.1, 'whoosh'); add(T.s2.launch[0], 'whooshSoft'); add(T.s2.one[0] + 0.15, 'swell');
  // 3 · one record
  add(T.s3.zoom[0] + 0.1, 'whooshSoft');
  T.s3.rec.forEach(t => add(t, 'pop', { soft: 1, f: 620 }));
  add(T.s3.saved, 'confirm'); add(T.s3.pull[0] + 0.05, 'whooshSoft');
  // 4 · six teams summed
  add(T.s4.dissolve[1], 'whoosh');
  T.s4.cols.forEach((t, i) => add(t, 'blip', { f: 1300 + i * 110 }));
  add(T.s4.tot, 'success'); add(T.s4.move[0] + 0.1, 'whooshSoft'); add(T.s4.res[0] + 0.05, 'hit');
  // 5 · verification and the shared summary
  add(T.s5.dissolve[1], 'whooshSoft'); add(T.s5.tapVerify + 0.12, 'confirm');
  add(T.s5.cut, 'whooshSoft'); add(T.s5.tapWa + 0.12, 'pop', { soft: 1 }); add(T.s5.chat[0], 'slide'); add(T.s5.paste, 'paste');
  add(T.s5.jimat[0] + 0.15, 'swell');
  // 6 · NADI: the supervisor's decision
  add(T.s6.dissolve[1], 'whoosh'); add(T.s6.expand[0] + 0.1, 'pop', { soft: 1 }); add(T.s6.left[0] + 0.1, 'hit', { soft: 1 });
  add(T.s6.click, 'click'); add(T.s6.planned[0], 'confirm');
  for (let i = 0; i < 6; i++) add(T.s6.marks + i * 0.1, 'blip', { f: 1500 + i * 90, soft: 1 });
  // 7 · closing
  add(T.s7.title + 0.05, 'sting');
  // phone taps + typing
  for (const tp of TAPS) add(tp.t, 'tap');
  for (const ty of TYPING) for (let i = 0; i < ty.text.length; i++) add(ty.t0 + (i + 0.5) * ((ty.t1 - ty.t0) / ty.text.length), 'key');
  ev.sort((a, b) => a.t - b.t);
  return ev;
}

/* ==========================================================================
 * MEASUREMENT (once, after fonts load). Offsets ignore transforms, so these
 * are layout positions that the renderer combines with scroll and cameras.
 * ========================================================================== */
const M = {};
function offsetWithin(el, anc) {
  let x = 0, y = 0, e = el;
  while (e && e !== anc) { x += e.offsetLeft; y += e.offsetTop; e = e.offsetParent; }
  return { x, y, w: el.offsetWidth, h: el.offsetHeight };
}
const PH_VIEWS = { dash: 'ph.vDash', borang: 'ph.vBorang', pasukan: 'ph.vPasukan' };
const PH_NAV = { dash: 'ph.nDash', borang: 'ph.nBorang', pasukan: 'ph.nPasukan' };
const PH_REFS = {
  dash: ['ph.btnNew', 'ph.hero', 'ph.table', 'ph.tableHead', 'ph.btnWa'],
  borang: ['ph.teamWrap', 'ph.teamSel', 'ph.dd1', 'ph.addrBox', 'ph.pills', 'ph.pill1', 'ph.occWrap', 'ph.occPlus', 'ph.secB', 'ph.toggle', 'ph.chip0', 'ph.chip1', 'ph.chip3',
    'ph.sympWrap', 'ph.refWrap', 'ph.secC', 'ph.cRow0', 'ph.cRow1', 'ph.cRow2', 'ph.cb0', 'ph.cb1', 'ph.action', 'ph.saveBtn', 'ph.lamp', 'ph.lampRow'],
  pasukan: ['ph.secD', 'ph.vNameBox', 'ph.vBtn']
};
const VIEW_OF = {};
for (const v in PH_REFS) for (const r of PH_REFS[v]) VIEW_OF[r] = v;
/* borang elements below the symptom box move when it opens or closes */
const BELOW_SYM = new Set(['ph.secC', 'ph.cRow0', 'ph.cRow1', 'ph.cRow2', 'ph.cb0', 'ph.cb1', 'ph.action', 'ph.saveBtn', 'ph.lamp', 'ph.lampRow']);
const SCREEN_REFS = ['ph.nDash', 'ph.nBorang', 'ph.nPasukan', 'ph.nPetugas', 'ph.newIcon', 'ph.bubble'];

function measure() {
  /* phone: show every view and open the symptom box while measuring */
  Object.values(PH_VIEWS).forEach(v => { $[v].style.display = 'block'; });
  $['ph.symBox'].style.height = 'auto';
  const screen = $['ph.screen'], scroll = $['ph.scroll'];
  M.phViewportTop = offsetWithin($['ph.viewport'], screen).y;
  M.phViewportH = $['ph.viewport'].offsetHeight;
  M.symH = $['ph.symInner'].offsetHeight;
  M.ph = {};
  for (const v in PH_REFS) for (const r of PH_REFS[v]) M.ph[r] = offsetWithin($[r], scroll);
  for (const r of SCREEN_REFS) M.ph[r] = offsetWithin($[r], screen);
  M.viewTop = {}; M.phContentH = {};
  for (const v in PH_VIEWS) { M.viewTop[v] = $[PH_VIEWS[v]].offsetTop; M.phContentH[v] = $[PH_VIEWS[v]].offsetHeight; }
  Object.values(PH_VIEWS).forEach(v => { $[v].style.display = ''; });
  $['ph.symBox'].style.height = '';
  /* desktop */
  const dk = $['dk.scroll'];
  M.dkViewportTop = offsetWithin($['dk.viewport'], $['dk.app']).y;
  M.dkViewportH = $['dk.viewport'].offsetHeight;
  M.dkContentH = dk.offsetHeight;
  M.dk = {}; for (const r of ['dk.table', 'dk.hero']) M.dk[r] = offsetWithin($[r], dk);
  M.dkCols = []; for (let k = 1; k <= 6; k++) M.dkCols.push(offsetWithin($['dk.th' + k], $['dk.table']));
  M.dkCols.push(offsetWithin($['dk.thTot'], $['dk.table']));
  M.dkTableH = $['dk.table'].offsetHeight;
  /* NADI card with the integration section open */
  M.na = {};
  M.na.mapTop = offsetWithin($['na.map'], $.nadi).y;
  $['na.proto'].style.height = 'auto';
  $['na.plannedWrap'].style.height = '0px';
  M.na.protoBaseH = $['na.proto'].offsetHeight;
  $['na.plannedWrap'].style.height = 'auto';
  M.na.plannedH = $['na.plannedWrap'].offsetHeight;
  M.na.protoTop = offsetWithin($['na.proto'], $['na.cardScroll']).y;
  M.na.bodyH = $['na.cardBody'].offsetHeight;
  M.na.decBtn = offsetWithin($['na.decBtn'], $['na.map']);
  M.na.card = offsetWithin($['na.card'], $['na.map']);
  $['na.proto'].style.height = ''; $['na.plannedWrap'].style.height = '';
  M.na.card0 = offsetWithin($['na.card'], $['na.map']);
  /* overlays */
  M.recH = $['ov.rec'].offsetHeight;
}

/* ---------------------------------------------------------------- phone: views, scroll, coordinates */
function phView(t) {
  if (t < T.s2.borang) return 'dash';
  if (t < T.s5.dissolve[0]) return 'borang';
  if (t < T.s5.cut) return 'pasukan';
  return 'dash';
}
function symOpen(t) { return t >= T.s3.toggle && t < T.s3.saved; }
function symH(t) {
  const open = seg(t, T.s3.toggle + 0.02, T.s3.toggle + 0.42, E.outCubic);
  const close = seg(t, T.s3.saved, T.s3.saved + 0.25, E.inOutCubic);
  return M.symH * Math.min(open, 1 - close);
}
/* content y of a phone element within its view, accounting for the symptom box at t */
function phRefY(ref, t) {
  const m = M.ph[ref], view = VIEW_OF[ref];
  let y = m.y - M.viewTop[view];
  if (BELOW_SYM.has(ref)) y += symH(t) - M.symH;
  return { x: m.x, y, w: m.w, h: m.h, view };
}
function clampScroll(v, view, closed) { const max = Math.max(0, M.phContentH[view] - (closed ? M.symH : 0) - M.phViewportH); return clamp(v, 0, max); }
/* screen-y range visible on stage (above the caption band) for a phone camera */
function phVisRange(F) {
  const toScreen = sy => 421 + ((F.fy + (sy - F.sy) / F.z) - PH.y) / PH.s;
  return [toScreen(120), toScreen(860)];
}
const SC = {};
function computeScrollTargets() {
  const yIn = r => M.ph[r].y - M.viewTop[VIEW_OF[r]];
  const off3 = phVisRange(CAM_F.F3)[0] - M.phViewportTop;
  SC.A = clampScroll(yIn('ph.teamWrap') - off3 - 12, 'borang');
  SC.B = clampScroll(yIn('ph.secB') - off3 - 10, 'borang');
  SC.C = clampScroll(yIn('ph.secC') - off3 - 10, 'borang');
  SC.list = clampScroll(yIn('ph.lampRow') - M.symH - (300 - M.phViewportTop), 'borang', true);
  SC.D = clampScroll(yIn('ph.secD') - (phVisRange(CAM_F.F5d)[0] - M.phViewportTop) - 10, 'pasukan');
  SC.table = clampScroll(yIn('ph.tableHead') - (phVisRange(CAM_F.F5dash)[0] - M.phViewportTop) - 14, 'dash');
}
function phScroll(t) {
  const v = phView(t);
  if (v === 'borang') {
    if (t >= T.s3.saved) {
      const keep = SC.C - (M.symH - symH(t)); // the box collapses above the save button; hold the frame, then scroll to Lampiran 1
      return lerp(keep, SC.list, seg(t, T.s3.pull[0], T.s3.pull[1]));
    }
    return kf(t, [[T.s3.zoom[0], 0], [T.s3.zoom[1], SC.A], [T.s3.toB[0], SC.A], [T.s3.toB[1], SC.B], [T.s3.toC[0], SC.B], [T.s3.toC[1], SC.C]]);
  }
  if (v === 'pasukan') return SC.D;
  return t > 80 ? SC.table : 0;
}
/* phone-screen coordinates of a ref at time t (anchor ax/ay within the element) */
function phRefScreen(ref, t, ax, ay) {
  ax = ax === undefined ? 0.5 : ax; ay = ay === undefined ? 0.5 : ay;
  if (!VIEW_OF[ref]) { const m = M.ph[ref]; return { x: m.x + m.w * ax, y: m.y + m.h * ay }; }
  const r = phRefY(ref, t);
  return { x: r.x + r.w * ax, y: M.phViewportTop + r.y - phScroll(t) + r.h * ay };
}

/* ---------------------------------------------------------------- layers + cameras */
/* camera: world point (fx, fy) appears at stage point (sx, sy) with zoom z */
const ID = { sx: 960, sy: 540, fx: 960, fy: 540, z: 1 };
const CAM_F = {};
const CAMS = {};
function phFrame(z, screenY, sy, sx) { return { sx, sy, fx: PH.x, fy: PH.y + (screenY - 421) * PH.s, z }; }
function nadiWorld(mx, my) { return { x: NW.x + (mx - NADI_W / 2) * NW.s, y: NW.y + (my + M.na.mapTop - NADI_H / 2) * NW.s }; }
function dkWorld(lx, ly) { return { x: DK.x - 490 + 14 + lx * DK_S, y: DK.y - 395 + 14 + 29.4 + ly * DK_S }; }
function dkScroll(t) {
  const max = Math.max(0, M.dkContentH - M.dkViewportH);
  const tab = clamp(M.dk['dk.table'].y - 14, 0, max);
  return lerp(tab, 0, seg(t, T.s4.move[0], T.s4.move[1], E.inOutCubic));
}
function computeCameras() {
  CAM_F.F3 = phFrame(1.7, 380, 490, 1300);                          // record entry close-up
  CAM_F.FO = { sx: 1360, sy: 500, fx: PH.x, fy: PH.y, z: 1.0 };     // whole phone after save
  CAM_F.F5d = phFrame(1.55, 461, 490, 1300);                        // Bahagian D (whole section above the captions)
  CAM_F.F5dash = phFrame(1.25, 470, 500, 1340);                     // summary table + toast
  CAM_F.F5chat = phFrame(1.55, M.ph['ph.bubble'].y + M.ph['ph.bubble'].h / 2, 470, 1310); // pasted summary
  CAMS.phone = [[0, { sx: PH.x, sy: PH.y, fx: PH.x, fy: PH.y, z: 1 }], [T.s3.zoom[0], { sx: PH.x, sy: PH.y, fx: PH.x, fy: PH.y, z: 1 }],
    [T.s3.zoom[1], CAM_F.F3], [T.s3.pull[0], CAM_F.F3], [T.s3.pull[1], CAM_F.FO],
    [T.s5.dissolve[0] - 0.01, CAM_F.FO], [T.s5.dissolve[0], CAM_F.F5d, E.lin],
    [T.s5.cut - 0.01, CAM_F.F5d], [T.s5.cut, CAM_F.F5dash, E.lin], [T.s5.cam[0], CAM_F.F5dash], [T.s5.cam[1], CAM_F.F5chat]];
  // desktop: the six-team table, then the coverage card (held still from 01:07.6)
  const tab = dkScroll(0), tb = M.dk['dk.table'];
  const tc = dkWorld(tb.x + tb.w / 2, M.dkViewportTop + tb.y - tab + tb.h / 2);
  CAM_F.FA = { sx: 960, sy: 462, fx: tc.x, fy: tc.y, z: Math.min(1.9, 1660 / (tb.w * DK_S)) };
  const hb = M.dk['dk.hero'], hc = dkWorld(hb.x + hb.w / 2, M.dkViewportTop + hb.y + hb.h / 2);
  CAM_F.FB = { sx: 1330, sy: 470, fx: hc.x, fy: hc.y, z: 2.05 };
  CAMS.desk = [[0, CAM_F.FA], [T.s4.move[0], CAM_F.FA], [T.s4.move[1], CAM_F.FB]];
  // NADI: whole window, then the locality card (same framing in segments 1 and 6)
  const c0 = nadiWorld(M.na.card0.x, M.na.card0.y), c1 = nadiWorld(M.na.card0.x + M.na.card0.w, M.na.card0.y);
  CAM_F.FC = { sx: 1390, sy: 470, fx: (c0.x + c1.x) / 2, fy: c0.y + (470 - 108) / 1.3, z: 1.3 };
  CAMS.nadi = [[0, ID], [T.s1.push[0], ID], [T.s1.push[1], CAM_F.FC]];
}
function camAt(layer, t) { return kf(t, CAMS[layer]); }
function camLayer(el, c) { tf(el, 'translate(' + px(c.sx) + ',' + px(c.sy) + ') scale(' + r2(c.z) + ') translate(' + px(-c.fx) + ',' + px(-c.fy) + ')'); }
/* Device changes are short dissolves through the stage background (out, then in), so two
 * unrelated screens are never superimposed. [a, b, c] = fade out a→b, fade in b→c. */
function layerOps(t) {
  const d = (a, b) => seg(t, a, b, E.inOutSine);
  const out = w => 1 - d(w[0], w[1]), inn = w => d(w[1], w[2]);
  return {
    nadi: t < 60 ? out(T.s2.setIn) : inn(T.s6.dissolve) * (1 - d(T.s7.in[0], T.s7.in[0] + 0.5)),
    man: inn(T.s2.setIn) * (1 - d(T.s2.setOut[0], T.s2.setOut[1])),
    phone: t < 70 ? (t >= T.s2.rise[0] ? 1 : 0) * out(T.s4.dissolve) : inn(T.s5.dissolve) * out(T.s6.dissolve),
    desk: inn(T.s4.dissolve) * out(T.s5.dissolve)
  };
}
/* phone placement: rises into frame at 00:17 and then stays put (cameras do the framing) */
const PHONE_KEYS = [
  [T.s2.rise[0], { x: PH.x, y: 1560, s: PH.s, r: 7 }],
  [T.s2.rise[1], { x: PH.x, y: PH.y, s: PH.s, r: 0 }, E.springSoft]
];

/* ---------------------------------------------------------------- touch indicator (phone) */
function touchState(taps, t, posFn) {
  // finger visible from 0.5 s before a tap to 0.4 s after; glides between close taps
  let cur = -1;
  for (let i = 0; i < taps.length; i++) { if (taps[i].t - 0.5 <= t) cur = i; }
  if (cur < 0) return null;
  const tp = taps[cur], prev = cur > 0 ? taps[cur - 1] : null, next = cur < taps.length - 1 ? taps[cur + 1] : null;
  const glide = prev && tp.t - prev.t < 0.95 && tp.layer === prev.layer;
  let o, x, y;
  const target = posFn(tp, t);
  if (glide) {
    const from = posFn(prev, t), p = seg(t, prev.t + 0.1, tp.t - 0.06, E.inOutCubic);
    x = lerp(from.x, target.x, p); y = lerp(from.y, target.y, p); o = 1;
  } else {
    x = target.x; y = target.y + 26 * (1 - seg(t, tp.t - 0.5, tp.t - 0.12, E.outCubic));
    o = seg(t, tp.t - 0.5, tp.t - 0.25, E.outCubic);
  }
  const willGlide = next && next.t - tp.t < 0.95 && next.layer === tp.layer;
  if (!willGlide) o = Math.min(o, 1 - seg(t, tp.t + 0.12, tp.t + 0.4, E.inCubic));
  const press = 1 - 0.14 * win(t, tp.t - 0.07, tp.t, tp.t + 0.02, tp.t + 0.12, E.outQuad, E.inQuad);
  const rp = seg(t, tp.t, tp.t + 0.5, E.outCubic);
  const ripple = t >= tp.t ? { s: lerp(0.5, 2.3, rp), o: 0.75 * (1 - rp) } : { s: 0.5, o: 0 };
  return { x, y, o, press, ripple };
}
function renderTouch(el, rip, st) {
  if (!st || st.o <= 0.002) { op(el, 0); op(rip, 0); return; }
  op(el, st.o);
  tf(el, 'translate(' + px(st.x) + ',' + px(st.y) + ') scale(' + r2(st.press) + ')');
  op(rip, st.ripple.o); tf(rip, 'scale(' + r2(st.ripple.s) + ')');
}

/* ==========================================================================
 * BUILDERS (seeded, run once)
 * ========================================================================== */
const MAP = {};
/* Illustrative district map in the OpenStreetMap palette — not real geography. */
function buildNadiMap() {
  const r = rng('peta-ilustrasi-nadi');
  const blob = (cx, cy, rx, ry, n, jit) => {
    let d = '';
    for (let i = 0; i <= n; i++) {
      const a = (i / n) * Math.PI * 2, k = 1 + (r() - 0.5) * jit;
      d += (i ? 'L' : 'M') + (cx + Math.cos(a) * rx * k).toFixed(1) + ' ' + (cy + Math.sin(a) * ry * k).toFixed(1);
    }
    return d + 'Z';
  };
  let g = '<defs><filter id="mkShadow" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="0" dy="2" stdDeviation="2.2" flood-color="#0f172a" flood-opacity=".35"/></filter></defs>' +
    '<rect width="1280" height="556" fill="#f2efe9"/>';
  const land = [[140, 110, 150, 80, '#e3ebd0'], [380, 470, 170, 70, '#dcebc9'], [610, 70, 140, 60, '#d6e7c4'], [1060, 470, 180, 80, '#e3ebd0'],
    [250, 300, 90, 60, '#e9e4dc'], [KET.x, KET.y, 128, 86, '#ebe5dc'], [520, 250, 70, 50, '#e9e4dc'], [80, 520, 120, 50, '#cfe3bd'], [700, 520, 110, 45, '#cfe3bd']];
  for (const [x, y, rx, ry, c] of land) g += '<path d="' + blob(x, y, rx, ry, 18, 0.22) + '" fill="' + c + '"/>';
  // river
  g += '<path d="M-20 470 C 180 420, 330 520, 520 450 S 760 330, 930 360 S 1150 470, 1300 420" fill="none" stroke="#aad3df" stroke-width="17" stroke-linecap="round"/>';
  // roads: casing then fill
  const roads = [
    ['M-20 150 C 160 170, 300 215, 420 205 S 640 150, 760 168 S 1060 250, 1300 250', '#c99a5b', '#fcd6a4', 11.5, 9],
    ['M620 580 C 660 470, 700 400, 760 330 S 850 250, 860 150 S 880 40, 900 -20', '#cbc3b4', '#ffffff', 8, 6],
    ['M-20 330 C 120 315, 220 290, 330 300 S 470 330, 560 318', '#cbc3b4', '#ffffff', 8, 6],
    ['M330 300 C 345 360, 360 420, 400 560', '#cbc3b4', '#ffffff', 7, 5]
  ];
  for (const [d, c0, c1, w0, w1] of roads) g += '<path d="' + d + '" fill="none" stroke="' + c0 + '" stroke-width="' + w0 + '" stroke-linecap="round"/><path d="' + d + '" fill="none" stroke="' + c1 + '" stroke-width="' + w1 + '" stroke-linecap="round"/>';
  const lanes = ['M760 300 L 900 285', 'M770 250 L 720 190', 'M840 200 L 930 215', 'M790 270 L 800 330', 'M860 260 L 905 300', 'M700 230 L 760 238'];
  for (const d of lanes) g += '<path d="' + d + '" fill="none" stroke="#cbc3b4" stroke-width="5" stroke-linecap="round"/><path d="' + d + '" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>';
  // building footprints (texture only)
  const hr = rng('rumah-ketoyong');
  for (let i = 0; i < 70; i++) {
    const a = hr() * Math.PI * 2, rad = 18 + Math.sqrt(hr()) * 100, x = KET.x + Math.cos(a) * rad * 1.25, y = KET.y + Math.sin(a) * rad * 0.8;
    if (x > 905) continue;
    g += '<rect x="' + (x - 3.5).toFixed(1) + '" y="' + (y - 3).toFixed(1) + '" width="7" height="6" rx="1" fill="#d9d0c9" transform="rotate(' + ((hr() - 0.5) * 50).toFixed(1) + ' ' + x.toFixed(1) + ' ' + y.toFixed(1) + ')"/>';
  }
  for (const [cx, cy, n] of [[250, 300, 22], [520, 250, 16], [150, 120, 10]]) {
    for (let i = 0; i < n; i++) { const x = cx + (hr() - 0.5) * 150, y = cy + (hr() - 0.5) * 80; g += '<rect x="' + (x - 3).toFixed(1) + '" y="' + (y - 3).toFixed(1) + '" width="6" height="5.5" rx="1" fill="#dcd3cb"/>'; }
  }
  // other synthetic localities (muted, unlabelled): one case, ended outbreak, WTK
  const others = [[240, 330, '#0284c7', 1, 0], [470, 120, '#059669', 2, 44], [590, 470, '#ea580c', 3, 0], [120, 470, '#0284c7', 1, 0]];
  for (const [x, y, c, n, buf] of others) {
    if (buf) g += '<circle cx="' + x + '" cy="' + y + '" r="' + buf + '" fill="' + c + '" fill-opacity=".07" stroke="' + c + '" stroke-opacity=".55" stroke-width="1.6" stroke-dasharray="6 5"/>';
    g += '<g opacity=".82" filter="url(#mkShadow)"><circle cx="' + x + '" cy="' + y + '" r="' + (n > 1 ? 12 : 9.5) + '" fill="' + c + '" stroke="#fff" stroke-width="2.5"/>' +
      '<text x="' + x + '" y="' + (y + 4) + '" text-anchor="middle" font-size="' + (n > 1 ? 12 : 10.5) + '" fill="#fff" class="mk-num">' + n + '</text></g>';
  }
  // Kg. Ketoyong: 200 m buffer, centroid marker with cumulative cases, label
  g += '<circle data-mk="buf" cx="' + KET.x + '" cy="' + KET.y + '" r="60" fill="#d97706" fill-opacity=".07" stroke="#d97706" stroke-opacity=".45" stroke-width="2"/>';
  g += '<g data-mk="fu"></g>';
  g += '<g filter="url(#mkShadow)"><circle data-mk="mk" cx="' + KET.x + '" cy="' + KET.y + '" r="15" fill="#d97706" stroke="#fff" stroke-width="2.5"/>' +
    '<text x="' + KET.x + '" y="' + (KET.y + 5.5) + '" text-anchor="middle" font-size="15" fill="#fff" class="mk-num">' + NADI_CARD.cumulativeCases + '</text></g>';
  g += '<g transform="translate(' + KET.x + ' ' + (KET.y - 40) + ')"><rect x="-49" y="-12" width="98" height="22" rx="6" fill="#fff" stroke="#d97706" stroke-width="1.2"/>' +
    '<text x="0" y="3.6" text-anchor="middle" font-size="11.5" fill="#102A43" class="mk-label">Kg. Ketoyong</text></g>';
  const svg = $['na.mapSvg'];
  svg.innerHTML = g;
  MAP.buf = svg.querySelector('[data-mk="buf"]');
  MAP.mk = svg.querySelector('[data-mk="mk"]');
  const fu = svg.querySelector('[data-mk="fu"]');
  fu.innerHTML = FOLLOW_POS.map((p, i) => '<g data-fu="' + i + '" opacity="0"><g filter="url(#mkShadow)"><circle r="9.5" fill="#006B5B" stroke="#fff" stroke-width="2"/>' +
    '<text y="3.6" text-anchor="middle" font-size="10" fill="#fff" class="mk-num">' + (i + 1) + '</text></g></g>').join('');
  MAP.fu = Array.from(fu.querySelectorAll('[data-fu]'));
}

const MAN = { scribbles: [], tally: [], cells: [] };
function buildManual() {
  // handwriting on the paper form
  const host = $['man.paperGrid'], pr = rng('kertas-acd');
  const W = 468, rowH = 40, rows = 12, colX = [0, 44, 230, 300, 380, 468];
  let s = '<svg width="' + W + '" height="' + (rowH * (rows + 1) + 4) + '" viewBox="0 0 ' + W + ' ' + (rowH * (rows + 1) + 4) + '">';
  ['Bil', 'Alamat', 'Kod', 'Penghuni', 'Gejala'].forEach((h, i) => { s += '<text x="' + (colX[i] + 6) + '" y="26" font-size="13" font-weight="700" fill="#334155">' + h + '</text>'; });
  for (let i = 0; i <= rows + 1; i++) s += '<line x1="0" x2="' + W + '" y1="' + (i * rowH) + '" y2="' + (i * rowH) + '" stroke="#94a3b8" stroke-width="1"/>';
  for (let c = 1; c < colX.length - 1; c++) s += '<line x1="' + colX[c] + '" x2="' + colX[c] + '" y1="0" y2="' + (rowH * (rows + 1)) + '" stroke="#94a3b8" stroke-width="1"/>';
  for (let ri = 1; ri <= rows; ri++) {
    for (let c = 0; c < 5; c++) {
      const x0 = colX[c] + 7, x1 = colX[c + 1] - 7, yb = ri * rowH + 27;
      const width = c === 1 ? (x1 - x0) * (0.55 + pr() * 0.4) : c === 4 ? (x1 - x0) * (0.3 + pr() * 0.6) : (x1 - x0) * (0.4 + pr() * 0.35);
      let path = 'M' + x0.toFixed(1) + ' ' + (yb - 4).toFixed(1), x = x0;
      while (x < x0 + width) {
        const w = 5 + pr() * 7, up = 7 + pr() * 9;
        path += ' c ' + (w * 0.3).toFixed(1) + ' ' + (-up).toFixed(1) + ' ' + (w * 0.7).toFixed(1) + ' ' + (-up).toFixed(1) + ' ' + w.toFixed(1) + ' ' + (pr() * 6 - 1).toFixed(1);
        x += w;
      }
      s += '<path d="' + path + '" fill="none" stroke="#1e3a8a" stroke-width="1.7" stroke-linecap="round" pathLength="1" stroke-dasharray="1 1" stroke-dashoffset="1" data-row="' + ri + '" data-col="' + c + '"/>';
    }
  }
  host.innerHTML = s + '</svg>';
  MAN.scribbles = Array.from(host.querySelectorAll('path[data-row]'));
  // tally marks: one row per team, groups of five
  const ts = $['man.tallySvg'], tr = rng('tally');
  let tg = '', mark = 0;
  for (let k = 1; k <= 6; k++) {
    const y = 34 + (k - 1) * 62;
    tg += '<text x="4" y="' + (y + 22) + '" font-size="22" font-weight="700" font-style="italic" fill="#1e3a8a">P' + k + '</text>';
    for (let i = 0; i < TEAMS[k].visited; i++) {
      const grp = Math.floor(i / 5), j = i % 5, gx = 52 + grp * 70;
      let p;
      if (j < 4) { const x = gx + j * 11 + (tr() - 0.5) * 2; p = 'M' + x.toFixed(1) + ' ' + (y + (tr() - 0.5) * 3).toFixed(1) + ' L' + (x + (tr() - 0.5) * 3).toFixed(1) + ' ' + (y + 30).toFixed(1); }
      else p = 'M' + (gx - 6) + ' ' + (y + 24) + ' L' + (gx + 42) + ' ' + (y + 6);
      tg += '<path d="' + p + '" stroke="#1e3a8a" stroke-width="2.6" stroke-linecap="round" fill="none" pathLength="1" stroke-dasharray="1 1" stroke-dashoffset="1" data-m="' + (mark++) + '"/>';
    }
  }
  ts.innerHTML = tg;
  MAN.tally = Array.from(ts.querySelectorAll('path[data-m]'));
  // re-entry grid on the laptop
  const lg = $['man.lapGrid'];
  const rowsL = [['Lokaliti', 'locality'], ['Dilawati', 'visited'], ['Berkunci/Kosong', 'locked'], ['Penduduk', 'pop'], ['Bergejala', 'symp'], ['Rujukan', 'ref']];
  let lh = '<div class="lg-row lg-hd"><span class="lg-l">PERKARA</span>' + [1, 2, 3, 4, 5, 6].map(k => '<span>P' + k + '</span>').join('') + '<span>Jumlah</span></div>';
  rowsL.forEach(([label, key]) => {
    lh += '<div class="lg-row"><span class="lg-l">' + label + '</span>';
    for (let k = 1; k <= 6; k++) lh += '<span class="lg-c" data-v="' + TEAMS[k][key] + '"></span>';
    lh += '<span class="lg-c" data-v="' + TOTALS[key] + '"></span></div>';
  });
  lg.innerHTML = lh + '<div class="lg-sim">' + simBadge('') + '</div>';
  MAN.cells = Array.from(lg.querySelectorAll('.lg-c'));
}

const DUST = [];
let CLOSING = [];
function buildBackground() {
  css($['bg.grad'], 'background', 'linear-gradient(160deg, #020617 0%, #0b1324 42%, #0e2a2c 74%, #134e4a 100%)');
  css($['bg.end'], 'background', 'radial-gradient(ellipse 90% 80% at 50% 40%, #0f766e 0%, #115e59 32%, #0b3b37 64%, #031b1a 100%)');
  css($['bg.end'], 'opacity', '0');
  let g = '';
  for (let x = 0; x <= 1920; x += 96) g += '<line x1="' + x + '" y1="0" x2="' + x + '" y2="1080" stroke="rgba(94,234,212,.045)" stroke-width="1"/>';
  for (let y = 0; y <= 1080; y += 96) g += '<line x1="0" y1="' + y + '" x2="1920" y2="' + y + '" stroke="rgba(94,234,212,.045)" stroke-width="1"/>';
  $['bg.grid'].innerHTML = g;
  const r = rng('dust'); let d = '';
  for (let i = 0; i < 30; i++) { d += '<i></i>'; DUST.push({ x: r() * 1920, y: r() * 1080, vx: (r() - 0.5) * 12, vy: -5 - r() * 10, a: 0.2 + r() * 0.45, s: 0.6 + r() * 1.4, ph: r() * 6.28 }); }
  $['bg.dust'].innerHTML = d;
  DUST.forEach((p, i) => { p.el = $['bg.dust'].children[i]; });
  CLOSING = Array.from($['ov.closing'].children);
}

/* ==========================================================================
 * RENDERERS
 * ========================================================================== */
function renderBg(t) {
  op($['bg.end'], seg(t, T.s7.in[0], T.s7.in[1], E.inOutSine));
  op($['bg.g1'], 0.85); op($['bg.g2'], 0.75);
  tf($['bg.g1'], 'translate(' + px(560 + Math.sin(t * 0.11) * 220) + ',' + px(-760 + Math.cos(t * 0.09) * 120) + ')');
  tf($['bg.g2'], 'translate(' + px(-420 + Math.cos(t * 0.08) * 200) + ',' + px(80 + Math.sin(t * 0.1) * 110) + ')');
  tf($['bg.grid'], 'translate(' + px(-((t * 6) % 96)) + ',' + px(-((t * 4) % 96)) + ')');
  for (const p of DUST) {
    const x = ((p.x + p.vx * t) % 1920 + 1920) % 1920, y = ((p.y + p.vy * t) % 1080 + 1080) % 1080;
    tf(p.el, 'translate(' + px(x) + ',' + px(y + Math.sin(t * 0.7 + p.ph) * 10) + ') scale(' + r2(p.s) + ')');
    op(p.el, p.a * (0.6 + 0.4 * Math.sin(t * 1.3 + p.ph)));
  }
}

/* ---------------------------------------------------------------- NADI */
function cardScroll(t) { return t > 60 ? M.na.protoTop * seg(t, T.s6.expand[0], T.s6.expand[1], E.inOutCubic) : 0; }
function decBtnMap(t) { const b = M.na.decBtn; return { x: b.x + b.w * 0.42, y: b.y - cardScroll(t) + b.h * 0.55 }; }
function renderNadi(t, o) {
  const L = $['w.nadi'];
  vis(L, o > 0.002); if (o <= 0.002) return;
  op(L, o);
  camLayer(L, camAt('nadi', t));
  tf($.nadi, 'translate(' + px(NW.x) + ',' + px(NW.y) + ') translate(-50%,-50%) scale(' + NW.s + ')');
  const s6 = t > 60;
  // locality selected by the click in segment 1 (stays selected)
  const sel = s6 ? 1 : seg(t, T.s1.click, T.s1.click + 0.3, E.outCubic);
  attr(MAP.buf, 'fill-opacity', String(r2(lerp(0.07, 0.18, sel))));
  attr(MAP.buf, 'stroke-opacity', String(r2(lerp(0.45, 0.95, sel))));
  attr(MAP.mk, 'r', String(r2(lerp(15, 18, s6 ? 1 : seg(t, T.s1.click, T.s1.click + 0.45, E.outBack)))));
  // locality card (OutbreakMap.tsx floating card)
  const cIn = s6 ? 1 : seg(t, T.s1.cardIn[0], T.s1.cardIn[1], E.outCubic);
  op($['na.card'], cIn);
  tf($['na.card'], 'scale(' + r2(s6 ? 1 : lerp(0.94, 1, seg(t, T.s1.cardIn[0], T.s1.cardIn[1] + 0.2, E.springSoft))) + ')');
  // e-ACD summary in NADI (integration prototype), segment 6
  const ex = s6 ? seg(t, T.s6.expand[0], T.s6.expand[1], E.inOutCubic) : 0;
  css($['na.proto'], 'height', ex >= 1 ? 'auto' : px(M.na.protoBaseH * ex));
  op($['na.protoIn'], s6 ? seg(t, T.s6.expand[0] + 0.25, T.s6.expand[1]) : 0);
  tf($['na.cardScroll'], 'translateY(' + px(-cardScroll(t)) + ')');
  cls($['na.kLeft'], 'hl', s6 && t >= T.s6.left[0]);
  const pl = s6 ? seg(t, T.s6.planned[0], T.s6.planned[1], E.outCubic) : 0;
  css($['na.plannedWrap'], 'height', pl >= 1 ? 'auto' : px(M.na.plannedH * pl));
  op($['na.planned'], pl);
  cls($['na.decBtn'], 'press', s6 && t >= T.s6.click - 0.02 && t < T.s6.click + 0.14);
  cls($['na.decBtn'], 'done', s6 && t >= T.s6.planned[0]);
  // follow-up premises appear on the map after the decision
  for (let i = 0; i < 6; i++) {
    const t0 = T.s6.marks + i * 0.1, a = s6 ? seg(t, t0, t0 + 0.45, E.outBack) : 0, p = FOLLOW_POS[i];
    attr(MAP.fu[i], 'opacity', String(r2(s6 ? seg(t, t0, t0 + 0.12) : 0)));
    attr(MAP.fu[i], 'transform', 'translate(' + p.x.toFixed(1) + ' ' + p.y.toFixed(1) + ') scale(' + r2(Math.max(0.01, a)) + ')');
  }
  renderCursor(t);
}
function renderCursor(t) {
  const c = $['na.cursor'], rip = $['na.ripple'];
  let ev = null;
  for (const e of NCUR) if (t >= e.t0 - 0.3 && t <= e.out[1]) ev = e;
  if (!ev) { op(c, 0); op(rip, 0); return; }
  const tg = ev.target(t), p = seg(t, ev.t0, ev.t1, E.inOutCubic);
  const x = lerp(ev.from[0], tg.x, p), y = lerp(ev.from[1], tg.y, p);
  op(c, Math.min(seg(t, ev.t0 - 0.3, ev.t0, E.outCubic), 1 - seg(t, ev.out[0], ev.out[1], E.inCubic)));
  const press = 1 - 0.12 * win(t, ev.click - 0.06, ev.click, ev.click + 0.02, ev.click + 0.12, E.outQuad, E.inQuad);
  tf(c, 'translate(' + px(x) + ',' + px(y) + ') scale(' + r2(press) + ')');
  const rp = seg(t, ev.click, ev.click + 0.5, E.outCubic);
  op(rip, t >= ev.click ? 0.8 * (1 - rp) : 0); tf(rip, 'scale(' + r2(lerp(0.4, 2.2, rp)) + ')');
}

/* ---------------------------------------------------------------- segment 2: manual process */
const MAN_ITEMS = [
  { el: 'man.paper', x: 330, y: 580, r: -5, s: 0.8, t: 12.0, tag: [330, 276] },
  { el: 'man.binder', x: 720, y: 590, r: 3, s: 0.8, t: 12.12, tag: [720, 332] },
  { el: 'man.tally', x: 1105, y: 580, r: -3, s: 0.8, t: 12.24, tag: [1105, 338] },
  { el: 'man.laptop', x: 1575, y: 600, r: 0, s: 0.7, t: 12.36, tag: [1575, 390] }
];
function renderManual(t, o) {
  const S = $.man;
  vis(S, o > 0.002); if (o <= 0.002) return;
  op(S, o);
  const sc = lerp(1, 0.55, seg(t, T.s2.shrink[0], T.s2.shrink[1], E.inOutCubic));
  tf(S, 'translate(40px,560px) scale(' + r2(sc) + ') translate(-40px,-560px)');
  // focus: form + file (2a), tally (counting), laptop (re-typing)
  const bright = [
    1 - seg(t, 15.6, 15.9), 1 - seg(t, 15.6, 15.9),
    Math.max(1 - seg(t, 12.45, 12.75), win(t, 15.45, 15.75, 16.5, 16.8, E.lin, E.lin)),
    Math.max(1 - seg(t, 12.45, 12.75), seg(t, 16.45, 16.75, E.lin))
  ];
  MAN_ITEMS.forEach((it, i) => {
    const a = seg(t, it.t, it.t + 0.7, E.springSoft);
    tf($[it.el], 'translate(' + px(it.x) + ',' + px(it.y + 70 * (1 - a)) + ') translate(-50%,-50%) rotate(' + it.r + 'deg) scale(' + it.s + ')');
    op($[it.el], seg(t, it.t, it.t + 0.3));
    op($['man.dim' + i], 0.55 * (1 - bright[i]));
    const tg = $['man.tag' + i], ta = seg(t, T.s2.tags[i], T.s2.tags[i] + 0.45, E.outBack);
    op(tg, seg(t, T.s2.tags[i], T.s2.tags[i] + 0.2) * lerp(0.45, 1, bright[i]));
    tf(tg, 'translate(' + px(it.tag[0]) + ',' + px(it.tag[1]) + ') translate(-50%,-50%) scale(' + r2(lerp(0.7, 1, ta)) + ')');
  });
  for (const p of MAN.scribbles) {
    const t0 = T.s2.write[0] + (+p.dataset.row - 1) * 0.23 + (+p.dataset.col) * 0.04;
    attr(p, 'stroke-dashoffset', String(r2(1 - seg(t, t0, t0 + 0.12, E.lin))));
  }
  const nT = MAN.tally.length, dT = (T.s2.tally[1] - T.s2.tally[0]) / nT;
  for (let i = 0; i < nT; i++) { const t0 = T.s2.tally[0] + i * dT; attr(MAN.tally[i], 'stroke-dashoffset', String(r2(1 - seg(t, t0, t0 + 0.05, E.lin)))); }
  const n = MAN.cells.length, dt = (T.s2.typing[1] - T.s2.typing[0]) / n;
  for (let i = 0; i < n; i++) {
    const c = MAN.cells[i], t0 = T.s2.typing[0] + i * dt;
    txt(c, t >= t0 ? c.dataset.v : '');
    cls(c, 'cur', t >= t0 - dt && t < t0 + dt * 0.6 && t < T.s2.typing[1] + 0.2);
  }
}

/* ---------------------------------------------------------------- e-ACD dashboards */
function setSync(prefix, t, states) {
  const s = step(t, states);
  txt($[prefix + 'syncText'], s[0]);
  css($[prefix + 'syncDot'], 'background-color', s[1] ? '#fbbf24' : '#34d399');
}
function renderDash(p, t, teams) {
  const tot = computeTotals(teams);
  txt($[p + 'kpiPct'], tot.pct + '%');
  txt($[p + 'kpiRatio'], '(' + tot.visited + ' / ' + tot.locality + ' premis)');
  const ok = tot.pct >= TARGET_PCT;
  css($[p + 'kpiBar'], 'width', Math.min(100, tot.pct) + '%');
  css($[p + 'kpiBar'], 'background-color', ok ? '#34d399' : '#fbbf24');
  css($[p + 'kpiBadge'], 'background-color', ok ? '#34d399' : '#fbbf24'); css($[p + 'kpiBadge'], 'color', '#020617');
  txt($[p + 'kpiTeams'], tot.activeTeams + '/6 Pasukan Aktif');
  txt($[p + 'mLoc'], String(tot.locality)); txt($[p + 'mVis'], String(tot.visited)); txt($[p + 'mLock'], String(tot.locked));
  txt($[p + 'mPop'], String(tot.pop)); txt($[p + 'mSymp'], String(tot.symp)); txt($[p + 'mRef'], String(tot.ref));
  txt($[p + 'mSample'], tot.sample + ' sampel');
  return tot;
}

/* ---------------------------------------------------------------- phone */
function renderPhone(t, o) {
  const L = $['w.phone'];
  vis(L, o > 0.002); if (o <= 0.002) return;
  op(L, o);
  camLayer(L, camAt('phone', t));
  const pk = kf(t, PHONE_KEYS);
  tf($.phone, 'translate(' + px(pk.x) + ',' + px(pk.y) + ') translate(-50%,-50%) rotate(' + r2(pk.r) + 'deg) scale(' + r2(pk.s) + ')');
  css($['ph.glass'], 'background-position', r2(46 + pk.r * 3) + '% 0');
  // layers: home screen (launch), app, messaging app
  const appOn = t >= T.s2.appIn[0] - 0.05;
  const homeO = 1 - seg(t, T.s2.appIn[0], T.s2.appIn[1], E.lin);
  vis($['ph.app'], appOn); op($['ph.app'], appOn ? 1 : 0);
  vis($['ph.home'], homeO > 0.002); op($['ph.home'], homeO);
  if (homeO > 0.002) renderHome(t);
  const chatIn = seg(t, T.s5.chat[0], T.s5.chat[1], E.outCubic);
  vis($['ph.chat'], chatIn > 0.002); op($['ph.chat'], chatIn > 0.002 ? 1 : 0);
  tf($['ph.chat'], 'translateX(' + (100 * (1 - chatIn)).toFixed(2) + '%)');
  if (chatIn > 0.002) renderChat(t);
  // app view, nav and scroll
  const v = phView(t);
  for (const k in PH_VIEWS) { vis($[PH_VIEWS[k]], k === v); cls($[PH_NAV[k]], 'on', k === v); }
  tf($['ph.scroll'], 'translateY(' + px(-phScroll(t)) + ')');
  setSync('ph.', t, [[0, ['Sistem Aktif', 0]], [T.s3.saved + 0.05, ['Menyimpan ke Sheet...', 1]], [T.s3.saved + 0.85, ['Sheet Diselaraskan', 0]]]);
  if (v === 'dash') renderDash('ph.', t, teamsAt(t));
  if (v === 'borang') renderBorang(t);
  if (v === 'pasukan') renderPasukan(t);
  cls($['ph.btnNew'], 'press', t >= T.s2.tapNew - 0.02 && t < T.s2.tapNew + 0.16);
  cls($['ph.btnWa'], 'press', t >= T.s5.tapWa - 0.02 && t < T.s5.tapWa + 0.16);
  // toasts (texts from the source showToast calls)
  const toasts = [
    [T.s3.saved, T.s3.saved + 2.8, 'Rekod rumah disimpan & ditambah ke Pasukan ' + HOUSE_DEMO.team],
    [T.s5.tapVerify + 0.05, T.s5.tapVerify + 2.2, 'Pengesahan Bahagian D telah direkodkan'],
    [T.s5.tapWa + 0.1, T.s5.chat[0] + 0.15, 'Ringkasan laporan disalin! Sedia ditampal ke WhatsApp.']
  ];
  let ta = 0, tt = '';
  for (const [a, b, s] of toasts) { const w = win(t, a, a + 0.18, b - 0.2, b); if (w > ta) { ta = w; tt = s; } }
  op($['ph.toast'], ta); tf($['ph.toast'], 'translateY(' + px(12 * (1 - ta)) + ')'); if (tt) txt($['ph.toastText'], tt);
  // finger
  const st = touchState(TAPS, t, tp => phRefScreen(tp.ref, t, tp.ax, tp.ay));
  renderTouch($['ph.touch'], $['ph.ripple'], st);
}
function renderHome(t) {
  const press = 1 - 0.1 * win(t, T.s2.tapIcon - 0.06, T.s2.tapIcon, T.s2.tapIcon + 0.05, T.s2.tapIcon + 0.15);
  tf($['ph.newIcon'], 'scale(' + r2(press) + ')');
  const m = M.ph['ph.newIcon'], lp = seg(t, T.s2.launch[0], T.s2.launch[1], E.inOutCubic), L = $['ph.launch'];
  op(L, t >= T.s2.launch[0] ? 1 : 0);
  css(L, 'left', px(lerp(m.x, 0, lp))); css(L, 'top', px(lerp(m.y, 0, lp)));
  css(L, 'width', px(lerp(m.w, PH_SCREEN_W, lp))); css(L, 'height', px(lerp(m.h, PH_SCREEN_H, lp)));
  css(L, 'border-radius', px(lerp(16, 56, lp)));
}
function renderBorang(t) {
  const S = T.s3;
  txt($['ph.teamSelText'], t < S.pickTeam ? 'Pasukan 2' : 'Pasukan ' + HOUSE_DEMO.team);
  const dd = win(t, S.tapTeam + 0.05, S.tapTeam + 0.18, S.pickTeam + 0.08, S.pickTeam + 0.22);
  op($['ph.teamDrop'], dd); tf($['ph.teamDrop'], 'scaleY(' + r2(lerp(0.9, 1, dd)) + ')');
  for (let k = 1; k <= 6; k++) cls($['ph.dd' + k], 'on', t < S.pickTeam - 0.06 ? k === 2 : k === 1);
  cls($['ph.teamSel'], 'focus-ring', t >= S.tapTeam && t < S.pickTeam + 0.3);
  // address: typed, cleared after save (source submit handler)
  const addr = t < S.saved ? typed(t, 0) : '';
  txt($['ph.addr'], addr); vis($['ph.addrPh'], addr.length === 0);
  const focused = t >= S.tapAddr && t < S.tapStatus - 0.1;
  op($['ph.addrCaret'], focused && (t < S.type[1] || Math.floor(t * 2.4) % 2 === 0) ? 1 : 0);
  cls($['ph.addrBox'], 'focus-ring', focused);
  // status: the previous record left "2 - Berkunci" selected (not reset by the source)
  for (const s of STATUS_CODES) cls($['ph.pill' + s.code], 'on', t < S.tapStatus ? s.code === '2' : s.code === HOUSE_DEMO.status);
  // status 1 sets occupants to 1 (if 0) and ticks the leaflet; status 2 had set 0 and unticked it
  const occ = t < S.tapStatus ? 0 : 1 + S.occ.filter(x => t >= x).length;
  txt($['ph.occ'], String(occ));
  cls($['ph.occWrap'], 'hl', t >= S.occ[0] - 0.3 && t < S.occ[3] + 1.2);
  // Bahagian B — "Ada Kes" sets 1 symptomatic, 1 referral and "Rujuk Klinik Kesihatan" (source)
  const tog = symOpen(t);
  cls($['ph.toggle'], 'on', tog); txt($['ph.toggleLbl'], tog ? 'Ada Kes' : 'Tiada');
  css($['ph.symBox'], 'height', px(symH(t)));
  const chipOn = [S.chips[0], S.chips[1], null, S.chips[2]];
  for (let i = 0; i < 8; i++) cls($['ph.chip' + i], 'on', chipOn[i] != null && t >= chipOn[i] && t < S.saved);
  txt($['ph.sympCnt'], tog ? String(HOUSE_DEMO.symptomCount) : '0');
  txt($['ph.refCnt'], tog ? String(HOUSE_DEMO.referredCount) : '0');
  txt($['ph.sampleCnt'], '0');
  cls($['ph.sympWrap'], 'hl-rose', t >= S.hlSymp && t < S.hlRef);
  cls($['ph.refWrap'], 'hl-purple', t >= S.hlRef && t < S.toC[0]);
  // Bahagian C
  cls($['ph.cb0'], 'on', t >= S.cb0 && t < S.saved);
  cls($['ph.cb1'], 'on', t >= S.cb1 && t < S.saved);
  cls($['ph.cb2'], 'on', t >= S.tapStatus);
  cls($['ph.cRow0'], 'hl-rose', t >= S.cb0 - 0.05 && t < S.cb1 - 0.05);
  cls($['ph.cRow1'], 'hl-emerald', t >= S.cb1 - 0.05 && t < S.hlRis);
  cls($['ph.cRow2'], 'hl-emerald', t >= S.hlRis && t < S.hlAct);
  txt($['ph.actionText'], t < S.tapStatus ? 'Notis / Kad Lawatan Ditinggalkan' : t < S.toggle ? 'Pendidikan Kesihatan' : HOUSE_DEMO.fieldAction);
  cls($['ph.action'], 'hl', t >= S.hlAct && t < S.save - 0.4);
  cls($['ph.saveBtn'], 'hl', t >= S.save - 0.4 && t < S.save);
  cls($['ph.saveBtn'], 'press', t >= S.save - 0.02 && t < S.save + 0.16);
  // Lampiran 1 list gains the saved record
  vis($['ph.lampRow'], t >= S.saved); vis($['ph.lampEmpty'], t < S.saved);
  cls($['ph.lampRow'], 'fresh', t >= S.saved);
  txt($['ph.lampSub'], 'Memaparkan ' + (t >= S.saved ? 1 : 0) + ' rekod rumah dalam Lampiran 1.');
}
function renderPasukan(t) {
  const name = typed(t, 1);
  txt($['ph.vName'], name); vis($['ph.vNamePh'], name.length === 0);
  op($['ph.vCaret'], t >= T.s5.tapName && t < T.s5.tapVerify - 0.1 && (t < T.s5.type[1] || Math.floor(t * 2.4) % 2 === 0) ? 1 : 0);
  cls($['ph.vNameBox'], 'focus-ring', t >= T.s5.tapName && t < T.s5.tapVerify - 0.1);
  const verified = t >= T.s5.tapVerify;
  html($['ph.vStatus'], verified
    ? 'Status: <span class="font-bold text-emerald-700">Telah Disahkan oleh ' + esc(VERIFICATION.officerName) + ' (' + esc(VERIFICATION.officerRole) + ') pada ' + esc(VERIFICATION.date) + '</span>'
    : 'Status: <span class="font-bold text-amber-700">Belum Disahkan</span>');
  cls($['ph.vBtn'], 'press', t >= T.s5.tapVerify - 0.02 && t < T.s5.tapVerify + 0.16);
  cls($['ph.secD'], 'hl-emerald', verified);
}
function renderChat(t) {
  const b = seg(t, T.s5.paste, T.s5.paste + 0.45, E.spring);
  op($['ph.bubble'], seg(t, T.s5.paste, T.s5.paste + 0.12));
  tf($['ph.bubble'], 'scale(' + r2(lerp(0.94, 1, b)) + ')');
  txt($['ph.chatInput'], t >= T.s5.paste ? 'Ringkasan ditampal · semak sebelum dihantar' : 'Tulis mesej');
}

/* ---------------------------------------------------------------- desktop (segment 4) */
const SUM_KEYS = ['locality', 'visited', 'locked', 'pop', 'symp', 'ref', 'sample', 'pct'];
function renderDesktop(t, o) {
  const L = $['w.desk'];
  vis(L, o > 0.002); if (o <= 0.002) return;
  op(L, o);
  camLayer(L, camAt('desk', t));
  tf($.desktop, 'translate(' + px(DK.x) + ',' + px(DK.y) + ') translate(-50%,-50%)');
  tf($['dk.scroll'], 'translateY(' + px(-dkScroll(t)) + ')');
  setSync('dk.', t, [[0, ['Sheet Diselaraskan', 0]]]);
  renderDash('dk.', t, TEAMS);
  // "Jumlah" column accumulates while the highlight sweeps Pasukan 1 → 6
  const C = T.s4.cols, n = C.filter(c => t >= c).length, fin = t >= T.s4.tot;
  const cum = { locality: 0, visited: 0, locked: 0, pop: 0, symp: 0, ref: 0, sample: 0 };
  for (let k = 1; k <= n; k++) for (const key in cum) cum[key] += TEAMS[k][key];
  for (let r = 0; r < 8; r++) {
    let v;
    if (fin) v = r === 7 ? TOTALS.pct + '%' : String(TOTALS[SUM_KEYS[r]]);
    else if (n === 0) v = '';
    else v = r === 7 ? Math.round(cum.visited / cum.locality * 100) + '%' : String(cum[SUM_KEYS[r]]);
    txt($['dk.tt' + r], v);
    cls($['dk.tt' + r], 'tc-hot', (n > 0 && !fin && t - C[n - 1] < 0.35) || (fin && t - T.s4.tot < 0.7));
  }
  const keys = [[C[0], 0]];
  for (let i = 1; i < 6; i++) keys.push([C[i] - 0.2, i - 1], [C[i], i, E.outCubic]);
  keys.push([T.s4.tot - 0.2, 5], [T.s4.tot, 6, E.outCubic]);
  const ci = kf(t, keys), i0 = Math.floor(ci), i1 = Math.min(6, i0 + 1), f = ci - i0;
  const a = M.dkCols[i0], b = M.dkCols[i1];
  const hl = $['dk.colHl'];
  op(hl, win(t, C[0] - 0.15, C[0] + 0.05, T.s4.move[0], T.s4.move[0] + 0.3));
  tf(hl, 'translate(' + px(lerp(a.x, b.x, f) - 3) + ',' + px(a.y - 3) + ')');
  css(hl, 'width', px(lerp(a.w, b.w, f) + 6)); css(hl, 'height', px(M.dkTableH - a.y + 3));
}

/* ---------------------------------------------------------------- overlays (screen space) */
function ovWin(el, t, w4, ein) { const w = win(t, w4[0], w4[1], w4[2], w4[3], ein || E.outCubic, E.inCubic); op(el, w); return w; }
function renderOverlays(t) {
  // fade in from black; a soft dip marks the direct cut inside segment 5
  op($['ov.dip'], Math.max(1 - seg(t, 0, 0.6, E.inOutSine), 0.45 * win(t, T.s5.cut - 0.12, T.s5.cut, T.s5.cut, T.s5.cut + 0.18, E.inQuad, E.outQuad)));
  // system label
  let sw = 0, sv = SYS[0];
  for (const s of SYS) { const w = win(t, s[0], s[0] + 0.3, s[1] - 0.3, s[1]); if (w > sw) { sw = w; sv = s; } }
  op($['ov.sys'], sw); txt($['ov.sysName'], sv[2]); txt($['ov.sysView'], sv[3]);
  tf($['ov.sys'], 'translate(64px,40px)');
  // scrim behind text panels that sit over the NADI map
  op($['ov.scrim'], Math.max(win(t, T.s1.q[0] - 0.2, T.s1.q[1], T.s1.q[2], T.s1.q[3] + 0.2), win(t, T.s6.left[0] - 0.2, T.s6.left[1], T.s6.left[2], T.s6.left[3] + 0.2)));
  // 1 · the supervisor's question (held ≥ 4 s)
  const q = ovWin($['ov.question'], t, T.s1.q);
  tf($['ov.question'], 'translate(100px,' + px(330 + 22 * (1 - q)) + ')');
  // 2 · one phone
  const w1 = ovWin($['ov.one'], t, T.s2.one);
  tf($['ov.one'], 'translate(130px,' + px(370 + 22 * (1 - w1)) + ')');
  // 3 · the record being built, line by line, then saved (held ≥ 4 s)
  const S3 = T.s3;
  const rw = ovWin($['ov.rec'], t, S3.recWin);
  tf($['ov.rec'], 'translate(100px,' + px(180 + 16 * (1 - rw)) + ')');
  for (let i = 0; i < 5; i++) {
    // each field starts as a grey placeholder and turns into the entered value
    const filled = t >= S3.rec[i], a = seg(t, S3.rec[i], S3.rec[i] + 0.35, E.outCubic);
    cls($['ov.rl' + i], 'pending', !filled);
    vis($['ov.rlp' + i], !filled); vis($['ov.rlv' + i], filled);
    op($['ov.rl' + i], filled ? lerp(0.4, 1, a) : 0.4);
    tf($['ov.rlv' + i], 'translateX(' + px(-14 * (1 - a)) + ')');
    cls($['ov.rl' + i], 'fresh', filled && t < Math.min(S3.rec[i] + 1.8, i < 4 ? S3.rec[i + 1] : 1e9));
  }
  op($['ov.recSaved'], seg(t, S3.saved, S3.saved + 0.25));
  const sv2 = ovWin($['ov.saved'], t, [S3.saved, S3.saved + 0.3, 61.75, 62.1], E.outBack);
  tf($['ov.saved'], 'translate(100px,' + px(180 + M.recH + 20 + 14 * (1 - sv2)) + ')');
  // 4 · aggregate result: one stable view from 01:08 to 01:23
  ovWin($['ov.res'], t, T.s4.res);
  tf($['ov.res'], 'translate(100px,170px)');
  // 5 · verification recorded (held ≥ 4 s); time saved preparing the report
  const vw = ovWin($['ov.ver'], t, T.s5.ver, E.outBack);
  tf($['ov.ver'], 'translate(100px,' + px(420 + 12 * (1 - vw)) + ')');
  const jw = ovWin($['ov.jimat'], t, T.s5.jimat);
  tf($['ov.jimat'], 'translate(120px,' + px(300 + 22 * (1 - jw)) + ')');
  // 6 · six premises left (held ≥ 5 s) and the supervisor's decision
  const lw = ovWin($['ov.left'], t, T.s6.left);
  tf($['ov.left'], 'translate(100px,' + px(150 + 16 * (1 - lw)) + ')');
  const dw = seg(t, T.s6.planned[0], T.s6.planned[1], E.outCubic);
  op($['ov.dec'], dw); tf($['ov.dec'], 'translateY(' + px(12 * (1 - dw)) + ')');
  // 7 · closing title, held to the last frame
  const cl = $['ov.closing'];
  op(cl, seg(t, T.s7.in[0], T.s7.in[0] + 0.2)); tf(cl, 'translate(0px,210px)');
  CLOSING.forEach((el, i) => {
    const t0 = T.s7.title + [0, 0.1, 0.25, 0.35, 0.45][i], a = seg(t, t0, t0 + 0.5, E.outCubic);
    op(el, a); tf(el, 'translateY(' + px(24 * (1 - a)) + ')' + (i === 0 ? ' scale(' + r2(lerp(0.85, 1, seg(t, t0, t0 + 0.8, E.springSoft))) + ')' : ''));
  });
}

/* ---------------------------------------------------------------- subtitles */
function renderSubs(t) {
  let best = null, a = 0;
  for (const c of CUES) {
    const w = win(t, c.start - 0.08, c.start + 0.1, c.end - 0.06, c.end + 0.1, E.outQuad, E.inQuad);
    if (w > a) { a = w; best = c; }
  }
  // bridge short gaps so the box does not flicker between phrases of one sentence
  if (!best) {
    let prev = null, next = null;
    for (const c of CUES) { if (c.end <= t) prev = c; if (!next && c.start > t) next = c; }
    if (prev && next && next.start - prev.end < 0.65 && t - prev.end < 0.65) { best = prev; a = 0; }
  }
  const show = typeof window === 'undefined' || window.ACD_SUBS !== false;
  op($['subsBox'], show ? a : 0);
  if (best) txt($['subsBox'], best.sub);
  let sh = 0;
  for (const c of CUES) sh = Math.max(sh, win(t, c.start - 0.4, c.start, c.end, c.end + 0.5, E.inOutSine, E.inOutSine));
  op($['subShade'], show ? 0.9 * sh : 0);
}

/* ==========================================================================
 * FRAME
 * ========================================================================== */
let lastFrame = -1;
function renderTime(t) {
  t = clamp(t, 0, DURATION - 1 / FPS);
  const o = layerOps(t);
  renderBg(t);
  renderManual(t, o.man);
  renderNadi(t, o.nadi);
  renderDesktop(t, o.desk);
  renderPhone(t, o.phone);
  renderOverlays(t);
  renderSubs(t);
}
function renderFrame(frameIndex) {
  const f = Math.max(0, Math.min(TOTAL_FRAMES - 1, Math.floor(frameIndex)));
  lastFrame = f;
  renderTime(f / FPS);
  return f;
}

/* ---------------------------------------------------------------- init */
function initStage(stage) {
  stage.innerHTML = buildStage();
  collectRefs(stage);
  buildBackground();
  buildNadiMap();
  buildManual();
}
function initMeasure() {
  measure();
  computeCameras();
  computeScrollTargets();
}
