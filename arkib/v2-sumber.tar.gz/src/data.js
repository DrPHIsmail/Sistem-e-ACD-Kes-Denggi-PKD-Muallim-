/* ==========================================================================
 * data.js — single source of truth for the 120-second NADI Muallim film.
 * Narration (verbatim from the edit plan), caption phrases, segment times,
 * the synthetic Kg. Ketoyong scenario and the calculations copied from the
 * e-ACD source. Every figure is SYNTHETIC ("Data Simulasi").
 * If src/narration-timing.json exists (written by tools/sync-narration.js
 * from the recorded takes), its cue times replace the planned ones, so the
 * player, captions, script, SRT and MP4 all follow the recording.
 * ========================================================================== */

const FPS = 60;
const DURATION = 120;                // 02:00.000
const TOTAL_FRAMES = FPS * DURATION; // 7200 frames: 0 .. 7199

/* Segments from the edit plan (seconds). E's internal split moved from 93.0 to
 * 90.4 so its narration fits at ≈5.2 syllables/s (see README). */
const SCENES = [
  { id: 1, start: 0,   end: 12,  key: 'Soalan',  title: 'NADI: soalan operasi lokaliti' },
  { id: 2, start: 12,  end: 28,  key: 'Telefon', title: 'Daripada borang kepada satu telefon' },
  { id: 3, start: 28,  end: 62,  key: 'Rekod',   title: 'Satu rekod lawatan premis' },
  { id: 4, start: 62,  end: 84,  key: 'Liputan', title: 'Kiraan agregat dan liputan ACD' },
  { id: 5, start: 84,  end: 103, key: 'Laporan', title: 'Pengesahan dan ringkasan' },
  { id: 6, start: 103, end: 114, key: 'Susulan', title: 'Keputusan penyelia di NADI' },
  { id: 7, start: 114, end: 120, key: 'Penutup', title: 'Penutup' }
];
const SPLIT_E = 90.4; // Bahagian D view → WhatsApp summary view

/* e-ACD locality metadata (source app state.meta). */
const META = { locality: 'Kg. Ketoyong', date: '04/11/2026 (Rabu)', time: '5.00 petang', meetingPoint: 'Surau Kg. Ketoyong (Peta)', requiredStaff: 16 };

/* Synthetic team totals (same set as the 90-second film). The followed visit is part of Pasukan 1. */
const TEAMS = {
  1: { locality: 20, visited: 17, locked: 2, pop: 61, symp: 1, ref: 1, sample: 0, breeding: 3, abate: 3, pamphlet: 17 },
  2: { locality: 18, visited: 15, locked: 2, pop: 55, symp: 0, ref: 0, sample: 0, breeding: 2, abate: 2, pamphlet: 15 },
  3: { locality: 19, visited: 16, locked: 2, pop: 58, symp: 1, ref: 1, sample: 0, breeding: 3, abate: 2, pamphlet: 16 },
  4: { locality: 17, visited: 14, locked: 2, pop: 50, symp: 0, ref: 0, sample: 0, breeding: 1, abate: 1, pamphlet: 14 },
  5: { locality: 18, visited: 15, locked: 2, pop: 56, symp: 1, ref: 1, sample: 0, breeding: 3, abate: 3, pamphlet: 15 },
  6: { locality: 18, visited: 15, locked: 2, pop: 57, symp: 0, ref: 0, sample: 0, breeding: 2, abate: 2, pamphlet: 15 }
};
const TEAM1_BEFORE = { locality: 19, visited: 16, locked: 2, pop: 56, symp: 0, ref: 0, sample: 0, breeding: 2, abate: 2, pamphlet: 16 };
const HOUSE_DEMO = {
  team: 1, address: 'Premis Contoh 012', status: '1', occupants: 5,
  symptoms: ['Demam panas mengejut', 'Sakit kepala teruk', 'Sakit sendi/tulang/otot'],
  symptomCount: 1, referredCount: 1, sampleCount: 0, breeding: true, abate: true, pamphlet: true, fieldAction: 'Rujuk Klinik Kesihatan'
};
const SYMPTOMS = ['Demam panas mengejut', 'Sakit kepala teruk', 'Sakit di belakang mata', 'Sakit sendi/tulang/otot',
  'Ruam bintik merah', 'Loya/muntah', 'Pendarahan gusi/hidung', 'Sakit perut teruk'];
const STATUS_CODES = [
  { code: '1', label: '1 - Dilawati' }, { code: '2', label: '2 - Berkunci' }, { code: '3', label: '3 - Kosong' },
  { code: '4', label: '4 - Enggan' }, { code: '6', label: '6 - Tanah/Lot Kosong' }
];
const VERIFICATION = { officerName: 'Pegawai Contoh', officerRole: 'Penolong Pegawai Kesihatan Persekitaran (PPKP)', date: '04/11/2026' };

/* ---- NADI locality card (OutbreakMap.tsx floating card), synthetic values only.
 * Kg. Ketoyong does not appear in the NADI repository's data. */
const NADI_CARD = {
  statusLabel: 'Wabak Aktif (WT)', name: 'Kg. Ketoyong', area: 'Daerah Muallim · paparan demonstrasi',
  outbreakCases: 3, cumulativeCases: 4, lastNotification: '02-11-2026', epidWeek: 44, expectedEnd: '16-11-2026', daysSince: 2,
  premisesInspected: 64, ptpP1: '03-11-2026', ptpP2: 'Tiada maklumat', srtP1: '03-11-2026', srtP2: 'Tiada maklumat'
};
/* Simulated target premises still to visit (follow-up list). */
const FOLLOW_UP = ['Premis Contoh 018', 'Premis Contoh 033', 'Premis Contoh 061', 'Premis Contoh 074', 'Premis Contoh 096', 'Premis Contoh 105'];

/* ---- calculations copied from the e-ACD source (computeTotals / calcTeamPct) */
function calcTeamPct(teamObj) {
  if (!teamObj || !teamObj.locality || teamObj.locality <= 0) return null;
  return Math.round((teamObj.visited / teamObj.locality) * 100);
}
function computeTotals(teams) {
  const totals = { locality: 0, visited: 0, locked: 0, pop: 0, symp: 0, ref: 0, sample: 0, breeding: 0, abate: 0, pamphlet: 0, activeTeams: 0 };
  for (let t = 1; t <= 6; t++) {
    const d = teams[t];
    for (const k of ['locality', 'visited', 'locked', 'pop', 'symp', 'ref', 'sample', 'breeding', 'abate', 'pamphlet']) totals[k] += Number(d[k]) || 0;
    if ((Number(d.locality) || 0) > 0 || (Number(d.visited) || 0) > 0) totals.activeTeams++;
  }
  totals.pct = totals.locality > 0 ? Math.round((totals.visited / totals.locality) * 100) : 0;
  totals.unvisited = Math.max(0, totals.locality - totals.visited - totals.locked);
  return totals;
}
const TOTALS = computeTotals(TEAMS);
const TARGET_PCT = 80; // shown only as "Sasaran dalam aplikasi"

function buildWhatsappSummary(meta, totals) {
  return [
    '*LAPORAN RINGKASAN ACD DENGGI - PKD MUALLIM*',
    '📍 Lokaliti: ' + meta.locality,
    '📅 Tarikh/Masa: ' + meta.date + ' (' + meta.time + ')',
    '',
    '*RINGKASAN DAPATAN KESELURUHAN:*',
    '1. Jumlah Rumah/Premis dalam Lokaliti: ' + totals.locality + ' buah',
    '2. Jumlah Rumah/Premis Dilawati: ' + totals.visited + ' buah',
    '3. Jumlah Rumah/Premis Berkunci/Kosong: ' + totals.locked + ' buah',
    '4. Jumlah Penduduk Diperiksa (ACD): ' + totals.pop + ' orang',
    '5. Jumlah Kes Bergejala Dikesan: ' + totals.symp + ' orang',
    '6. Jumlah Rujukan Fasiliti Kesihatan: ' + totals.ref + ' orang',
    '7. Jumlah Sampel Diambil: ' + totals.sample + ' sampel',
    '📊 *Pencapaian ACD (%): ' + totals.pct + '%*',
    '',
    '*Pemeriksaan Persekitaran (Bahagian C):*',
    '• Takungan Berpotensi Aedes: ' + totals.breeding + ' premis',
    '• Tindakan Abate Diberi: ' + totals.abate + ' premis',
    '• Risalah Kesihatan Diedar: ' + totals.pamphlet + ' premis'
  ].join('\n');
}

/* ==========================================================================
 * NARRATION — verbatim from the edit plan, split into caption phrases.
 * `say` is spoken (numbers in words); `sub` is the caption (≤ 2 lines).
 * Planned times fit ≤ 5.4 syllables/second; tools/sync-narration.js replaces
 * them with times measured from the recorded scene takes.
 * ========================================================================== */
const CUES = [
  // 1 · 00:00–00:12
  { id: '1a', scene: 1, start: 0.60,   end: 3.65,   say: 'Selepas operasi pengesanan kes aktif denggi,', sub: 'Selepas operasi pengesanan\nkes aktif denggi,' },
  { id: '1b', scene: 1, start: 3.75,   end: 6.40,   say: 'penyelia perlu tahu dua perkara.', sub: 'penyelia perlu tahu dua perkara.' },
  { id: '1c', scene: 1, start: 6.90,   end: 8.85,   say: 'Premis mana sudah dilawati,', sub: 'Premis mana sudah dilawati,' },
  { id: '1d', scene: 1, start: 8.95,   end: 11.55,  say: 'dan di mana pasukan masih perlu turun?', sub: 'dan di mana pasukan masih perlu turun?' },
  // 2 · 00:12–00:28
  { id: '2a', scene: 2, start: 12.30,  end: 15.45,  say: 'Borang dan fail rekod perlu dibawa ke lapangan.', sub: 'Borang dan fail rekod\nperlu dibawa ke lapangan.' },
  { id: '2b', scene: 2, start: 15.60,  end: 19.20,  say: 'Selepas lawatan, angka dikira dan ditaip semula.', sub: 'Selepas lawatan, angka dikira\ndan ditaip semula.' },
  { id: '2c', scene: 2, start: 19.70,  end: 24.20,  say: 'Dengan e-ACD, petugas merekod lawatan terus pada telefon.', sub: 'Dengan e-ACD, petugas merekod\nlawatan terus pada telefon.' },
  // 3 · 00:28–01:02
  { id: '3a', scene: 3, start: 28.40,  end: 32.40,  say: 'Petugas memilih pasukan dan merekod status lawatan premis.', sub: 'Petugas memilih pasukan dan\nmerekod status lawatan premis.' },
  { id: '3b', scene: 3, start: 38.40,  end: 41.60,  say: 'Dalam contoh ini, seorang penghuni bergejala', sub: 'Dalam contoh ini,\nseorang penghuni bergejala' },
  { id: '3c', scene: 3, start: 41.70,  end: 44.10,  say: 'dan rujukannya ke klinik direkodkan.', sub: 'dan rujukannya ke klinik direkodkan.' },
  { id: '3d', scene: 3, start: 48.40,  end: 53.20,  say: 'Petugas turut mencatat semakan takungan Aedes dan tindakan lapangan.', sub: 'Petugas turut mencatat semakan\ntakungan Aedes dan tindakan lapangan.' },
  { id: '3e', scene: 3, start: 56.40,  end: 57.80,  say: 'Apabila disimpan,', sub: 'Apabila disimpan,' },
  { id: '3f', scene: 3, start: 57.90,  end: 61.80,  say: 'dapatan lawatan ini terus masuk dalam kiraan pasukan.', sub: 'dapatan lawatan ini terus masuk\ndalam kiraan pasukan.' },
  // 4 · 01:02–01:24
  { id: '4a', scene: 4, start: 62.40,  end: 66.60,  say: 'Sistem menjumlahkan dapatan enam pasukan secara automatik.', sub: 'Sistem menjumlahkan dapatan\nenam pasukan secara automatik.' },
  { id: '4b', scene: 4, start: 67.30,  end: 69.30,  say: 'Dalam simulasi ini,', sub: 'Dalam simulasi ini,' },
  { id: '4c', scene: 4, start: 69.40,  end: 74.30,  say: 'sembilan puluh dua daripada seratus sepuluh premis telah dilawati.', sub: '92 daripada 110 premis\ntelah dilawati.' },
  { id: '4d', scene: 4, start: 74.70,  end: 77.80,  say: 'Liputannya ialah lapan puluh empat peratus.', sub: 'Liputannya ialah 84 peratus.' },
  // 5 · 01:24–01:43
  { id: '5a', scene: 5, start: 84.40,  end: 87.20,  say: 'Pegawai menyemak dan merekod pengesahan.', sub: 'Pegawai menyemak dan merekod pengesahan.' },
  { id: '5b', scene: 5, start: 90.70,  end: 95.30,  say: 'Ringkasan boleh disalin untuk dikongsi melalui WhatsApp dari telefon.', sub: 'Ringkasan boleh disalin untuk dikongsi\nmelalui WhatsApp dari telefon.' },
  { id: '5c', scene: 5, start: 95.50,  end: 97.20,  say: 'Petugas menjimatkan masa', sub: 'Petugas menjimatkan masa' },
  { id: '5d', scene: 5, start: 97.30,  end: 100.70, say: 'kerana maklumat lawatan yang sama terus digunakan', sub: 'kerana maklumat lawatan yang sama\nterus digunakan' },
  { id: '5e', scene: 5, start: 100.80, end: 102.80, say: 'untuk menyediakan laporan.', sub: 'untuk menyediakan laporan.' },
  // 6 · 01:43–01:54
  { id: '6a', scene: 6, start: 103.10, end: 105.35, say: 'Dalam prototaip integrasi ini,', sub: 'Dalam prototaip integrasi ini,' },
  { id: '6b', scene: 6, start: 105.45, end: 109.55, say: 'penyelia melihat baki operasi bagi lokaliti yang sama', sub: 'penyelia melihat baki operasi\nbagi lokaliti yang sama' },
  { id: '6c', scene: 6, start: 109.65, end: 113.95, say: 'dan merancang lawatan susulan untuk enam premis yang belum dilawati.', sub: 'dan merancang lawatan susulan untuk\nenam premis yang belum dilawati.' },
  // 7 · 01:54–02:00
  { id: '7a', scene: 7, start: 114.30, end: 115.50, say: 'NADI Muallim.', sub: 'NADI Muallim.' },
  { id: '7b', scene: 7, start: 115.70, end: 119.60, say: 'Dari survelan denggi kepada tindakan susulan di lapangan.', sub: 'Dari survelan denggi kepada\ntindakan susulan di lapangan.' }
];
const PLANNED = CUES.map(c => ({ id: c.id, start: c.start, end: c.end }));

/* Optional: cue times measured from the recorded takes (tools/sync-narration.js). */
let NARRATION_SOURCE = 'planned';
function applyTiming(t) {
  if (!t || !t.cues) return;
  let n = 0;
  for (const c of CUES) { const o = t.cues[c.id]; if (o && o.end > o.start) { c.start = o.start; c.end = o.end; n++; } }
  if (n) NARRATION_SOURCE = 'recording';
}
if (typeof NARRATION_TIMING !== 'undefined') applyTiming(NARRATION_TIMING);             // injected by the build
if (typeof module !== 'undefined') { try { applyTiming(require('./narration-timing.json')); } catch (e) { /* planned times */ } }

/* Narration per scene (one take per scene). */
const NARRATION = SCENES.map(s => {
  const cs = CUES.filter(c => c.scene === s.id);
  return { id: 'N' + s.id, scene: s.id, cues: cs.map(c => c.id), start: cs[0].start, end: cs[cs.length - 1].end, say: cs.map(c => c.say).join(' ') };
});

if (typeof module !== 'undefined') {
  module.exports = { FPS, DURATION, TOTAL_FRAMES, SCENES, SPLIT_E, META, TEAMS, TEAM1_BEFORE, TOTALS, TARGET_PCT, HOUSE_DEMO, SYMPTOMS, STATUS_CODES,
    VERIFICATION, NADI_CARD, FOLLOW_UP, CUES, PLANNED, NARRATION, calcTeamPct, computeTotals, buildWhatsappSummary,
    get NARRATION_SOURCE() { return NARRATION_SOURCE; } };
}
