#!/usr/bin/env node
/* Builds the self-contained video-showcase.html from src/:
 *   1. compiles Tailwind 3.4.17 utilities used by the mockups (offline),
 *   2. inlines Inter, Plus Jakarta Sans, JetBrains Mono (woff2, OFL) and the
 *      Jata Negara PNG as data URIs,
 *   3. injects src/narration-timing.json (if present, written by
 *      tools/sync-narration.js) so captions follow the recorded narration,
 *   4. concatenates data → markup → engine → audio → player into one <script>,
 *   5. refuses to write the file if live URLs, the spreadsheet ID, map
 *      coordinates or real staff names from the source apps leak into it.
 * Usage: node tools/build-player.js   (needs tailwindcss: npm install, or TAILWIND_BIN=/path/to/tailwindcss)
 */
'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'src');
const ASSETS = path.join(ROOT, 'assets');
const OUT = path.join(ROOT, 'video-showcase.html');

function tailwindBin() {
  const cands = [process.env.TAILWIND_BIN, path.join(ROOT, 'node_modules', '.bin', 'tailwindcss')].filter(Boolean);
  for (const c of cands) if (fs.existsSync(c)) return c;
  throw new Error('tailwindcss not found. Run "npm install" (devDependency tailwindcss@3.4.17) or set TAILWIND_BIN.');
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'eacd-build-'));
const cssOut = path.join(tmp, 'styles.css');
execFileSync(tailwindBin(), ['-c', path.join(__dirname, 'tailwind.config.js'), '-i', path.join(SRC, 'styles.css'), '-o', cssOut, '--minify'], { stdio: ['ignore', 'ignore', 'inherit'] });
let css = fs.readFileSync(cssOut, 'utf8');
// keep Tailwind's MIT attribution banner, minus the URL scheme (the output must contain no URLs at all)
css = css.replace(/https:\/\/tailwindcss\.com/g, 'tailwindcss.com');
const fonts = {
  __FONT_400__: 'Inter-Regular', __FONT_500__: 'Inter-Medium', __FONT_600__: 'Inter-SemiBold', __FONT_700__: 'Inter-Bold', __FONT_800__: 'Inter-ExtraBold',
  __PJS_400__: 'PlusJakartaSans-400', __PJS_500__: 'PlusJakartaSans-500', __PJS_600__: 'PlusJakartaSans-600', __PJS_700__: 'PlusJakartaSans-700', __PJS_800__: 'PlusJakartaSans-800',
  __JBM_400__: 'JetBrainsMono-Regular', __JBM_600__: 'JetBrainsMono-SemiBold', __JBM_700__: 'JetBrainsMono-Bold'
};
for (const [ph, f] of Object.entries(fonts)) {
  if (css.split(ph).length !== 2) throw new Error('expected one ' + ph + ' placeholder in CSS');
  css = css.replace(ph, fs.readFileSync(path.join(ASSETS, f + '.woff2')).toString('base64'));
}
if (/__(FONT|PJS|JBM)_\d+__/.test(css)) throw new Error('font placeholder left in CSS');

const order = ['data.js', 'markup.js', 'engine.js', 'audio.js', 'player.js'];
let js = order.map(f => '/* ---- ' + f + ' ---- */\n' + fs.readFileSync(path.join(SRC, f), 'utf8')).join('\n');
// measured narration timing (optional): cue start/end in seconds, keyed by cue id
const timingFile = path.join(SRC, 'narration-timing.json');
if (fs.existsSync(timingFile)) {
  const timing = JSON.parse(fs.readFileSync(timingFile, 'utf8'));
  js = '/* ---- narration-timing.json (from tools/sync-narration.js) ---- */\nconst NARRATION_TIMING = ' + JSON.stringify(timing) + ';\n' + js;
  console.log('narration timing: ' + Object.keys(timing.cues || {}).length + ' cues from the recording');
} else console.log('narration timing: planned (no src/narration-timing.json)');
const jata = 'data:image/png;base64,' + fs.readFileSync(path.join(ASSETS, 'jata-negara.png')).toString('base64');
if ((js.match(/__JATA__/g) || []).length !== 1) throw new Error('expected exactly one __JATA__ placeholder');
js = js.replace('__JATA__', jata);

let html = fs.readFileSync(path.join(SRC, 'template.html'), 'utf8');
html = html.replace('/*__CSS__*/', () => css).replace('/*__JS__*/', () => js);

// privacy / offline guards
const forbidden = [
  /https?:\/\//i, /script\.google/i, /google\.com\/maps/i, /3\.6993145/, /101\.510945/,
  /1w9P5Ikuv3gI312b_LhnG2Ko6VbHJr6j2NZEHVmpr8t8/,
  /LOGESVARAN|KUMARASAMY|SHAHIRAN|KHAIRULLAH|SOMUSUNDARAM|NAZREEN|SAIFUL BIN|HARTINI|IRDAWATY|SURYANI|AFZAN|NURUL DIANA|SAFIYYAH|HAPIZAH|AZLIN BINTI|AZRI A\/L/i
];
for (const re of forbidden) {
  const m = html.match(re);
  if (m) throw new Error('forbidden content in output: ' + re + ' near "' + html.substr(Math.max(0, m.index - 40), 100) + '"');
}
fs.writeFileSync(OUT, html);
fs.rmSync(tmp, { recursive: true, force: true });
console.log('wrote ' + path.relative(process.cwd(), OUT) + ' (' + (fs.statSync(OUT).size / 1024).toFixed(0) + ' KB)');
