#!/usr/bin/env node
/* Automated checks for video-showcase.html (run: node tools/check-player.js).
 * A offline load · B data and calculations · C labels and captions ·
 * H holds from the edit plan, measured frame by frame (≥ 4 s, ≥ 5 s, the
 * 01:08–01:16 coverage view, still cameras) · D frame determinism ·
 * E audio · F player controls · G narration timing. Exit code 1 on failure. */
'use strict';
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { pathToFileURL } = require('url');
const { chromium } = require('playwright');

const HTML = path.resolve(__dirname, '..', 'video-showcase.html');
const URL = pathToFileURL(HTML).href;
const results = [];
const check = (name, ok, detail) => { results.push({ name, ok: !!ok, detail: detail === undefined ? '' : String(detail) }); };
const sha = b => crypto.createHash('sha1').update(b).digest('hex');
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function open(browser, query) {
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  const blocked = [], errors = [];
  await ctx.route('**/*', r => { const u = r.request().url(); if (/^(file|data|blob):/i.test(u)) return r.continue(); blocked.push(u); return r.abort(); });
  const page = await ctx.newPage();
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(URL + (query || ''));
  await page.evaluate(() => window.ACD.ready);
  return { ctx, page, blocked, errors, cdp: await ctx.newCDPSession(page) };
}
const shot = async X => sha(Buffer.from((await X.cdp.send('Page.captureScreenshot', { format: 'png' })).data, 'base64'));

/* in-page helpers: effective opacity and on-stage visibility of an element */
const PAGE_HELPERS = () => {
  window.__eff = el => {
    if (!el || !el.getClientRects().length) return 0;
    let o = 1, e = el;
    while (e && e.id !== 'stage') { const cs = getComputedStyle(e); if (cs.display === 'none' || cs.visibility === 'hidden') return 0; o *= parseFloat(cs.opacity); e = e.parentElement; }
    const r = el.getBoundingClientRect();
    if (r.right < 0 || r.left > 1920 || r.bottom < 0 || r.top > 1080) return 0;
    return o;
  };
  window.__ref = r => document.querySelector('[data-ref="' + r + '"]');
  window.__textVisible = (needle, min) => Array.from(document.querySelectorAll('#stage *')).some(el => el.childElementCount === 0 && el.textContent.includes(needle) && window.__eff(el) >= (min || 0.98));
};
/* longest continuous run (seconds) in [t0, t1] where pred(frame) holds, sampled every frame */
async function longestRun(page, t0, t1, predSrc) {
  return page.evaluate(([a, b, src]) => {
    const pred = new Function('t', src);
    let best = 0, cur = 0, bestStart = -1, curStart = -1;
    for (let f = Math.round(a * 60); f <= Math.round(b * 60); f++) {
      window.renderFrame(f);
      if (pred(f / 60)) { if (cur === 0) curStart = f / 60; cur++; if (cur > best) { best = cur; bestStart = curStart; } } else cur = 0;
    }
    return { sec: best / 60, from: bestStart, to: bestStart + best / 60 };
  }, [t0, t1, predSrc]);
}

(async () => {
  const browser = await chromium.launch({ args: ['--autoplay-policy=user-gesture-required'] });
  try {
    /* ---------------- A. offline load */
    const R = await open(browser, '?render=1');
    await R.page.evaluate(PAGE_HELPERS);
    const html = fs.readFileSync(HTML, 'utf8');
    check('A1 opens from file:// with every network request blocked', R.blocked.length === 0, R.blocked.length + ' request(s) attempted');
    check('A2 no live URL / spreadsheet ID / map coordinates in the file', !/https?:\/\/|1w9P5Ikuv3gI312b|3\.6993145|101\.510945/i.test(html));
    const meta = await R.page.evaluate(() => ({ fps: window.ACD.FPS, frames: window.ACD.TOTAL_FRAMES, dur: window.ACD.DURATION, scenes: SCENES.map(s => s.start).concat(SCENES[SCENES.length - 1].end) }));
    check('A3 timeline 120 s × 60 fps = 7,200 frames', meta.fps === 60 && meta.frames === 7200 && meta.dur === 120, JSON.stringify({ fps: meta.fps, frames: meta.frames, dur: meta.dur }));
    check('A4 segments at 00:00 00:12 00:28 01:02 01:24 01:43 01:54 02:00', meta.scenes.join() === '0,12,28,62,84,103,114,120', meta.scenes.join(' '));

    /* ---------------- B. data and calculations (synthetic set) */
    const T = await R.page.evaluate(() => window.ACD.TOTALS);
    check('B1 totals 110 / 92 / 12 / 337 / 3 / 3', T.locality === 110 && T.visited === 92 && T.locked === 12 && T.pop === 337 && T.symp === 3 && T.ref === 3, JSON.stringify(T));
    check('B2 coverage ROUND(92/110×100) = 84%', T.pct === 84 && Math.round(92 / 110 * 100) === 84, (92 / 110 * 100).toFixed(3) + '% → ' + T.pct + '%');
    const fu = await R.page.evaluate(() => FOLLOW_UP.length);
    check('B3 6 premises not visited = 110 − 92 − 12, and 6 follow-up premises listed', T.unvisited === 6 && fu === 6, 'unvisited ' + T.unvisited + ', list ' + fu);
    const teamPct = await R.page.evaluate(() => [1, 2, 3, 4, 5, 6].map(t => calcTeamPct(TEAMS[t])));
    check('B4 team coverage 85/83/84/82/83/83 %', teamPct.join() === '85,83,84,82,83,83', teamPct.join(' '));
    const before = await R.page.evaluate(() => ({ t1: TEAM1_BEFORE.visited + '/' + TEAM1_BEFORE.locality, t1after: TEAMS[1].visited + '/' + TEAMS[1].locality, pct: TOTALS_BEFORE.pct, v: TOTALS_BEFORE.visited, l: TOTALS_BEFORE.locality }));
    check('B5 the saved record moves Pasukan 1 from 16/19 to 17/20 (source: locality +1, visited +1)', before.t1 === '16/19' && before.t1after === '17/20' && before.v === 91 && before.l === 109, JSON.stringify(before));
    await R.page.evaluate(() => window.renderFrame(70 * 60));
    const dom = await R.page.evaluate(() => { const g = r => window.__ref(r).textContent.trim(); return { pct: g('dk.kpiPct'), ratio: g('dk.kpiRatio'), badge: g('dk.kpiBadge'), loc: g('dk.mLoc'), vis: g('dk.mVis'), pop: g('dk.mPop'), tt0: g('dk.tt0'), tt1: g('dk.tt1'), tt7: g('dk.tt7') }; });
    check('B6 e-ACD dashboard at 01:10 shows 84%, (92 / 110 premis), "Sasaran dalam aplikasi ≥ 80%"', dom.pct === '84%' && dom.ratio === '(92 / 110 premis)' && dom.badge === 'Sasaran dalam aplikasi ≥ 80%', JSON.stringify(dom));
    check('B7 six-team table totals 110 / 92 / 84%', dom.tt0 === '110' && dom.tt1 === '92' && dom.tt7 === '84%' && dom.loc === '110' && dom.vis === '92' && dom.pop === '337');
    await R.page.evaluate(() => window.renderFrame(111 * 60));
    const card = await R.page.evaluate(() => ['na.kTarget', 'na.kVisited', 'na.kLocked', 'na.kLeft'].map(r => window.__ref(r).querySelector('.na-kpi-n').textContent.trim()));
    check('B8 NADI card (prototype) shows 110 sasaran / 92 dilawati / 12 berkunci-kosong / 6 belum dilawati', card.join() === '110,92,12,6', card.join(' / '));
    const wa = await R.page.evaluate(() => buildWhatsappSummary(META, TOTALS));
    check('B9 WhatsApp summary built like the source (84%, 110, 92, 337)', /Pencapaian ACD \(%\): 84%/.test(wa) && /Lokaliti: 110 buah/.test(wa) && /Dilawati: 92 buah/.test(wa) && /337 orang/.test(wa));

    /* ---------------- C. labels and captions */
    const simAt = [5, 10, 21, 33, 45, 59, 64, 72, 80, 87, 96, 106, 112];
    const simVis = [];
    for (const t of simAt) { await R.page.evaluate(f => window.renderFrame(f), Math.round(t * 60)); simVis.push(await R.page.evaluate(() => Array.from(document.querySelectorAll('#stage .sim-badge')).some(el => window.__eff(el) > 0.5))); }
    check('C1 "DATA SIMULASI" on screen at ' + simAt.join(', ') + ' s', simVis.every(Boolean), simVis.map((v, i) => simAt[i] + 's:' + (v ? 'ya' : 'TIDAK')).join(' '));
    const protoAt = [[104.5, true], [108, true], [112, true], [113.5, true], [5, false], [60, false], [96, false]];
    const protoVis = [];
    for (const [t] of protoAt) { await R.page.evaluate(f => window.renderFrame(f), Math.round(t * 60)); protoVis.push(await R.page.evaluate(() => Array.from(document.querySelectorAll('#stage .proto-badge')).some(el => window.__eff(el) > 0.5))); }
    check('C2 "PROTOTAIP INTEGRASI" shown with the e-ACD summary in NADI, and only there', protoVis.every((v, i) => v === protoAt[i][1]), protoVis.map((v, i) => protoAt[i][0] + 's:' + (v ? 'ya' : 'tidak')).join(' '));
    const caps = await R.page.evaluate(() => ({ lines: CUES.every(c => c.sub.split('\n').length <= 2), inScene: CUES.every(c => { const s = SCENES.find(q => q.id === c.scene); return c.start >= s.start && c.end <= s.end; }), ordered: CUES.every((c, i) => !i || c.start >= CUES[i - 1].end) }));
    check('C3 captions: ≤ 2 lines, inside their segment, in order without overlap', caps.lines && caps.inScene && caps.ordered, JSON.stringify(caps));
    const capOk = [];
    for (const id of ['1d', '3c', '4c', '5b', '6c', '7b']) {
      const c = await R.page.evaluate(i => CUES.find(q => q.id === i), id);
      await R.page.evaluate(f => window.renderFrame(f), Math.round((c.start + c.end) / 2 * 60));
      capOk.push(await R.page.evaluate(sub => { const b = window.__ref('subsBox'); return b.textContent === sub && parseFloat(getComputedStyle(b).opacity) > 0.95; }, c.sub));
    }
    check('C4 caption on screen matches its narration cue (6 samples)', capOk.every(Boolean), capOk.join(' '));
    const target = await R.page.evaluate(() => { window.renderFrame(72 * 60); return { badge: window.__textVisible('Sasaran dalam aplikasi ≥ 80%', 0.9), res: window.__textVisible('Sasaran dalam aplikasi: 80%', 0.9), bare: /Capai Sasaran|Sasaran ≥ 80%/.test(document.getElementById('stage').textContent) }; });
    check('C5 the 80% threshold is labelled "Sasaran dalam aplikasi"', target.badge && target.res && !target.bare, JSON.stringify(target));

    /* ---------------- H. holds from the edit plan (every frame) */
    const vis = r => 'return window.__eff(window.__ref("' + r + '")) >= 0.98;';
    let h = await longestRun(R.page, 5, 12.5, vis('ov.question'));
    check('H1 "Premis mana masih perlu dilawati?" held ≥ 4 s', h.sec >= 4, h.sec.toFixed(2) + ' s (' + h.from.toFixed(2) + '–' + h.to.toFixed(2) + ')');
    h = await longestRun(R.page, 56, 62.2, vis('ov.saved'));
    check('H2 "Rekod disimpan" held ≥ 4 s', h.sec >= 4, h.sec.toFixed(2) + ' s (' + h.from.toFixed(2) + '–' + h.to.toFixed(2) + ')');
    h = await longestRun(R.page, 66, 84, 'const r = window.__ref("ov.res"); return window.__eff(r) >= 0.98 && r.querySelector(".res-pct").textContent.replace(/\\s+/g, " ").trim() === "84% liputan ACD" && ' +
      'r.querySelector(".res-ratio").textContent.trim() === "92 daripada 110 premis dilawati" && window.__eff(r.querySelector(".sim-badge")) >= 0.98;');
    check('H3 "92 daripada 110 premis dilawati" + "84% liputan ACD" + Data Simulasi together from ≤ 01:08 to ≥ 01:16', h.sec >= 6 && h.from <= 68.0 && h.to >= 76.0, h.sec.toFixed(2) + ' s (' + h.from.toFixed(2) + '–' + h.to.toFixed(2) + ')');
    const camSrc = layer => 'const v = window.__ref("' + layer + '").style.transform; if (window.__c === undefined || t === window.__t0) { window.__c = v; } return v === window.__c;';
    await R.page.evaluate(() => { window.__t0 = 68; });
    h = await longestRun(R.page, 68, 76, camSrc('w.desk'));
    check('H4 camera still during the coverage hold 01:08–01:16', h.sec >= 7.98, h.sec.toFixed(2) + ' s unchanged');
    const ver = await longestRun(R.page, 85, 90.5, vis('ov.ver'));
    const paste = await longestRun(R.page, 92, 103.2, 'return window.__eff(window.__ref("ph.bubble")) >= 0.98;');
    check('H5 segment 5 results held ≥ 4 s (verification, pasted summary)', ver.sec >= 4 && paste.sec >= 4, 'pengesahan ' + ver.sec.toFixed(2) + ' s, ringkasan ' + paste.sec.toFixed(2) + ' s');
    h = await longestRun(R.page, 103, 114.2, vis('ov.left'));
    const dec = await longestRun(R.page, 103, 114.2, 'const d = window.__ref("ov.dec"); return window.__eff(d) >= 0.98 && d.textContent.includes("Rancang lawatan susulan");');
    check('H6 "6 premis belum dilawati" held ≥ 5 s; decision "Rancang lawatan susulan" shown', h.sec >= 5 && dec.sec >= 3, h.sec.toFixed(2) + ' s; keputusan ' + dec.sec.toFixed(2) + ' s');
    h = await longestRun(R.page, 113.5, 119.99, 'return window.__textVisible("NADI") && window.__textVisible("Dari Survelan ke Respons Denggi") && window.__textVisible("Pejabat Kesihatan Daerah Muallim");');
    check('H7 closing title, tagline and PKD name held to the last frame', h.sec >= 5.0 && h.to >= 119.98, h.sec.toFixed(2) + ' s (' + h.from.toFixed(2) + '–' + h.to.toFixed(2) + ')');
    await R.page.evaluate(() => { window.__t0 = 28.8; window.__c = undefined; });
    const still3 = await longestRun(R.page, 28.8, 57.2, camSrc('w.phone'));
    await R.page.evaluate(() => { window.__t0 = 4.4; window.__c = undefined; });
    const still1 = await longestRun(R.page, 4.4, 11.6, camSrc('w.nadi'));
    await R.page.evaluate(() => { window.__t0 = 103.4; window.__c = undefined; });
    const still6 = await longestRun(R.page, 103.4, 113.7, camSrc('w.nadi'));
    check('H8 camera holds still while the record is entered and while NADI is read', still3.sec >= 28.3 && still1.sec >= 7.1 && still6.sec >= 10.2, 'rekod ' + still3.sec.toFixed(1) + ' s, NADI ' + still1.sec.toFixed(1) + ' s / ' + still6.sec.toFixed(1) + ' s');
    const seq = await R.page.evaluate(() => { const r = []; for (const t of [30.5, 41, 50, 52, 58.5]) { window.renderFrame(Math.round(t * 60)); r.push([0, 1, 2, 3, 4].filter(i => !window.__ref('ov.rl' + i).classList.contains('pending')).length); } return r; });
    check('H9 the record card fills one field at a time with the narration', seq.join() === '0,2,3,5,5', 'medan terisi pada 30.5/41/50/52/58.5 s: ' + seq.join(' '));

    /* ---------------- D. determinism */
    const frames = [600, 1730, 2650, 3790, 4580, 5399, 6300, 7199];
    const A = await open(browser, '?render=1'), B = await open(browser, '?render=1');
    let seekSame = 0;
    for (const f of frames) { await A.page.evaluate(i => window.renderFrame(i), f); await B.page.evaluate(i => window.renderFrame(i), f); if ((await shot(A)) === (await shot(B))) seekSame++; }
    check('D1 seeking to a frame is reproducible across fresh pages', seekSame === frames.length, seekSame + '/' + frames.length + ' identical');
    const stateHash = () => { const out = []; for (const el of document.querySelectorAll('#stage *')) { if (!el.getClientRects().length) continue; let o = 1, e = el; while (e && e.id !== 'stage') { const cs = getComputedStyle(e); o *= parseFloat(cs.opacity); if (cs.visibility === 'hidden') o = 0; e = e.parentElement; } if (o <= 0.001) continue; out.push(Array.from(el.style).sort().map(k => k + ':' + el.style.getPropertyValue(k)).join(';'), Array.from(el.classList).sort().join(' '), el.getAttribute('d') || '', el.getAttribute('opacity') || '', el.getAttribute('transform') || '', el.getAttribute('stroke-dashoffset') || '', el.childElementCount ? '' : el.textContent); } return out.join('|'); };
    let stateSame = 0; const sampled = [1730, 3790, 5600, 7000];
    const P1 = await open(browser, '?render=1');
    for (let f = 0; f <= 7000; f += 2) { await P1.page.evaluate(i => window.renderFrame(i), f); if (sampled.includes(f)) { const a = sha(await P1.page.evaluate(stateHash)); await B.page.evaluate(i => window.renderFrame(i), f); const b = sha(await B.page.evaluate(stateHash)); if (a === b) stateSame++; } }
    check('D2 playing to frame N gives the same visible DOM state as seeking to N', stateSame === sampled.length, stateSame + '/' + sampled.length + ' identical hashes over every element with non-zero effective opacity');
    await A.ctx.close(); await B.ctx.close(); await P1.ctx.close();

    /* ---------------- E. audio */
    const au = await R.page.evaluate(async () => { const m = await window.ACD.audio.render(); let pk = 0, acc = 0; for (let i = 0; i < m.length; i++) { const v = Math.max(Math.abs(m.L[i]), Math.abs(m.R[i])); if (v > pk) pk = v; acc += m.L[i] * m.L[i]; } return { len: m.length, sr: m.sampleRate, peak: pk, rms: Math.sqrt(acc / m.length), events: buildSoundEvents().length, taps: buildSoundEvents().filter(e => e.k === 'tap').length }; });
    check('E1 audio mix is exactly 120.000 s at 48 kHz', au.len === 120 * 48000 && au.sr === 48000, au.len + ' samples');
    check('E2 audio peak below full scale', au.peak < 0.9, 'peak ' + (20 * Math.log10(au.peak)).toFixed(1) + ' dBFS, rms ' + (20 * Math.log10(au.rms)).toFixed(1) + ' dBFS');
    check('E3 sound cues come from the shared timeline', au.events > 80 && au.taps >= 18, au.events + ' events, ' + au.taps + ' taps');

    /* ---------------- G. narration timing */
    const nar = await R.page.evaluate(() => ({ src: typeof NARRATION_SOURCE !== 'undefined' ? NARRATION_SOURCE : '?', n: NARRATION.length, cues: CUES.length, rate: Math.max(...CUES.map(c => (c.say.toLowerCase().replace(/ai|au|oi/g, 'a').match(/[aeiou]/g) || []).length / (c.end - c.start))) }));
    check('G1 narration: 7 scene takes, 27 caption cues (' + nar.src + ' timing)', nar.n === 7 && nar.cues === 27, 'max ' + nar.rate.toFixed(2) + ' suku kata/s per frasa');
    check('G2 no page errors in render mode', R.errors.length === 0, R.errors.join(' | '));
    await R.ctx.close();

    /* ---------------- F. player controls (preview mode) */
    const U = await open(browser, '');
    const st = () => U.page.evaluate(() => window.ACD.player.state);
    const visq = sel => U.page.evaluate(s => { const e = document.querySelector(s); if (!e) return false; const cs = getComputedStyle(e); return cs.display !== 'none' && cs.visibility !== 'hidden' && parseFloat(cs.opacity) > 0.05; }, sel);
    check('F1 start overlay and controls present', (await visq('#startOverlay')) && (await visq('#controls')));
    check('F2 Web Speech toggle disabled when no ms-MY voice exists', await U.page.evaluate(() => { const b = document.getElementById('bSpeech'); const has = 'speechSynthesis' in window && speechSynthesis.getVoices().some(v => /^ms/i.test(v.lang)); return has ? !b.disabled : b.disabled; }));
    await U.page.waitForFunction(() => /Sedia/.test(document.getElementById('startStatus').textContent), null, { timeout: 90000 });
    await U.page.click('#startOverlay');
    await sleep(1600);
    let s = await st();
    check('F3 first click starts playback and unlocks audio', s.playing && s.t > 1.0 && s.ctx === 'running' && s.buffer && s.audioClock, JSON.stringify({ t: +s.t.toFixed(2), ctx: s.ctx, audioClock: s.audioClock }));
    await U.page.keyboard.press('Space'); await sleep(100);
    const p1 = await st(); await sleep(500); const p2 = await st();
    check('F4 pause holds the frame', !p1.playing && p1.t === p2.t, 't=' + p1.t.toFixed(3));
    await U.page.click('.scene-btn[data-s="4"]'); await sleep(150);
    s = await st();
    check('F5 scene jump to segment 4 lands on 01:02.000 (frame 3720)', Math.abs(s.t - 62) < 1e-6 && s.frame === 3720, 't=' + s.t + ' frame=' + s.frame);
    await U.page.evaluate(() => { const r = document.getElementById('scrub'); r.value = '4560'; r.dispatchEvent(new Event('input', { bubbles: true })); });
    s = await st();
    check('F6 scrubber seeks to frame 4560 (01:16.000)', s.frame === 4560 && Math.abs(s.t - 76) < 1e-6, 'frame=' + s.frame);
    const subOn = await U.page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('[data-ref="subsBox"]')).opacity));
    await U.page.keyboard.press('s'); await sleep(50);
    const subOff = await U.page.evaluate(() => parseFloat(getComputedStyle(document.querySelector('[data-ref="subsBox"]')).opacity));
    await U.page.keyboard.press('s');
    check('F7 subtitle toggle hides/shows the caption', subOn > 0.9 && subOff === 0, 'on ' + subOn + ' / off ' + subOff);
    await U.page.click('#bMute'); s = await st();
    const muteTxt = await U.page.textContent('#bMute');
    check('F8 mute sets gain 0 and relabels the button', s.muted && s.gain === 0 && /Mati/.test(muteTxt), muteTxt.trim());
    await U.page.click('#bMute');
    await U.page.keyboard.press('7'); await sleep(100); s = await st();
    check('F9 key 7 jumps to the closing at 01:54.000 (frame 6840)', s.frame === 6840, 'frame=' + s.frame);
    await U.page.click('#bRestart'); await sleep(300); s = await st();
    check('F10 restart returns to 0 and plays', s.playing && s.t < 0.6, 't=' + s.t.toFixed(3));
    await U.page.mouse.move(5, 5); await sleep(3000);
    check('F11 controls auto-hide during playback', await U.page.evaluate(() => document.getElementById('controls').classList.contains('hidden')));
    await U.page.keyboard.press('c'); await sleep(100);
    const cleanHidden = !(await visq('#controls')) && (await U.page.evaluate(() => getComputedStyle(document.body).cursor)) === 'none';
    await U.page.keyboard.press('Escape'); await sleep(100);
    check('F12 clean recording mode hides controls and cursor; Esc exits', cleanHidden && (await visq('#controls')));
    await U.page.keyboard.press('Space'); await sleep(50);
    await U.page.keyboard.press('ArrowRight'); s = await st();
    const tA = s.t; await U.page.keyboard.press('.'); const sB = await st();
    check('F13 keyboard seek ±1 s and single-frame step', Math.abs(sB.t - tA - 1 / 60) < 1e-6, 't ' + tA.toFixed(3) + ' → ' + sB.t.toFixed(3));
    const timeLbl = await U.page.textContent('#tTime');
    check('F14 time display shows the 02:00.00 length', /\/ 02:00\.00/.test(timeLbl), timeLbl.trim());
    check('F15 no page errors in preview mode', U.errors.length === 0, U.errors.join(' | '));
    await U.ctx.close();
  } finally { await browser.close(); }

  const w = Math.max(...results.map(r => r.name.length));
  let fail = 0;
  for (const r of results) { if (!r.ok) fail++; console.log((r.ok ? 'PASS ' : 'FAIL ') + r.name.padEnd(w) + (r.detail ? '  · ' + r.detail : '')); }
  console.log('\n' + (results.length - fail) + '/' + results.length + ' checks passed');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
