#!/usr/bin/env node
/* Generates skrip-narasi-bm.md (per-scene narration script with timestamps) and
 * sari-kata-bm.srt from src/data.js, so the documents use exactly the cue times
 * the player and the MP4 use (planned, or measured by tools/sync-narration.js). */
'use strict';
const fs = require('fs');
const path = require('path');
const D = require('../src/data.js');
const ROOT = path.resolve(__dirname, '..');

const ts = s => { const m = Math.floor(s / 60), r = s - m * 60; return String(m).padStart(2, '0') + ':' + r.toFixed(2).padStart(5, '0'); };
const srt = s => { const ms = Math.round(s * 1000), h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, sec = Math.floor(ms / 1000) % 60; return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0') + ',' + String(ms % 1000).padStart(3, '0'); };
// BM syllables ≈ vowel nuclei (ai/au/oi once); acronyms as spoken
const SPELL = { 'e-ACD': 'i ei si di', WhatsApp: 'wat sep' };
const syl = s => s.split(/\s+/).map(w => { const k = w.replace(/[.,?]/g, ''); const x = SPELL[k] || k; return (x.toLowerCase().replace(/ai|au|oi/g, 'a').match(/[aeiou]/g) || []).length; }).reduce((a, b) => a + b, 0);
const timed = D.NARRATION_SOURCE === 'recording';

let md = '# Skrip Narasi BM — NADI Muallim (120 saat)\n\n';
md += 'Narasi Bahasa Melayu untuk filem pertandingan PKD Muallim, dibahagikan kepada **7 rakaman mengikut babak**. Semua masa dalam dokumen ini dijana daripada `src/data.js`, iaitu jadual kiu yang sama yang memacu sari kata dalam `video-showcase.html`, fail `sari-kata-bm.srt` dan campuran audio dalam `render-video.js`.\n\n';
md += timed
  ? '> **Status masa:** masa di bawah diukur daripada rakaman (`src/narration-timing.json`, dijana oleh `tools/sync-narration.js`).\n\n'
  : '> **Status masa:** masa di bawah ialah masa **dirancang**. Selepas rakaman disegerakkan dengan `tools/sync-narration.js`, jana semula dokumen ini supaya masa mengikut rakaman.\n\n';
md += '## Taklimat rakaman\n\n';
md += '- **Satu fail bagi setiap babak:** `narasi/babak-1.wav` hingga `narasi/babak-7.wav` (WAV 48 kHz disyorkan; `.m4a`, `.mp3`, `.flac` dan `.ogg` juga diterima). Mono atau stereo.\n';
md += '- **Cara membaca:** mulakan setiap fail dengan kira-kira 0.5 s senyap. Baca ayat dalam babak itu berturut-turut dengan jeda biasa: kira-kira 0.3 s antara frasa dan 0.6 s antara ayat. Tidak perlu mengikut masa filem. `tools/sync-narration.js` memotong rakaman pada jeda dan meletakkan setiap **ayat** pada masa mulanya dalam jadual di bawah, supaya ayat itu kedengaran ketika paparan berkaitan berada dalam bingkai.\n';
md += '- **Rentak:** frasa dirancang pada 4.0–5.4 suku kata sesaat (lajur *Rentak*). Bahagian paling padat ialah babak 6 dan ayat akhir babak 5. Alat penyegerak membenarkan setiap ayat bermula sehingga 1.0 s lebih awal atau 0.5 s lewat. Ujian sintetik menunjukkan bacaan yang kira-kira **3% lebih perlahan** daripada rancangan masih muat. Jika lebih perlahan, babak 6–7 tidak muat dan alat itu akan menamakan ayat yang perlu dirakam semula dengan sedikit lebih pantas.\n';
md += '- **Pilihan jika babak 6 terlalu padat:** buang frasa *"bagi lokaliti yang sama"* (≈9 suku kata, ≈1.7 s). Maksud ayat kekal, kerana kad NADI sudah menamakan Kg. Ketoyong. Ini perubahan teks; kemas kini `src/data.js` (kiu 6b) jika digunakan.\n';
md += '- **Paras:** puncak tidak melebihi −3 dBFS, tanpa muzik atau kesan bunyi. `render-video.js --voiceover` menormalkan narasi ke −16 LUFS (dua laluan, linear) dan merendahkan muzik kira-kira 11 dB ketika narator bercakap.\n';
md += '- **Selepas rakaman:**\n\n```bash\nnode tools/sync-narration.js\n```\n\n```bash\nnode tools/build-player.js && node tools/make-docs.js\n```\n\n```bash\nnode render-video.js --voiceover narasi/narasi-penuh.wav\n```\n\n';
md += '## Narasi mengikut babak (baca tepat seperti tertulis)\n\n';
md += '*Teks dibaca* ialah apa yang disebut oleh narator (nombor ditulis dalam perkataan). *Sari kata* ialah apa yang dipaparkan (maksimum dua baris, nombor dalam digit).\n\n';
for (const s of D.SCENES) {
  const n = D.NARRATION.find(q => q.scene === s.id), cues = D.CUES.filter(c => c.scene === s.id);
  md += '### Babak ' + s.id + ' · ' + ts(s.start) + '–' + ts(s.end) + ' · ' + s.title + '\n\n';
  md += '**Fail:** `narasi/babak-' + s.id + '.wav` · **Narasi:** ' + ts(n.start) + '–' + ts(n.end) + ' (' + (n.end - n.start).toFixed(1) + ' s, ' + syl(n.say) + ' suku kata)\n\n';
  md += '> ' + n.say + '\n\n';
  md += '| Kiu | Mula | Tamat | Rentak (suku kata/s) | Teks dibaca | Sari kata |\n|---|---|---|---|---|---|\n';
  for (const c of cues) md += '| ' + c.id + ' | ' + ts(c.start) + ' | ' + ts(c.end) + ' | ' + (syl(c.say) / (c.end - c.start)).toFixed(1) + ' | ' + c.say + ' | ' + c.sub.replace(/\n/g, ' / ') + ' |\n';
  md += '\n';
}
md += '## Nota sebutan dan penyampaian (bukan sebahagian teks)\n\n| Istilah | Panduan |\n|---|---|\n';
md += '| NADI | Sebut sebagai perkataan: "na-di". |\n';
md += '| e-ACD | Sebut huruf: "i-ei-si-di". |\n';
md += '| WhatsApp | Nama produk seperti biasa. |\n';
md += '| Aedes | Ikut sebutan yang digunakan Unit Vektor PKD; sahkan dengan pegawai bertugas sebelum rakaman. |\n';
md += '| Muallim | Tiga suku kata jelas: "Mu-al-lim". |\n';
md += '| Nombor | Baca penuh seperti tertulis: *sembilan puluh dua*, *seratus sepuluh*, *lapan puluh empat peratus*. |\n';
md += '| Nada | Tenang, yakin dan formal, seperti taklimat kesihatan awam, bukan iklan. Beri sedikit penekanan pada *automatik*, *lapan puluh empat peratus* dan *enam premis*. |\n';
md += '| Ketepatan | *"Dalam simulasi ini"* (babak 4) dan *"Dalam prototaip integrasi ini"* (babak 6) mesti dikekalkan: angka ialah data sintetik dan paparan NADI–e-ACD ialah prototaip. |\n\n';
md += '## Peta babak\n\n| Babak | Masa | Tajuk | Paparan utama |\n|---|---|---|---|\n';
const VIEW = { 1: 'Peta NADI dan kad Kg. Ketoyong; soalan penyelia', 2: 'Borang, fail rekod, kiraan manual dan taip semula; e-ACD dibuka pada telefon', 3: 'Satu rekod premis contoh pada telefon; "Rekod disimpan"', 4: 'Jadual enam pasukan; 92 daripada 110 premis, 84% liputan ACD', 5: 'Pengesahan Bahagian D; ringkasan ditampal untuk WhatsApp', 6: 'Kad NADI dengan ringkasan e-ACD (prototaip integrasi); 6 premis belum dilawati; rancang lawatan susulan', 7: 'Jata Negara, NADI Muallim, Pejabat Kesihatan Daerah Muallim' };
for (const s of D.SCENES) md += '| ' + s.id + ' | ' + ts(s.start) + '–' + ts(s.end) + ' | ' + s.title + ' | ' + VIEW[s.id] + ' |\n';
fs.writeFileSync(path.join(ROOT, 'skrip-narasi-bm.md'), md);

let out = '';
D.CUES.forEach((c, i) => { out += (i + 1) + '\n' + srt(c.start) + ' --> ' + srt(c.end) + '\n' + c.sub + '\n\n'; });
fs.writeFileSync(path.join(ROOT, 'sari-kata-bm.srt'), out);
console.log('wrote skrip-narasi-bm.md and sari-kata-bm.srt (' + D.CUES.length + ' kiu, ' + D.NARRATION.length + ' babak, masa ' + (timed ? 'rakaman' : 'dirancang') + ')');
